// 首先导入socket.io-client库中的io函数以及Socket类型，用于创建WebSocket连接及后续类型标注
// import { io, Socket } from'socket.io-client';

// 定义WebSocketClient类
class WebSocketClient {
  // 声明messageHandlers属性，类型为一个函数数组，每个函数接收一个任意类型的参数，无返回值
  messageHandlers: ((data: any) => void)[] = []
  // 声明socket属性，类型为Socket.io的Socket类型
  socket: any

  params: any

  revertHandler: (data: any) => void = () => { }

  // 构造函数
  constructor(params: any) {
    this.params = params;
    console.log('ws参数:', params)
    // 在构造函数中调用connect方法来建立连接
    this.connect(params)
  }

  // 连接方法，用于建立WebSocket连接以及设置相关的事件监听
  connect(params: any): void {

    // wsFullHost , 去掉前面的 
    let socketHost = params.host
    let host = ""
    host = socketHost.replace(/^(ws|wss):\/\//, '') // 去掉前面的 ws:// 或 wss://
    host = host.replace(/\/$/, '') // 去掉末尾的斜杠
    // 使用io函数创建WebSocket连接，传入连接的URL以及一些配置选项


    console.log('ws host1:', socketHost)
    console.log('ws host2:', host)

    this.socket = io(socketHost, {
      host: host,
      secure: true,
      transports: ['websocket'],
      query: 'token=' + params.uuid + '&platform=kf',
      path: '/socket.io/',
      reconnection: true,
    })

    // 监听服务端发送的'messageAck'消息，当收到该消息时，解析消息内容并遍历所有消息处理函数进行调用
    this.socket.on('messageAck', (msg: string) => {
      let data = JSON.parse(msg)
      console.log('messageAck-->', data)
    })

    this.socket.on('message', (msg: string) => {
      let data = JSON.parse(msg)
      console.log('message-->', data)
      this.messageHandlers.forEach((handler) => handler(data))
    })

    this.socket.on('revert', (msg: string) => {
      let data = JSON.parse(msg)
      this.revertHandler(data)
    })

    // 监听服务端断开连接的事件，当连接断开时，在控制台打印断开原因
    this.socket.on('disconnect', (reason: string) => {
      console.log('Disconnected from the server:', reason)
    })

    // 监听服务端发送的'sessionId'消息，当收到该消息时，在控制台打印出sessionId信息
    this.socket.on('sessionId', (msg: string) => {
      this.socket = null;
      console.log('sessionId-->', msg)
    })
  }

  // 发送消息的方法，接收一个消息参数，类型为任意类型（可根据实际情况细化为具体类型），将其转换为JSON字符串后通过WebSocket连接发送给服务端
  async sendMessage(message: any): void {
    if (!this.socket) {
      await this.reconnect()
    }
    console.log('发送消息:', message)
    this.socket.emit('message', JSON.stringify(message))
  }

  // 接收消息的方法，接收一个消息处理函数作为参数，该函数接收一个任意类型的参数且无返回值，将其添加到messageHandlers数组中，以便后续处理接收到的消息
  onMessage(handler: (data: any) => void): void {
    this.messageHandlers.push(handler)
  }

  onRevert(handler: (data: any) => void): void {
    this.revertHandler = handler
  }

  // 发送已读事件. 
  async sendReadEvent(msg): void {
    console.log('发送已读消息', msg)
    if (!this.socket) {
      await this.reconnect()
    }
    this.socket.emit('message', JSON.stringify({ msgType: 'kfuserread', ...msg }))
  }

  // 检查WebSocket连接状态
  isConnected(): boolean {
    return this.socket && this.socket.connected;
  }

  // 重新连接WebSocket
  async reconnect(): Promise<void> {
    if (this.socket) {
      // 如果存在旧连接，先断开
      this.socket.disconnect();
    }
    // 重新建立连接
    this.connect(this.params);

    // 等待连接建立
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error('WebSocket reconnection timeout'));
      }, 5000); // 5秒超时

      this.socket.on('connect', () => {
        clearTimeout(timeout);
        resolve();
      });

      this.socket.on('connect_error', (error) => {
        clearTimeout(timeout);
        reject(error);
      });
    });
  }
}

export default WebSocketClient
