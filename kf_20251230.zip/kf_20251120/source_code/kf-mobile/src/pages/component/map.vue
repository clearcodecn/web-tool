<template>
    <div class="map-container">
        <div class="search-box">
            <van-search v-model="searchKeyword" placeholder="搜索位置" @search="onSearch" @clear="onClear" />
            <div v-if="searchResults.length > 0" class="search-results">
                <div v-for="(item, index) in searchResults" :key="index" class="search-item"
                    @click="selectSearchResult(item)">
                    <van-icon name="location-o" />
                    <div class="item-info">
                        <div class="item-title">{{ item.title }}</div>
                        <div class="item-address">{{ item.address }}</div>
                    </div>
                </div>
            </div>
        </div>
        <div id="map" class="map"></div>
        <div class="map-controls">
            <template v-if="!isReadOnly">
                <div class="button-group">
                    <van-button plain block @click="cancelSelection">取消</van-button>
                    <van-button type="primary" block @click="confirmLocation">确定</van-button>
                </div>
            </template>
            <template v-else>
                <van-button plain block @click="closeMap">关闭</van-button>
            </template>
        </div>
    </div>
</template>

<script setup lang="ts">
import { onMounted, onUnmounted, ref, computed } from 'vue'
import { showToast } from 'vant'

const emit = defineEmits(['select-location', 'close'])

const props = defineProps<{
    initialLocation?: {
        lat: number
        lng: number
        address: string
    }
}>()

const isReadOnly = computed(() => !!props.initialLocation)

const map = ref<any>(null)
const marker = ref<any>(null)
const selectedLocation = ref<{
    lat: number
    lng: number
    address: string
} | null>(null)

const searchKeyword = ref('')
const searchResults = ref<any[]>([])
const localSearch = ref<any>(null)

// 初始化地图
const initMap = () => {
    // 创建地图实例
    map.value = new BMap.Map('map')

    // 初始化本地搜索
    localSearch.value = new BMap.LocalSearch(map.value, {
        onSearchComplete: (results: any) => {
            console.log('results', results)
            if (results.getNumPois() > 0) {
                const pois = []
                for (let i = 0; i < results.getCurrentNumPois(); i++) {
                    const poi = results.getPoi(i)
                    pois.push({
                        title: poi.title,
                        address: poi.address,
                        point: poi.point
                    })
                }
                searchResults.value = pois
            } else {
                searchResults.value = []
                showToast('未找到相关位置')
            }
        }
    })

    // 获取当前位置
    const geolocation = new BMap.Geolocation()
    geolocation.enableHighAccuracy = true // 开启高精度定位
    geolocation.getCurrentPosition((result: any) => {
        if (geolocation.getStatus() === BMAP_STATUS_SUCCESS) {
            const point = new BMap.Point(result.point.lng, result.point.lat)
            map.value.centerAndZoom(point, 15)

            // 添加标记
            marker.value = new BMap.Marker(point)
            map.value.addOverlay(marker.value)

            // 获取地址信息
            const geocoder = new BMap.Geocoder()
            geocoder.getLocation(point, (res: any) => {
                if (res) {
                    selectedLocation.value = {
                        lat: result.point.lat,
                        lng: result.point.lng,
                        address: res.address
                    }
                }
            })
        } else {
            console.log('定位失败:', geolocation.getStatus())
            // 如果获取当前位置失败，则使用初始位置或默认位置
            if (props.initialLocation) {
                const point = new BMap.Point(props.initialLocation.lng, props.initialLocation.lat)
                map.value.centerAndZoom(point, 15)
                marker.value = new BMap.Marker(point)
                map.value.addOverlay(marker.value)
                selectedLocation.value = props.initialLocation
            } else {
                // 默认定位到北京
                const point = new BMap.Point(116.404, 39.915)
                map.value.centerAndZoom(point, 15)
            }
        }
    }, {
        enableHighAccuracy: true, // 开启高精度定位
        timeout: 10000, // 超时时间
        maximumAge: 0 // 禁用缓存
    })

    // 添加地图控件
    map.value.addControl(new BMap.NavigationControl())
    map.value.addControl(new BMap.ScaleControl())

    // 只在非只读模式下添加点击事件
    if (!isReadOnly.value) {
        map.value.addEventListener('click', (e: any) => {
            const point = new BMap.Point(e.point.lng, e.point.lat)

            // 更新标记位置
            if (marker.value) {
                marker.value.setPosition(point)
            } else {
                marker.value = new BMap.Marker(point)
                map.value.addOverlay(marker.value)
            }

            // 获取地址信息
            const geocoder = new BMap.Geocoder()
            geocoder.getLocation(point, (res: any) => {
                if (res) {
                    selectedLocation.value = {
                        lat: e.point.lat,
                        lng: e.point.lng,
                        address: res.address
                    }
                }
            })
        })
    }
}

// 搜索位置
const onSearch = () => {
    if (isReadOnly.value) return
    if (!searchKeyword.value.trim()) {
        showToast('请输入搜索关键词')
        return
    }
    localSearch.value.search(searchKeyword.value)
}

// 清除搜索
const onClear = () => {
    searchResults.value = []
}

// 选择搜索结果
const selectSearchResult = (item: any) => {
    if (isReadOnly.value) return
    const point = item.point
    map.value.centerAndZoom(point, 15)

    // 更新标记位置
    if (marker.value) {
        marker.value.setPosition(point)
    } else {
        marker.value = new BMap.Marker(point)
        map.value.addOverlay(marker.value)
    }

    selectedLocation.value = {
        lat: point.lat,
        lng: point.lng,
        address: item.address
    }

    // 清空搜索结果
    searchResults.value = []
    searchKeyword.value = ''
}

// 确认选择位置
const confirmLocation = () => {
    if (!selectedLocation.value) {
        showToast('请先选择位置')
        return
    }

    emit('select-location', selectedLocation.value)
    emit('close')
}

// 关闭地图
const closeMap = () => {
    emit('close')
}

// 取消选择
const cancelSelection = () => {
    if (marker.value) {
        map.value.removeOverlay(marker.value)
        marker.value = null
    }
    selectedLocation.value = null
    emit('close')
}

onMounted(() => {
    // 动态加载百度地图脚本
    const script = document.createElement('script')
    script.src = `https://api.map.baidu.com/api?v=3.0&ak=baiduKey&callback=initBMap`
    document.head.appendChild(script)

    // 定义全局回调函数
    window.initBMap = () => {
        initMap()
    }
})

onUnmounted(() => {
    // 清理地图实例
    if (map.value) {
        map.value.clearOverlays()
        map.value = null
    }
    // 移除全局回调
    delete window.initBMap
})
</script>

<style lang="scss" scoped>
.map-container {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: #fff;
    z-index: 1000;
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100vh;
    max-width: 100vw;
    overflow: hidden;
}

.search-box {
    position: relative;
    z-index: 1001;
    background: #fff;
    padding: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.map {
    flex: 1;
    width: 100%;
    height: 100%;
    min-height: 0; // 防止flex布局下的溢出
    position: relative;
}

.map-controls {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 1002;
    padding: 16px;
    background: #fff;
    border-top: 1px solid #eee;
    width: 100%;
    box-sizing: border-box;
    transform: translateZ(0); // 强制创建新的层叠上下文

    .button-group {
        display: flex;
        gap: 12px;
        width: 100%;
        max-width: 800px;
        margin: 0 auto;
    }
}

.search-results {
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    background: #fff;
    max-height: 300px;
    overflow-y: auto;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    z-index: 1002;
    width: 100%;
    box-sizing: border-box;
}

.search-item {
    display: flex;
    align-items: flex-start;
    padding: 12px;
    border-bottom: 1px solid #eee;
    cursor: pointer;
    width: 100%;
    box-sizing: border-box;

    &:active {
        background: #f5f5f5;
    }

    .van-icon {
        font-size: 20px;
        color: #1989fa;
        margin-right: 8px;
        flex-shrink: 0;
    }

    .item-info {
        flex: 1;
        min-width: 0;
        width: 100%;
        overflow: hidden;

        .item-title {
            font-size: 14px;
            color: #323233;
            margin-bottom: 4px;
            word-break: break-all;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
            line-height: 1.4;
        }

        .item-address {
            font-size: 12px;
            color: #969799;
            word-break: break-all;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
            line-height: 1.4;
        }
    }
}
</style>