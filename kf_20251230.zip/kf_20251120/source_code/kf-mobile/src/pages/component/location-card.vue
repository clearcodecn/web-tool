<template>
    <div class="location-card" @click="openMap">
        <div class="map-preview">
            <img :src="mapImageUrl" alt="位置预览" />
        </div>
        <div class="location-info">
            <div class="location-title">{{ location.address }}</div>
            <div class="location-address">{{ location.address }}</div>
        </div>
    </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps<{
    location: {
        lat: number
        lng: number
        address: string
    }
}>()

const emit = defineEmits(['open-map'])

// 生成百度地图静态图片URL
const mapImageUrl = computed(() => {
    const { lat, lng } = props.location
    const width = 300
    const height = 150
    const zoom = 15
    const markers = `${lng},${lat}`
    return `https://api.map.baidu.com/staticimage/v2?ak=baiduKey&mcode=666666&center=${lng},${lat}&width=${width}&height=${height}&zoom=${zoom}&markers=${markers}&markerStyles=l,A`
})

const openMap = () => {
    emit('open-map', props.location)
}
</script>

<style lang="scss" scoped>
.location-card {
    width: 100%;
    max-width: 300px;
    background: #fff;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    cursor: pointer;
    transition: transform 0.2s ease;

    &:active {
        transform: scale(0.98);
    }

    .map-preview {
        width: 100%;
        height: 150px;
        overflow: hidden;
        background: #f5f5f5;

        img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
    }

    .location-info {
        padding: 12px;

        .location-title {
            font-size: 16px;
            font-weight: 500;
            color: #333;
            margin-bottom: 4px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .location-address {
            font-size: 14px;
            color: #666;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
    }
}
</style>