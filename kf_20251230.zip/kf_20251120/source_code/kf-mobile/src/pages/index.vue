<template>
  <div class="chatroom-contain">
    <div v-show="topNotice" class="top-notice" @click="isShowNotice = true">
      <div class="scrolling-text">
        {{ topNotice }}
      </div>
    </div>
    <!-- 消息展示区域 -->
    <div class="message-display" ref="messageDisplayRef">
      <template v-for="(message, index) in processedMessages" :key="index">
        <div v-if="message.showTime" class="time">{{ message.displayMsgTime }}</div>
        <div :class="['message', message.isKf == '2' ? 'right' : '']">
          <div class="avatar-and-name">
            <!-- <span class="name">{{ message.guestName }}</span> -->
            <img :src="message.isKf == '2' ? guestAvatar : kfAvatar" alt="Avatar" />
          </div>
          <div class="message-content">
            <p v-if="message.msgType === 'text' || message.msgType == 'smartReply'" class="msg-text"
              v-html="message.content"></p>
            <template v-if="message.msgType === 'image'">
              <van-image width="160" height="120" fit="cover" :src="globalCdnHost + message.content"
                @click="previewImage(globalCdnHost + message.content)" />
            </template>
            <div v-if="message.msgType === 'video'" class="video-contain"
              @click="playVideo(globalCdnHost + message.content.url)">
              <van-image width="160" height="120" fit="cover" :src="globalCdnHost + message.content.thumb" />
              <van-icon name="play-circle-o" class="play-icon" />
            </div>
            <div v-if="message.msgType === 'smart_msg'" class="msg-text">
              <p>{{ message.content.describe }}</p>
              <p v-for="item in message.content.list" key="item.id">
                <van-highlight :keywords="item.title" :source-string="item.title" @click="onSelectSmartMsg(item)" />
              </p>
            </div>
            <div v-if="message.msgType === 'location'" class="location">
              <LocationCard :location="message.content" @open-map="handleOpenMap" />
            </div>
          </div>
        </div>
      </template>
    </div>
    <!-- 消息输入区域 -->
    <div class="input-area safe-area-inset-bottom" :class="{ 'emoji-picker-visible': showEmojiPicker }">
      <div class='input-container' :class="{ 'input-min-height': showFunctionPanel }">
        <div class="input-toolbar">
          <!-- <van-icon name="smile-o" class="toolbar-icon" size="24" @click="toggleEmojiPicker" /> -->
          <van-field v-model="newMessage" type="textarea" rows="1" autosize class="input-box" placeholder="请输入消息..."
            @focus="hidePicker" @keydown.enter.prevent="onEnter" :enterkeyhint="'send'" />
          <van-icon name="add-o" class="toolbar-icon" size="24" @click="toggleFunctionPanel" />
          <span class="send-button" @click="onEnter">发送</span>
        </div>

        <!-- 功能面板 -->
        <div v-show="showFunctionPanel" class="function-panel">
          <div class="function-item" @click="triggerImageUpload">
            <van-icon name="photo-o" size="36" />
            <span>图片</span>
          </div>
          <!-- 预留视频功能位置 -->
          <div class="function-item" @click='triggerVideoUpload'>
            <van-icon name='video-o' size="36" />
            <span>视频</span>
          </div>
          <!-- 预留地图位置，选择位置 -->
          <!-- <div class="function-item" @click='triggerMapSelect'>
            <van-icon name='location-o' size="36" />
            <span>位置</span> -->
        </div>
      </div>
    </div>

    <!-- 隐藏的文件上传组件 -->
    <van-uploader ref="uploaderRef" :after-read="afterRead" :max-count="9" :max-size="isOverSize" @oversize="onOversize"
      :accept="accept" style="display: none" />
  </div>

  <!-- 表情包选择区域 -->
  <div v-if="showEmojiPicker" class="emoji-picker-wrapper">
    <div class="emoji-picker-content">
      <div v-for="(emoji, index) in emojiList" :key="index" class="emoji-item" @click="onSelectEmoji(emoji)">
        {{ emoji }}
      </div>
    </div>
    <div class="emoji-picker-footer">
      <div class="emoji-actions">
        <van-icon name="arrow-left" class="delete-btn" @click="deleteLastEmoji" />
        <div class="send-btn" @click="onEnter">发送</div>
      </div>
    </div>
  </div>

  <!-- 视频播放 -->
  <van-overlay :show="showVideo" @click="stopPlayVideo">
    <div class="video-wrapper" @click.stop>
      <van-icon name="close" class="close-icon" @click="stopPlayVideo" />
      <video @play="onPlay" @pause="onPause" @ended="onEnded" ref="videoPlayer" :src="videoUrl" controls autoplay
        class="video-player" playsinline webkit-playsinline x5-video-player-type="h5" x5-video-player-fullscreen="true"
        x5-video-orientation="portraint" @click="togglePlay"></video>
    </div>
  </van-overlay>

  <!-- 检测 loading -->
  <van-overlay :show="isShowChecking" :z-index="2000">
    <div class="loading-wrapper">
      <van-loading type="spinner" color="#1989fa" size="36px" />
      <span class="loading-text">正在接入客服</span>
    </div>
  </van-overlay>

  <!-- 上传 loading -->
  <van-overlay :show="isUploading" :z-index="2000">
    <div class="loading-wrapper">
      <van-loading type="spinner" color="#1989fa" size="36px" />
      <span class="loading-text">文件上传中...</span>
    </div>
  </van-overlay>

  <!-- 公告弹出层 -->
  <van-popup v-model:show="isShowNotice" :style="{ padding: '64px' }" closeable>{{ topNotice }}</van-popup>

  <!-- 在底部添加地图组件 -->
  <MapComponent v-if="showMap" :initial-location="selectedLocation" @select-location="handleLocationSelect"
    @close="showMap = false" />

</template>

<script setup lang="ts">
import EmojiPicker from 'vue3-emoji-picker'
import 'vue3-emoji-picker/css'
import { useRouter, useRoute } from 'vue-router'
import { nextTick, onMounted, onUnmounted, ref, computed } from 'vue'
import { showFailToast } from 'vant'
import WebSocketClient from '@/plugins/mySocket.ts';
import dayjs from 'dayjs'
import { showImagePreview, Loading } from 'vant';
import { checkIP, msgList, fileUpload, getNotice, stayReport } from '@/service/user'
import { getCurrentUser } from '@/service/user'
import { throttle } from 'lodash-es'
import MapComponent from './component/map.vue'
import LocationCard from './component/location-card.vue'

// 客服头像
const { VITE_CDN_URL, VITE_KF_AVATAR } = import.meta.env
// 粉丝头像
let guestAvatar: any

// 聊天窗口引用
const messageDisplayRef = ref()
const accept = ref('image/*,video/*')

// 消息对象数组
const messages: any = ref([]);
// 处理后的消息，带 showTime 字段
const processedMessages = computed(() => {
  const FIVE_MINUTES = 5 * 60; // 单位：秒
  let lastTimestamp: any = null;

  return messages.value.map((msg: any, index: any) => {
    const currentTime = msg.msgTime;
    let showTime = false;

    if (index === 0 || !lastTimestamp || (currentTime - lastTimestamp > FIVE_MINUTES)) {
      showTime = true;
      lastTimestamp = currentTime;
    }

    return {
      ...msg,
      showTime,
      displayMsgTime: showTime ? formatTime(msg.msgTime) : undefined
    };
  });
});

const formatTime = (timestamp: any) => {
  if (timestamp === 0) {
    return ''
  }
  const msgDate = dayjs(timestamp * 1000);
  const today = dayjs();

  if (msgDate.isSame(today, 'day')) {
    return msgDate.format('HH:mm');
  } else {
    return msgDate.format('YYYY-MM-DD HH:mm');
  }
};

const keywords = ref([]);

const newMessage = ref('');
const code = ref('');
const isShowChecking = ref(false);
const isUploading = ref(false);
const route = useRoute()
const router = useRouter()
const topNotice = ref('')
const globalCdnHost = ref('')
const kfName = ref('')
const kfAvatar = ref('')
const lastFocusTime = ref(0);


/** 选择表情包  */
const showEmojiPicker = ref(false);
const toggleEmojiPicker = () => {
  showEmojiPicker.value = !showEmojiPicker.value;
};

const hidePicker = () => {
  showEmojiPicker.value = false;
  showFunctionPanel.value = false;
};

const onSelectEmoji = (emoji: string) => {
  newMessage.value += emoji
  // 确保输入框高度适应内容
  nextTick(() => {
    const inputBox = document.querySelector('.input-box .van-field__control') as HTMLElement
    if (inputBox) {
      inputBox.style.height = 'auto'
      inputBox.style.height = inputBox.scrollHeight + 'px'
    }
  })
}
/** 选择表情包  */

// 上传文件
const handleUpload = async (formData: any, isImage: boolean) => {
  isUploading.value = true;
  try {
    const res = await fileUpload(formData)
    if (res.code === 200) {
      const { cdnHost, path, thumb } = res.data
      // 发送至聊天框
      const params = {
        msgType: isImage ? 'image' : 'video', // 需要区分video or image
        msgTime: dayjs().unix(),
        content: `${path}`, //上传成功后获取到的url
        guestAvatar,
        isKf: 2,
      }
      if (params.msgType === 'video') {
        params.content = {
          url: path,
          thumb: thumb,
        }
      }

      messages.value.push(JSON.parse(JSON.stringify(params)))
      // 需要序列号提交 
      if (params.msgType === 'video') {
        params.content = JSON.stringify(params.content)
      }

      await wsClient.sendMessage(JSON.parse(JSON.stringify(params)))
      nextTick(() => {
        messageDisplayRef.value.scrollTop = messageDisplayRef.value.scrollHeight
      })
      // 关闭工具栏
      showFunctionPanel.value = false
    }
  } finally {
    isUploading.value = false;
  }
}

/** 选择文件 */
const IMG_MAX = 10
const VIDEO_MAX = 50
const isOverSize = (file: any) => {
  const maxSize = file.type.includes('image') ? IMG_MAX * 1024 * 1024 : VIDEO_MAX * 1024 * 1024;
  return file.size >= maxSize;
};

const onOversize = (file: any) => {
  const isImg = file.file.type.includes('image')
  showFailToast(`${isImg ? '图片' : '视频'}最大不能超过${isImg ? IMG_MAX : VIDEO_MAX}M`);
};


const afterRead = (file: any) => {
  const isImage = file.file.type.includes('image')
  // 上传至服务器
  const formData = new FormData();
  formData.append('file', file.file);
  formData.append('fileType', isImage ? 'image' : 'video');
  handleUpload(formData, isImage)
};

// 预览图片
const previewImage = (url: string) => {
  showImagePreview({
    images: [url],
    closeable: true
  });
}

const hasUnReadMessage = ref(false);
const readMessageId = ref('');

// 预览视频
const showVideo = ref(false)
const videoUrl = ref('')
const isPlaying = ref(false)
const videoPlayer = ref(null);
const playVideo = (url: string) => {
  showVideo.value = true
  videoUrl.value = url
  nextTick(() => {
    if (videoPlayer.value) {
      videoPlayer.value.play()
      isPlaying.value = true
    }
  })
}

const togglePlay = () => {
  if (!videoPlayer.value) return
  if (isPlaying.value) {
    videoPlayer.value.pause()
  } else {
    videoPlayer.value.play()
  }
}

const onPause = () => {
  isPlaying.value = false
}

const onEnded = () => {
  isPlaying.value = false
}

const onPlay = () => {
  isPlaying.value = true
}

const stopPlayVideo = () => {
  if (videoPlayer.value) {
    videoPlayer.value.pause()
    videoPlayer.value.currentTime = 0
  }
  showVideo.value = false
  videoUrl.value = ''
  isPlaying.value = false
}


const onSelectSmartMsg = (smartMsg) => {
  const res = {
    msgType: 'smartReply',
    msgTime: dayjs().unix(),
    content: smartMsg.title,
    guestAvatar,
    isKf: 2,
    smartMsgId: smartMsg.id,
  }
  console.log('send -> ', res)
  messages.value.push(JSON.parse(JSON.stringify(res)))
  wsClient.sendMessage(JSON.parse(JSON.stringify(res)))
  newMessage.value = ''

  nextTick(() => {
    messageDisplayRef.value.scrollTop = messageDisplayRef.value.scrollHeight
  })

  throttledSendMessageRead()
}

/** 选择文件 */

const onEnter = (event: any) => {
  // 避免换行
  event.preventDefault()

  if (!newMessage.value.trim()) {
    showFailToast('请勿发送空白消息')
    return
  }
  const res = {
    msgType: 'text',
    msgTime: dayjs().unix(),
    content: newMessage.value,
    guestAvatar,
    isKf: 2,
  }
  messages.value.push(JSON.parse(JSON.stringify(res)))
  wsClient.sendMessage(JSON.parse(JSON.stringify(res)))
  newMessage.value = ''
  nextTick(() => {
    messageDisplayRef.value.scrollTop = messageDisplayRef.value.scrollHeight
  })

  throttledSendMessageRead()
}

const checking = async () => {
  isShowChecking.value = true;
  let ok = await checkIP({ code: code.value }).then((res: any) => {
    if (res.code != 200) {
      showFailToast(res.message);
      return
    }
    globalCdnHost.value = res.data.cdnHost
    kfName.value = res.data.kfName
    kfAvatar.value = globalCdnHost.value + res.data.kfAvatar
    // 设置html标题为客服名称
    document.title = kfName.value
    isShowChecking.value = false;
    return true;
  }).catch((err: any) => {
    console.log('检测失败:', err);
    isShowChecking.value = false;
    return false;
  })

  return ok
}

const lastMsgTime = ref(0)
let preScrollHeight = 0
let preScrollTop = 0
// 是否请求完消息
const isLoadAll = ref(false)
const isFetching = ref(false)
const isFirstLoadMsgList = ref(true)

const getMsg = async () => {
  if (isLoadAll.value) {
    return
  }
  if (isFetching.value) {
    return
  }
  isFetching.value = true

  preScrollHeight = messageDisplayRef.value.scrollHeight
  preScrollTop = messageDisplayRef.value.scrollTop
  if (lastMsgTime.value === 0 && !isFirstLoadMsgList.value) {
    // 没有消息就不加载列表
    return
  }
  isFirstLoadMsgList.value = false

  let msgs = await msgList({ lastMsgTime: lastMsgTime.value })

  isFetching.value = false

  msgs?.data?.messages?.forEach(el => {
    if (el.msgType === 'smart_msg' || el.msgType == 'location') {
      el.content = JSON.parse(el.content)
    }
    if (el.msgType === 'video') {
      try {
        let content = JSON.parse(el.content)
        el.content = content
      } catch (e) {
        el.content = {
          url: el.content,
          thumb: '',
        }
      }
    }
  })

  if (msgs.code === 200) {
    if (msgs?.data?.messages) {
      // 根据消息id去重 .
      const existingMsgIds = new Set(messages.value.map((msg: any) => msg.msgId));
      msgs.data.messages = msgs.data.messages.filter((msg: any) => !existingMsgIds.has(msg.msgId));
      if (msgs.data.messages.length === 0) {
        isLoadAll.value = true; // 没有更多消息了
        return;
      }
      messages.value = [...msgs.data.messages, ...messages.value]
      lastMsgTime.value = msgs.data.messages[0].msgTime
    } else {
      isLoadAll.value = true
    }
    // 滚动条定位
    nextTick(() => {
      if (preScrollHeight === 0) {
        messageDisplayRef.value.scrollTop = messageDisplayRef.value.scrollHeight
      } else {
        messageDisplayRef.value.scrollTop = (messageDisplayRef.value.scrollHeight - preScrollHeight) + preScrollTop
      }
    })
  }
  console.log('messages.value ->', messages.value)
  // 获取最后一条消息的id. 
  readMessageId.value = msgs.data?.messages?.[msgs.data?.messages.length - 1]?.msgId || ref(''); // 更新已读消息ID
  hasUnReadMessage.value = true;
  throttledSendMessageRead()
}

// 定义滚动事件处理函数
const handleScroll = throttle(() => {
  const { scrollTop } = messageDisplayRef.value;
  // 这里可以添加根据滚动位置执行的逻辑
  if (scrollTop <= 0) {
    getMsg()
  }

  if (!hasUnReadMessage.value) {
    throttledSendMessageRead()
  }
}, 500)

const isShowNotice = ref(false)
const initNotice = async () => {
  let noticeResp = await getNotice();
  if (noticeResp.code === 200) {
    let notice = noticeResp.data.notice
    if (notice != '') {
      topNotice.value = notice;
    }
  }
}

const focusState = ref(0)

const showFunctionPanel = ref(false)
const uploaderRef = ref()

const toggleFunctionPanel = () => {
  showFunctionPanel.value = !showFunctionPanel.value
  if (showFunctionPanel.value) {
    showEmojiPicker.value = false
    // 打开功能面板时，将输入框滚动到底部
    nextTick(() => {
      messageDisplayRef.value.scrollTop = messageDisplayRef.value.scrollHeight
    })
  }
}

const triggerImageUpload = () => {
  showFunctionPanel.value = false;
  accept.value = 'image/*'
  nextTick(() => {
    uploaderRef.value?.$el.querySelector('input[type="file"]')?.click()
  });
}


const triggerVideoUpload = () => {
  showFunctionPanel.value = false;
  accept.value = 'video/*'
  nextTick(() => {
    uploaderRef.value?.$el.querySelector('input[type="file"]')?.click()
  });
}

const deleteLastEmoji = () => {
  if (newMessage.value) {
    // 处理表情符号和普通文本的删除
    const lastChar = newMessage.value.slice(-1);
    const secondLastChar = newMessage.value.slice(-2, -1);

    // 检查是否是表情符号（通常表情符号是2个字符长度）
    if (lastChar && secondLastChar) {
      const lastTwoChars = secondLastChar + lastChar;
      // 如果是表情符号，删除两个字符
      if (/\p{Emoji}/u.test(lastTwoChars)) {
        newMessage.value = newMessage.value.slice(0, -2);
      } else {
        // 如果不是表情符号，只删除一个字符
        newMessage.value = newMessage.value.slice(0, -1);
      }
    } else {
      // 如果只有一个字符，直接删除
      newMessage.value = newMessage.value.slice(0, -1);
    }
  }
}

let wsClient: any
onMounted(async () => {

  let matchedCode = route.query.c;
  if (!matchedCode) {
    let pathMatch = route.params.pathMatch;
    if (!pathMatch || typeof pathMatch !== 'object' || pathMatch.length == 0) {
      // 路径参数错误，不跳转错误页面，直接返回
      return
    }
    matchedCode = '/s/' + pathMatch.join('/')
  }

  let res = matchedCode
  code.value = matchedCode
  let ok = await checking();
  if (!ok) {
    router.push('/error');
    return
  }

  // 开始上报. 
  let interval = setInterval(() => {
    // 这里做一下流量控制  
    throttleStayReport()
  }, 2000);

  const throttleStayReport = throttle(
    async () => {
      stayReport()
    },
    2000,
    {
      trailing: false // 不执行最后一次点击的延迟回调
    }
  )

  let user = getCurrentUser();
  // 粉丝头像
  guestAvatar = `${VITE_CDN_URL}${user.avatar}`

  // 获取聊天记录
  getMsg()

  let wsParams = {
    host: user.wsHost,
    uuid: user.uuid,
  };

  // 创建ws链接
  wsClient = new WebSocketClient(wsParams);

  wsClient.onMessage((res: any) => {
    if (res.msgType === 'smart_msg') {
      res.content = JSON.parse(res.content)
    }
    if (res.msgType === 'video' || res.msgType == 'location') {
      try {
        res.content = JSON.parse(res.content)
      } catch (e) {
        res.content = {
          url: res.content,
          thumb: '',
        }
      }
    }
    console.log('接收到啦：', res);
    res.msgTime = dayjs().unix()

    // 根据消息id去重，避免重复. 
    const m = JSON.parse(JSON.stringify(res))
    const existingMsgIds = new Set(messages.value.map((msg: any) => msg.msgId));
    if (!existingMsgIds.has(m.msgId)) {
      messages.value.push(m)
      // 到最底部
      nextTick(() => {
        messageDisplayRef.value.scrollTop = messageDisplayRef.value.scrollHeight || 0
      })
    }
    hasUnReadMessage.value = true;
    readMessageId.value = res.msgId; // 更新已读消息ID
  })

  wsClient.onRevert((res: any) => {
    console.log('撤回一条消息', res);
    messages.value = messages.value.filter((el: any) => el.msgId !== res.msgId);
    // 到最底部
    nextTick(() => {
      messageDisplayRef.value.scrollTop = messageDisplayRef.value.scrollHeight
    })
  })

  // 绑定滚动事件
  messageDisplayRef.value.addEventListener('scroll', handleScroll)

  initNotice()

  // 焦点事件. 
  window.addEventListener('blur', () => {
    if (focusState.value === 1) {
      focusState.value = 2; // 页面从获取焦点 -> 失去焦点 
    }
  })
  // 焦点事件. 
  window.addEventListener('focus', async () => {
    const now = dayjs().unix();
    if (lastFocusTime.value === 0) {
      lastFocusTime.value = now;
    }
    lastFocusTime.value = dayjs().unix();

    if (focusState.value === 0) {
      focusState.value = 1; // 页面获取焦点
    }
    if (focusState.value === 2) {
      focusState.value = 1; // 页面从失去焦点 -> 获取焦点 
      if (hasUnReadMessage.value) {
        throttledSendMessageRead(); // 发送已读消息
      }

      // 检查WebSocket连接状态并重连
      if (wsClient && !wsClient.isConnected()) {
        console.log('WebSocket disconnected, attempting to reconnect...');
        try {
          await wsClient.reconnect();
          console.log('WebSocket reconnected successfully');
        } catch (error) {
          console.error('WebSocket reconnection failed:', error);
          // 如果重连失败，可以在这里添加重试逻辑或显示提示
          showFailToast('网络连接已断开，请刷新页面重试');
        }
      }
    }
  })
  // 任意点击事件.  
  window.addEventListener('click', () => {
    if (hasUnReadMessage.value) {
      throttledSendMessageRead(); // 发送已读消息
    }
  })
  // 任意触摸事件.  
  window.addEventListener('touch', () => {
    if (hasUnReadMessage.value) {
      throttledSendMessageRead(); // 发送已读消息
    }
  })
})


// 每隔1s检测ws状态，app端切后台检测不到，如果离线则直接刷新页面
var interval = setInterval(() => {
  if (wsClient && !wsClient.isConnected()) {
    console.log('WebSocket disconnected, attempting to reconnect...');
  }
}, 1000);

// 每隔5s拉一下最近10条消息，同步展示. 
var msgInterval = setInterval(async () => {
  isLoadAll.value = false
  await getMsg()
}, 10000);

// 已读消息判定方式: 只要用户停留在页面上，即认为已读. 
// 判定方式如下:
// 1. 页面重新加载. 
// 2. 滚动事件
// 3. 页面失去焦点后，重新获取焦点.  
const initMessageReadStatus = (isInit) => {
  let ok = false;
  if (isInit) {
    ok = true;
  }
}

const throttledSendMessageRead = throttle(
  async () => {
    if (!hasUnReadMessage.value) {
      return;
    }
    await wsClient.sendReadEvent({ msgId: readMessageId.value });
    hasUnReadMessage.value = false; // 重置未读状态
  },
  200,
  {
    leading: true, // 立即执行第一次点击
    trailing: false // 不执行最后一次点击的延迟回调
  }
)

onUnmounted(() => {
  // 解绑事件
  messageDisplayRef.value?.removeEventListener('scroll', handleScroll)
})

// 表情列表
const emojiList = [
  '😀', '😃', '😄', '😁', '😆', '😅', '😂', '🤣', '😊', '😇',
  '🙂', '🙃', '😉', '😌', '😍', '🥰', '😘', '😗', '😙', '😚',
  '😋', '😛', '😝', '😜', '🤪', '🤨', '🧐', '🤓', '😎', '🤩',
  '🥳', '😏', '😒', '😞', '😔', '😟', '😕', '🙁', '☹️', '😣',
  '😖', '😫', '😩', '🥺', '😢', '😭', '😤', '😠', '😡', '🤬',
  '🤯', '😳', '🥵', '🥶', '😱', '😨', '😰', '😥', '😓', '🤗',
  '🤔', '🤭', '🤫', '🤥', '😶', '😐', '😑', '😬', '🙄', '😯',
  '😦', '😧', '😮', '😲', '🥱', '😴', '🤤', '😪', '😵', '🤐',
  '🥴', '🤢', '🤮', '🤧', '😷', '🤒', '🤕', '🤑', '🤠', '💩'
]

// 在 setup 中添加
const showMap = ref(false)
const selectedLocation = ref<any>(null)

const triggerMapSelect = () => {
  showMap.value = true
  selectedLocation.value = null
}

const handleLocationSelect = async (location: any) => {
  // 发送位置消息
  const params = {
    msgType: 'location',
    content: {
      lat: location.lat,
      lng: location.lng,
      address: location.address
    },
    msgTime: dayjs().unix(),
    guestAvatar,
    isKf: 2,
  }
  messages.value.push(JSON.parse(JSON.stringify(params)))
  params.content = JSON.stringify(params.content)
  await wsClient.sendMessage(JSON.parse(JSON.stringify(params)))
  nextTick(() => {
    if (messageDisplayRef.value) {
      messageDisplayRef.value.scrollTop = messageDisplayRef.value.scrollHeight
    }
  })
  showFunctionPanel.value = false
}

const handleOpenMap = (location: any) => {
  selectedLocation.value = location
  showMap.value = true
}
</script>

<style lang="scss" scoped>
.chatroom-contain {
  height: 100%;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  background: #f5f5f5;
  overflow-y: hidden;
  max-width: 800px; // 限制最大宽度
  margin: 0 auto; // 居中显示
}

/* 消息展示区域 */
.message-display {
  flex: 1;
  padding: 12px;
  // padding-bottom: 120px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 8px;
  background-color: #f5f5f5;

  .time {
    font-size: 12px;
    color: #999;
    text-align: center;
    margin: 8px 0;
  }
}

.message {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  max-width: 80%;
}


.input-min-height {
  min-height: 240px;
}

.message .avatar-and-name {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
}

.message img {
  width: 40px;
  height: 40px;
  border-radius: 4px;
}

.message-content {
  background: #fff;
  padding: 10px 12px;
  border-radius: 4px;
  display: flex;
  flex-direction: column;

  .msg-text {
    font-size: 16px;
    line-height: 1.4;
    color: #333;
    overflow-wrap: anywhere;
  }

  &.location {
    padding: 0;
    background: transparent;
    box-shadow: none;
  }
}

.message.right {
  margin-left: auto;
  flex-direction: row-reverse;
}

.message.right .message-content {
  background: #95ec69;
}

/* 消息输入区域 */
.input-area {
  // position: fixed;
  // bottom: 0;
  // left: 0;
  // right: 0;
  background-color: #f5f5f5;
  border-top: 1px solid #e5e5e5;
  padding: 8px 12px;
  transition: transform 0.3s ease;
  // z-index: 0;

  .input-container {
    max-width: 800px;
    margin: 0 auto;
  }

  &.emoji-picker-visible {
    transform: translateY(-50vh);
  }
}

.input-toolbar {
  display: flex;
  align-items: center;
  gap: 8px;
  background: #f5f5f5;
  padding: 4px 0;
  position: relative;

  .send-button {
    width: 54px;
    height: 32px;
    line-height: 32px;
    text-align: center;
    user-select: none;
    color: #fff;
    background: linear-gradient(90deg, #ff4d4f, #ff7a45);
    border-radius: 4px;
  }
}

.toolbar-icon {
  color: #7f7f7f;
  padding: 8px;
  font-size: 24px;
}

.input-box {
  flex: 1;
  background: #fff;
  border-radius: 4px;
  padding: 8px 12px;

  :deep(.van-field__body) {
    border: none;
    padding: 0;
  }

  :deep(.van-field__control) {
    min-height: 24px;
    max-height: 80px;
    font-size: 16px;
    line-height: 1.4;
    padding: 0;
  }

  :deep(.van-field__word-limit) {
    margin-top: 0;
    padding: 0;
  }

  :deep(.van-field__bottom) {
    padding: 0;
    border: none;
  }
}


.send-btn {
  position: absolute;
  right: 48px;
  bottom: 8px;
  background: #07c160;
  color: #fff;
  padding: 4px 12px;
  border-radius: 4px;
  font-size: 14px;
  cursor: pointer;
  user-select: none;

  &:active {
    opacity: 0.8;
  }
}

.function-panel {
  display: flex;
  gap: 24px;
  padding: 20px 12px;
  background: #f5f5f5;
  border-top: 1px solid #e5e5e5;
}

.function-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
  color: #333;
  font-size: 12px;
  padding: 8px;
  border-radius: 4px;

  &:active {
    background-color: #e5e5e5;
  }

  .van-icon {
    background: #ffffff;
    border-radius: 8px;
    padding: 8px;
  }

  span {
    font-size: 16px;
  }
}

.v3-emoji-picker {
  width: 100%;
  background: #f5f5f5;
  border-top: 1px solid #e5e5e5;
}

/* 顶部公告样式保持不变 */
.top-notice {
  background: linear-gradient(90deg, #ff4d4f, #ff7a45);
  color: #fff;
  font-weight: bold;
  font-size: 14px;
  padding: 10px 0;
  overflow: hidden;
  position: sticky;
  top: 0;
  z-index: 999;

  .scrolling-text {
    display: inline-block;
    white-space: nowrap;
    padding-left: 100%;
    animation: marquee 20s linear infinite;
  }

  @keyframes marquee {
    0% {
      transform: translateX(0%);
    }

    100% {
      transform: translateX(-100%);
    }
  }
}

/* 视频相关样式保持不变 */
.video-contain {
  position: relative;

  .video-box {
    height: 120px;
  }

  .play-icon {
    width: 36px;
    height: 36px;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: #fff;
    font-size: 36px;
    background: #ccc;
    border-radius: 50%;
  }
}

.video-wrapper {
  width: 100%;
  height: 100%;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #000;

  .video-player {
    width: 100%;
    height: 100%;
    object-fit: contain;
  }

  .close-icon {
    position: absolute;
    top: 60px;
    right: 20px;
    font-size: 24px;
    color: #fff;
    background: rgba(0, 0, 0, 0.5);
    border-radius: 50%;
    padding: 8px;
    z-index: 999;
  }
}

.loading-wrapper {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  background: rgba(0, 0, 0, 0.7);
  padding: 20px;
  border-radius: 8px;

  .loading-text {
    color: #fff;
    font-size: 14px;
  }
}

.emoji-picker-wrapper {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  background: #f5f5f5;
  border-top: 1px solid #e5e5e5;
  z-index: 1000;
  display: flex;
  flex-direction: column;
  max-height: 50vh;

  .emoji-picker-content {
    display: grid;
    grid-template-columns: repeat(7, 1fr);
    gap: 12px;
    padding: 16px;
    padding-bottom: 60px;
    overflow-y: auto;
    overflow-x: hidden;
    flex: 1;

    .emoji-item {
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 28px;
      padding: 12px;
      cursor: pointer;
      border-radius: 4px;

      &:active {
        background-color: #e5e5e5;
      }
    }
  }

  .emoji-picker-footer {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    padding: 8px 16px;
    background: #fff;
    border-top: 1px solid #e5e5e5;
    z-index: 1001;

    .emoji-actions {
      max-width: 800px;
      margin: 0 auto;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0 16px;

      .delete-btn {
        font-size: 28px;
        color: #666;
        padding: 8px;
        cursor: pointer;
        width: 44px;
        height: 44px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 4px;
        background: #f5f5f5;

        &:active {
          opacity: 0.8;
          background: #e5e5e5;
        }
      }

      .send-btn {
        background: #07c160;
        color: #fff;
        padding: 8px 24px;
        border-radius: 4px;
        font-size: 14px;
        cursor: pointer;
        user-select: none;
        height: 44px;
        display: flex;
        align-items: center;
        justify-content: center;

        &:active {
          opacity: 0.8;
        }
      }
    }
  }
}
</style>