// 存储用户登录状态
import { CurrentUser } from "../models/user";

const id = location.pathname.split('/')[2]



let currentUser: CurrentUser;


const setCurrentUserStates = (user: CurrentUser) => {
    currentUser = user
    localStorage.setItem(`currentUser_${id}`, JSON.stringify(user))
}

const getCurrentUserStates = (): CurrentUser => {
    if (currentUser == null) {
        const user = localStorage.getItem(`currentUser_${id}`)
        if (user) {
            currentUser = JSON.parse(user)
        }
    }
    return currentUser
}

export {
    setCurrentUserStates,
    getCurrentUserStates
}