package ffmpeg

import (
	"fmt"
	"os/exec"
)

// GetVideoThumb fp filepath 文件地址
// 返回视频缩略图的路径
func GetVideoThumb(fp string, thumbPath string) error {
	err := exec.Command("ffmpeg", "-i", fp, "-vframes", "1", "-q:v", "2", thumbPath).Run()
	if err != nil {
		fmt.Println(err)
		return err
	}
	return nil
}
