package version

var (
	Version = "20260624.a-1"
)
