package ipinfo

import (
	"strings"
)

// UserAgentInfo 存储解析后的 User-Agent 信息
type UserAgentInfo struct {
	SystemType  string `json:"systemType"`
	DeviceType  string `json:"deviceType"`
	BrowserType string `json:"browserType"`
}

// ParseUserAgent 解析 User-Agent 字符串
func ParseUserAgent(userAgent string) UserAgentInfo {
	ua := strings.ToLower(userAgent)
	info := UserAgentInfo{
		SystemType:  "-",
		DeviceType:  "-",
		BrowserType: "-",
	}

	// 解析系统类型
	switch {
	case strings.Contains(ua, "windows"):
		info.SystemType = "Windows"
	case strings.Contains(ua, "android"):
		info.SystemType = "安卓 (Android)"
	case strings.Contains(ua, "iphone") || strings.Contains(ua, "ipad"):
		info.SystemType = "iPhone (iOS)"
	case strings.Contains(ua, "mac os x"):
		info.SystemType = "苹果电脑"
	}

	// 解析设备类型
	if strings.Contains(ua, "mobile") || strings.Contains(ua, "android") || strings.Contains(
		ua,
		"iphone",
	) || strings.Contains(ua, "ipad") {
		info.DeviceType = "手机"
	} else {
		info.DeviceType = "电脑"
	}

	// 解析浏览器类型
	switch {
	case strings.Contains(ua, "micromessenger"):
		info.BrowserType = "微信扫码"
	case strings.Contains(ua, "chrome"):
		info.BrowserType = "Chrome"
	case strings.Contains(ua, "firefox"):
		info.BrowserType = "Firefox"
	case strings.Contains(ua, "safari") && !strings.Contains(ua, "chrome"):
		info.BrowserType = "Safari"
	case strings.Contains(ua, "msie") || strings.Contains(ua, "trident"):
		info.BrowserType = "IE"
	case strings.Contains(ua, "edge"):
		info.BrowserType = "Edge"
	default:
		info.BrowserType = "其他"
	}

	return info
}
