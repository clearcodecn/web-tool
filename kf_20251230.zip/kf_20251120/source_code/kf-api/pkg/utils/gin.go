package utils

import (
	"net"
	"strings"

	"github.com/gin-gonic/gin"
)

func ClientIP(ctx *gin.Context) string {
	if ip := ctx.Request.Header.Get("CF-Connecting-IP"); ip != "" {
		return parseIP(ip)
	}
	if ip := ctx.Request.Header.Get("X-Forwarded-For"); ip != "" {
		return parseIP(ip)
	}
	ip, _, _ := net.SplitHostPort(strings.TrimSpace(ctx.Request.RemoteAddr))
	if ip == "::1" {
		return "127.0.0.1"
	}
	return ip
}

func parseIP(ip string) string {
	if strings.Contains(ip, ",") {
		arr := strings.Split(ip, ",")
		return strings.TrimSpace(arr[0])
	}
	return ip
}
