package domaincheck

import (
	"context"

	"smartkf.top/smart-kf/kf-api/config"
	xlogger "smartkf.top/smart-kf/kf-api/pkg/log"
)

type DomainStatusWechat int8

// 1正常, 2拦截(域名被封), 3-检测失败,4-拦截(非微信官方链接，需跳转访问)
const (
	DomainStatusOK       DomainStatusWechat = 1
	DomainStatusBanned   DomainStatusWechat = 2 // 被封
	DomainStatusFailed   DomainStatusWechat = 3
	DomainStatusRedirect DomainStatusWechat = 4 // 非微信官方链接，需跳转访问
)

func (s DomainStatusWechat) Banned() bool {
	return s == DomainStatusBanned
}

func (s DomainStatusWechat) Redirect() bool {
	return s == DomainStatusRedirect
}

type DomainCheck interface {
	CheckDomain(ctx context.Context, domain []string) (map[string]DomainStatusWechat, error)
}

func NewDomainCheck() DomainCheck {
	typ := config.GetConfig().DomainCheck.DomainCheckType
	switch typ {
	case "mock":
		return &MockCheck{}
	}
	panic("do not implement")
}

func BatchCheckDomain(ctx context.Context, domain []string) (map[string]DomainStatusWechat, error) {
	var (
		ret  = make(map[string]DomainStatusWechat)
		size = 10
	)
	for {
		var check = domain
		if len(domain) >= size {
			check = domain[:size]
			domain = domain[size:]
		}
		if len(check) == 0 {
			break
		}
		res, err := NewDomainCheck().CheckDomain(ctx, check)
		if err != nil {
			xlogger.Error(ctx, "域名检测失败", xlogger.Err(err))
			continue
		}
		for k, v := range res {
			ret[k] = v
		}
		if len(check) < size {
			break
		}
	}
	return ret, nil
}
