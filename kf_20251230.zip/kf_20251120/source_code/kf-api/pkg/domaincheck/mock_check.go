package domaincheck

import (
	"context"
)

type MockCheck struct {
	apiKey string
}

type MockCheckResponse struct {
	ErrorCode int                           `json:"error_code"`
	Error     string                        `json:"error"`
	Data      map[string]DomainStatusWechat `json:"data"`
}

func (c *MockCheck) CheckDomain(ctx context.Context, domain []string) (map[string]DomainStatusWechat, error) {
	var ret = make(map[string]DomainStatusWechat)
	for _, d := range domain {
		ret[d] = DomainStatusOK
	}
	return ret, nil
}
