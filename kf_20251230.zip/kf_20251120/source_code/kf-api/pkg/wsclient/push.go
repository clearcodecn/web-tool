package wsclient

import (
	"context"
	"encoding/json"

	"smartkf.top/smart-kf/kf-api/config"
	"smartkf.top/smart-kf/kf-api/internal/domain/dto"
	"smartkf.top/smart-kf/kf-api/pkg/httpclient"
)

type PushMessageRequest struct {
	SessionId  string   `json:"sessionId"`
	SessionIds []string `json:"sessionIds"`
	Event      string   `json:"event"`
	Data       string   `json:"data"`
}

type PushMessageResponse struct {
	SuccessSessionIds []string `json:"successSessionIds"`
}

type WsClient struct{}

func (WsClient) Push(ctx context.Context, event string, message *dto.Message, sessionIds ...string) ([]string, error) {
	url := config.GetConfig().HttpClient.SocketServerClient + "/api/push"
	msg := PushMessageRequest{
		Event: event,
	}
	if len(sessionIds) == 1 {
		msg.SessionId = sessionIds[0]
	} else {
		msg.SessionIds = sessionIds
	}

	msgBody, _ := json.Marshal(message)
	msg.Data = string(msgBody)

	var out PushMessageResponse

	err := httpclient.Post(ctx, url, msg, &out)
	if err != nil {
		return nil, err
	}
	return out.SuccessSessionIds, nil
}

type DisConnectRequest struct {
	Sid []string `json:"sid"`
}

func (WsClient) DisConnect(ctx context.Context, sessionIds ...string) error {
	url := config.GetConfig().HttpClient.SocketServerClient + "/api/disconnect"
	msg := DisConnectRequest{
		Sid: sessionIds,
	}
	var out = make(map[string]interface{})
	err := httpclient.Post(ctx, url, msg, &out)
	if err != nil {
		return err
	}
	return nil
}

type CheckOnlineParams struct {
	SessionIds []string `json:"session_ids"`
}

func (WsClient) CheckSessions(ctx context.Context, sessionIds ...string) ([]string, error) {
	url := config.GetConfig().HttpClient.SocketServerClient + "/api/check"
	msg := CheckOnlineParams{
		SessionIds: sessionIds,
	}
	var out []string
	err := httpclient.Post(ctx, url, msg, &out)
	if err != nil {
		return nil, err
	}
	return out, nil
}
