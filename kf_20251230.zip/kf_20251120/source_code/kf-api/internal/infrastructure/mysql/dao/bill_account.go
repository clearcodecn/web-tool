package dao

import "gorm.io/gorm"

const (
	BillAccountStatusActive   = 1 // 正常
	BillAccountStatusDisabled = 2 // 禁用
)

type BillAccount struct {
	gorm.Model

	Username string `gorm:"column:username;unique;type:varchar(255)"`
	Password string `gorm:"column:password;type:varchar(255)"`
	Role     string `gorm:"column:role;type:varchar(255)"` // 角色: admin / seller
	Code     string `gorm:"column:code;type:varchar(255)"` // 账号分销编码
	Status   int    `gorm:"column:status;type:int(11)"`    // 状态: 1正常，2禁用
}

func (BillAccount) TableName() string {
	return "bill_account"
}

func (acc *BillAccount) IsAdmin() bool {
	return acc.Role == "admin"
}
