package dao

import (
	"gorm.io/gorm"

	"smartkf.top/smart-kf/kf-api/internal/interfaces/common"
)

// KFMessage 消息
type KFMessage struct {
	gorm.Model
	MsgId   string             `gorm:"column:msg_id;index"`
	MsgType common.MessageType `gorm:"column:msg_type;type:varchar(128)" json:"type"` // 消息类型
	GuestId string             `gorm:"column:guest_id;index" json:"guestId"`                // 客服id
	CardId  string             `gorm:"column:card_id" json:"cardId"`                  // 卡密id
	Content string             `gorm:"column:content;type:longtext;" json:"content"`  // 内容.
	IsKf    int                `gorm:"column:is_kf;type:tinyint(4)"`                  // 是否是客服
	Status  int                `gorm:"column:status;default(1);"`                     // 消息状态 1:正常 2:已撤回
}

func (KFMessage) TableName() string {
	return "kf_message"
}
