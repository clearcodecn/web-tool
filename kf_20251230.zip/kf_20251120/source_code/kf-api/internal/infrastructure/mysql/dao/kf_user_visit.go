package dao

import (
	"gorm.io/gorm"
)

type KfUserVisit struct {
	gorm.Model
	CardID    string `json:"card_id" gorm:"column:card_id;index"`                   // 卡密id
	UUID      string `json:"uuid" gorm:"column:uuid;index"`                         // 用户uuid
	IP        string `json:"ip" gorm:"column:ip;type:varchar(255)"`                 // 访问IP
	UserAgent string `json:"userAgent" gorm:"column:user_agent;type:varchar(1000)"` // 浏览器信息
	Device    string `json:"device" gorm:"column:device;type:varchar(50)"`          // 设备类型
	Browser   string `json:"browser" gorm:"column:browser;type:varchar(255)"`       // 浏览器类型
	Area      string `json:"area" gorm:"column:area;type:varchar(255)"`             // IP对应的地区
}

func (KfUserVisit) TableName() string {
	return "kf_user_visits"
}
