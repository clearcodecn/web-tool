package dao

import (
	"time"

	"gorm.io/gorm"
)

type BillDomain struct {
	gorm.Model
	TopName      string    `gorm:"column:top_name;type:varchar(255)"`                // 顶级域名
	IsBind       bool      `gorm:"column:is_bind"`                                   // 是否有卡密绑定该域名.
	Status       int       `gorm:"column:status"`                                    // 1:正常，2禁用, 3: 锁定, 4: 出售
	WechatStatus int       `gorm:"column:wechat_status;default(1)"`                  // 域名状态 1正常 2 封禁 3跳转
	IsForTesting bool      `gorm:"column:is_for_testing"`                            // 是否是测试卡密的域名, << 转为测试卡密绑定 >>
	CheckTime    time.Time `gorm:"column:check_time"`                                // 检测时间, 主要用于测试卡密绑定的域名, 绑定后会自动检测域名是否正常.
	Protocol     string    `gorm:"column:protocol;type:varchar(50);default('http')"` // 协议类型, 默认 http
}

func (BillDomain) TableName() string {
	return "bill_domain"
}
