package mysql

import (
	"context"
	"log"
	"sync"

	"github.com/gin-gonic/gin"

	dao2 "smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql/dao"
	xlogger "smartkf.top/smart-kf/kf-api/pkg/log"

	"golang.org/x/crypto/bcrypt"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"

	"smartkf.top/smart-kf/kf-api/config"
)

var (
	o               sync.Once
	_db             *gorm.DB
	buildSqliteFunc func() (*gorm.DB, error)
)

func Load() *gorm.DB {
	o.Do(
		func() {
			conf := config.GetConfig()
			var (
				db  *gorm.DB
				err error
			)
			switch conf.DB.Driver {
			// 服务器编译慢，不支持他了.
			case "sqlite":
				if buildSqliteFunc == nil {
					panic(`sqlite is not support, please use -tag sqlite to build`)
				} else {
					db, err = buildSqliteFunc()
				}
			case "mysql":
				db, err = gorm.Open(mysql.Open(conf.DB.Dsn), &gorm.Config{})
			default:
				log.Fatal("database driver not set")
			}

			if err != nil {
				log.Fatal("初始化db失败")
				return
			}
			_db = db

			db.Use(xlogger.NewLoggerPlugin())

			syncTable(_db)

			go initBillAccounts()
		},
	)

	return _db
}

func syncTable(db *gorm.DB) {
	if err := db.AutoMigrate(
		&dao2.BillAccount{},
		&dao2.KFCard{},
		&dao2.BillLog{},
		&dao2.KFLog{},
		&dao2.KFSettings{},
		&dao2.Orders{},
		&dao2.KFMessage{},
		&dao2.KfUser{},
		&dao2.KFQRCodeDomain{},
		&dao2.BillDomain{},
		&dao2.KfFile{},
		&dao2.KfWelcomeMessage{},
		&dao2.BillSetting{},
		&dao2.DomainOrder{},
		&dao2.KfUserVisit{},
	); err != nil {
		log.Fatal(err)
	}
}

func DB() *gorm.DB {
	return _db
}

var transactionKey = "ctx-transaction-key"

// Begin 开启事务
func Begin(ctx context.Context) (*gorm.DB, context.Context) {
	if ginCtx, ok := ctx.(*gin.Context); ok {
		ctx = ginCtx.Request.Context()
	}
	db, ok := ctx.Value(transactionKey).(*gorm.DB)
	if !ok {
		db = DB()
		db = db.Begin()
		ctx = context.WithValue(ctx, transactionKey, db)
	}
	return db, ctx
}

func GetDBFromContext(ctx context.Context) *gorm.DB {
	if ginCtx, ok := ctx.(*gin.Context); ok {
		ctx = ginCtx.Request.Context()
	}
	db, ok := ctx.Value(transactionKey).(*gorm.DB)
	if !ok {
		db = DB()
		db = db.WithContext(ctx)
	}
	return db
}

// initBillAccounts 初始化默认计费账号密码
func initBillAccounts() {
	accs := config.GetConfig().BillAccount
	for _, acc := range accs {
		billDao := &dao2.BillAccount{
			Username: acc.Username,
			Password: acc.Password,
			Role:     acc.Role,
		}
		pass, _ := bcrypt.GenerateFromPassword([]byte(billDao.Password), bcrypt.DefaultCost)
		billDao.Password = string(pass)
		db := DB()
		var dbAcc dao2.BillAccount
		db.Where("username = ?", billDao.Username).First(&dbAcc)
		if dbAcc.ID == 0 {
			db.Create(billDao)
		} else {
			db.Save(billDao)
		}
	}
}
