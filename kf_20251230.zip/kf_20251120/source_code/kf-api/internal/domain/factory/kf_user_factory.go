package factory

import (
	"errors"
	"fmt"
	"regexp"
	"strconv"
	"strings"

	"github.com/google/uuid"

	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql/dao"
	"smartkf.top/smart-kf/kf-api/pkg/utils"
)

func FactoryNewKfUser(cardMainId int64, cardId string, ip string) *dao.KfUser {
	uid := strings.ReplaceAll(uuid.New().String(), "-", "")
	token := fmt.Sprintf("%d|%s", cardMainId, uid)
	nickName := utils.GetRandomNickname()
	user := dao.KfUser{
		CardID:     cardId,
		UUID:       token,
		Avatar:     utils.RandomAvatar(),
		NickName:   nickName, // 生成随机名称.
		RemarkName: "",
		Mobile:     "",
		Comments:   "",
		IP:         "127.0.0.1", // 先写死
		Area:       "四川成都电信",    // 先写死
		OfflineAt:  0,
		Device:     "Iphone",
		IsProxy:    0,
		Source:     "",
	}
	return &user
}

func FactoryParseUserToken(token string) (cardMainId int64, err error) {
	arr := strings.Split(token, "|")
	if len(arr) != 2 {
		return 0, errors.New("wrong token parts1")
	}
	cardMainId, err = strconv.ParseInt(arr[0], 10, 64)
	if err != nil {
		return 0, err
	}
	return
}

func parseUserAgent(ua string) (string, string, string, bool, bool) {
	// 定义正则表达式
	iosRegex := regexp.MustCompile(`iPhone; CPU iPhone OS ([\d_]+)`)
	androidRegex := regexp.MustCompile(`Android.*; ([^;]+)`)
	emulatorRegex := regexp.MustCompile(`(sdk|emulator|Genymotion)`)

	var deviceType, brand, iosVersion string
	isEmulator := false
	isWeChat := false

	if iosMatches := iosRegex.FindStringSubmatch(ua); len(iosMatches) > 1 {
		deviceType = "iPhone"
		iosVersion = strings.ReplaceAll(iosMatches[1], "_", ".") // 将版本中的下划线替换为点
	} else if androidMatches := androidRegex.FindStringSubmatch(ua); len(androidMatches) > 1 {
		deviceType = "Android"
		brand = strings.TrimSpace(androidMatches[1])
	}

	if emulatorRegex.MatchString(ua) {
		isEmulator = true
	}

	// 检查是否为微信浏览器
	if strings.Contains(ua, "MicroMessenger") {
		isWeChat = true
	}

	return deviceType, brand, iosVersion, isEmulator, isWeChat
}
