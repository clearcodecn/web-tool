package repository

import (
	"context"
	"errors"
	"fmt"
	"math/rand"
	"net/url"
	"strings"
	"time"

	"gorm.io/gorm"
	"gorm.io/gorm/clause"

	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql"
	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql/dao"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/common"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/common/constant"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/cron/billlog"
	xlogger "smartkf.top/smart-kf/kf-api/pkg/log"
	"smartkf.top/smart-kf/kf-api/pkg/utils"
	"smartkf.top/smart-kf/kf-api/pkg/xerrors"
)

type BillDomainRepository struct {
}

func (r *BillDomainRepository) FindByTopName(ctx context.Context, topName []string) ([]*dao.BillDomain, error) {
	tx := mysql.DB()
	var (
		domains []*dao.BillDomain
	)
	err := tx.Model(&dao.BillDomain{}).Where("top_name in ?", topName).Find(&domains).Error
	if err != nil {
		return nil, err
	}
	return domains, nil
}

func (r *BillDomainRepository) FindByID(ctx context.Context, id int64) (*dao.BillDomain, bool, error) {
	tx := mysql.DB()

	var domain dao.BillDomain
	err := tx.Where("id = ?", id).First(&domain).Error

	if err != nil {
		if err == gorm.ErrRecordNotFound {
			return nil, false, nil
		}
		return nil, false, err
	}

	return &domain, true, nil
}

type ListDomainOption struct {
	*common.PageRequest
	Status       int
	DomainStatus []int
	IsBind       bool
}

func (r *BillDomainRepository) List(ctx context.Context, options *ListDomainOption) ([]*dao.BillDomain, int64, error) {
	tx := mysql.GetDBFromContext(ctx)
	if options.IsBind {
		tx = tx.Where("is_bind = ?", options.IsBind)
	}
	if options.Status != 0 {
		tx = tx.Where("status = ?", options.Status)
	}
	return common.Paginate[*dao.BillDomain](tx, options.PageRequest)
}

func (r *BillDomainRepository) DeleteByID(ctx context.Context, id int64) error {
	tx := mysql.GetDBFromContext(ctx)
	return tx.Where("id = ?", id).Delete(&dao.BillDomain{}).Error
}

func (r *BillDomainRepository) FindFirstPublic(ctx context.Context, notBind bool) (*dao.BillDomain, bool, error) {
	tx := mysql.GetDBFromContext(ctx)
	var domain dao.BillDomain
	if notBind {
		tx = tx.Where("is_bind = ?", false)
	}
	err := tx.Where("status = ? and is_for_testing = ?", constant.DomainStatusNormal, false).First(&domain).Error
	if err != nil {
		return nil, false, err
	}
	return &domain, true, nil
}

func (r *BillDomainRepository) FindDifferentTopName(ctx context.Context, topName []string) (
	*dao.BillDomain, bool,
	error,
) {
	tx := mysql.GetDBFromContext(ctx)
	var domain dao.BillDomain
	tx = tx.Where("is_bind = ?", false)
	if len(topName) > 0 {
		for _, top := range topName {
			tx = tx.Where("top_name not like ?", "%"+top+"%")
		}
	}
	err := tx.Where("status = ? and is_for_testing = ?", constant.DomainStatusNormal, false).First(&domain).Error
	if err != nil {
		if err == gorm.ErrRecordNotFound {
			return nil, false, nil
		}
		return nil, false, err
	}
	return &domain, true, nil
}

func (r *BillDomainRepository) FindFirstTesting(ctx context.Context) (*dao.BillDomain, bool, error) {
	tx := mysql.GetDBFromContext(ctx)
	var domains []*dao.BillDomain
	err := tx.Where("status = ? and is_for_testing = ?", constant.DomainStatusNormal, true).Find(&domains).Error
	if err != nil {
		return nil, false, err
	}
	if len(domains) > 0 {
		// 随机返回一个
		return domains[rand.Intn(len(domains))], true, nil
	}
	return nil, false, errors.New("not foudn domain")
}

func (r *BillDomainRepository) CountPrivateDomain(ctx context.Context, notBind bool) (int64, error) {
	var cnt int64
	tx := mysql.GetDBFromContext(ctx)
	if notBind {
		tx = tx.Where("is_bind = ?", false)
	}
	err := tx.Model(&dao.BillDomain{}).Where(
		"status = ? and is_for_testing = ?",
		constant.DomainStatusNormal,
		false,
	).Count(&cnt).Error
	if err != nil {
		return 0, err
	}
	return cnt, nil
}

func (r *BillDomainRepository) LockOnePrivateDomain(ctx context.Context, notBind bool) (*dao.BillDomain, bool, error) {
	var (
		domain dao.BillDomain
	)
	tx := mysql.GetDBFromContext(ctx)
	if notBind {
		tx = tx.Where("is_bind = ?", false)
	}
	err := tx.Model(&dao.BillDomain{}).Clauses(clause.Locking{Strength: "UPDATE"}).
		Where(
			"status = ? and is_for_testing = ?",
			constant.DomainStatusNormal,
			false,
		).First(&domain).Error
	if err != nil {
		if err == gorm.ErrRecordNotFound {
			return nil, false, nil
		}
		return nil, false, err
	}
	return &domain, true, nil
}

func (r *BillDomainRepository) Update(ctx context.Context, domain *dao.BillDomain) error {
	tx := mysql.GetDBFromContext(ctx)
	err := tx.Model(&dao.BillDomain{}).Where("id = ?", domain.ID).Save(domain).Error
	return err
}

func (r *BillDomainRepository) AssignDomain(ctx context.Context, acc dao.BillAccount, card *dao.KFCard) error {
	// 查询当前的的域名.
	var qrcodeDomainRepo QRCodeDomainRepository
	existing, err := qrcodeDomainRepo.FindDomain(ctx, card.CardID)
	if err != nil {
		return err
	}

	var domains []string
	for _, item := range existing {
		// 解析下.
		u, _ := url.Parse(item.Domain)
		if u != nil {
			kp := strings.Split(u.Host, ".")
			if len(kp) >= 2 { // 保留顶级域名
				d := strings.Join(kp[len(kp)-2:], ".")
				domains = append(domains, d)
			}
		}
	}

	domain, exist, err := r.FindDifferentTopName(ctx, domains)
	if err != nil {
		return err
	}
	if !exist {
		domain, exist, err = r.FindFirstPublic(ctx, true)
		if err != nil || !exist {
			return xerrors.NewCustomError("域名库存不足")
		}
	}
	if domain == nil {
		return xerrors.NewCustomError("域名库存不足")
	}

	// 分配公共域名
	qrCodeDomain := dao.KFQRCodeDomain{
		Version:          1,
		ChangeQRCodeTime: time.Now().Unix(),
		Status:           constant.QRCodeNormal,
		Path:             fmt.Sprintf("/s/%v/%s", card.ID, utils.RandomPath()),
		CardID:           card.CardID,
		Domain:           domain.TopName,
		DomainId:         int64(domain.ID),
		IsPrivate:        false,
	}

	tx := mysql.GetDBFromContext(ctx)

	if err := tx.Create(&qrCodeDomain).Error; err != nil {
		xlogger.Error(
			ctx,
			"Create-KFQRCodeDomain failed",
			xlogger.Any("qrCodeDomain", qrCodeDomain),
			xlogger.Err(err),
		)
		return xerrors.NewCustomError("Create-KFQRCodeDomain failed")
	}
	// 设置域名绑定.
	if !domain.IsBind {
		domain.IsBind = true
		if err := tx.Where("id = ?", domain.ID).Select("is_bind").Updates(domain).Error; err != nil {
			xlogger.Error(
				ctx,
				"Create-UpdateDomainBind failed",
				xlogger.Any("domain", domain),
				xlogger.Err(err),
			)
			return xerrors.NewCustomError("Create-UpdateDomainBind failed")
		}
	}
	billlog.AddBillLog(acc.Username, "手动分配域名", "卡密: "+card.CardID+" 分配域名: "+domain.TopName)
	return nil
}

func (r *BillDomainRepository) BatchUpdateWechatStatus(ctx context.Context, topName []string, status int) error {
	if len(topName) == 0 {
		return nil
	}
	tx := mysql.GetDBFromContext(ctx)
	err := tx.Model(&dao.BillDomain{}).Where("top_name in ?", topName).Update("wechat_status", status).Error
	if err != nil {
		xlogger.Error(ctx, "BatchUpdateWechatStatus failed", xlogger.Err(err), xlogger.Any("topName", topName))
		return xerrors.NewCustomError("BatchUpdateWechatStatus failed")
	}
	return nil
}

func (r *BillDomainRepository) BatchUpdateCheckTime(ctx context.Context, topName []string, checkTime time.Time) error {
	if len(topName) == 0 {
		return nil
	}
	tx := mysql.GetDBFromContext(ctx)
	err := tx.Model(&dao.BillDomain{}).Where("top_name in ?", topName).Update("check_time", checkTime).Error
	if err != nil {
		xlogger.Error(ctx, "BatchUpdateCheckTime failed", xlogger.Err(err), xlogger.Any("topName", topName))
		return xerrors.NewCustomError("BatchUpdateCheckTime failed")
	}
	return nil
}

func (r *BillDomainRepository) FindAvailableDomain(ctx context.Context, notInDomainIDs []int64) (
	*dao.BillDomain,
	error,
) {
	// 1. 先查找不在范围内的域名.
	var domain dao.BillDomain
	tx := mysql.GetDBFromContext(ctx)
	if len(notInDomainIDs) > 0 {
		tx = tx.Where("id not in ?", notInDomainIDs)
	}
	tx = tx.Where("wechat_status != ? and status = 1", constant.WechatStatusBanned).Order("RAND()")
	tx.First(&domain)

	if domain.ID > 0 {
		return &domain, nil
	}

	// 2. 如果没有找到，则查找所有的域名.
	tx = mysql.GetDBFromContext(ctx)
	tx = tx.Where("wechat_status != ?", constant.WechatStatusBanned).Order("RAND()")
	tx.First(&domain)

	if domain.ID > 0 {
		return &domain, nil
	}

	return nil, fmt.Errorf("域名库存不足")
}
