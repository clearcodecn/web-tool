package repository

import (
	"context"

	"gorm.io/gorm"

	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql"
)

type BaseRepository struct{}

func NewBaseRepository() *BaseRepository {
	return &BaseRepository{}
}

func (b *BaseRepository) getDB(ctx context.Context) *gorm.DB {
	db := mysql.DB()
	return db.WithContext(ctx)
}
