package repository

import (
	"context"
	"time"

	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql"
	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql/dao"
)

type KFUserVisitRepository struct{}

func (r *KFUserVisitRepository) SaveOne(ctx context.Context, visit *dao.KfUserVisit) error {
	tx := mysql.GetDBFromContext(ctx)
	res := tx.Model(&dao.KfUserVisit{})
	if visit.ID > 0 {
		res = res.Where("id = ?", visit.ID)
	}
	res = res.Save(visit)
	if err := res.Error; err != nil {
		return err
	}
	return nil
}

// GetCardVisitCount 获取卡密的访问总量
func (r *KFUserVisitRepository) GetCardVisitCount(ctx context.Context, cardID string) (int64, error) {
	tx := mysql.GetDBFromContext(ctx)
	var count int64
	err := tx.Model(&dao.KfUserVisit{}).
		Where("card_id = ?", cardID).
		Count(&count).Error
	if err != nil {
		return 0, err
	}
	return count, nil
}

// GetCardDailyVisitCount 获取卡密的每日访问量
func (r *KFUserVisitRepository) GetCardDailyVisitCount(ctx context.Context, cardID string, date time.Time) (int64, error) {
	tx := mysql.GetDBFromContext(ctx)
	var count int64
	startOfDay := time.Date(date.Year(), date.Month(), date.Day(), 0, 0, 0, 0, date.Location())
	endOfDay := startOfDay.Add(24 * time.Hour)

	err := tx.Model(&dao.KfUserVisit{}).
		Where("card_id = ? AND created_at >= ? AND created_at < ?", cardID, startOfDay, endOfDay).
		Count(&count).Error
	if err != nil {
		return 0, err
	}
	return count, nil
}
