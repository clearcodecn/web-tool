package repository

import (
	"context"
	"errors"

	"gorm.io/gorm"

	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql/dao"
)

type BillAccountRepository struct {
	BaseRepository
}

func (r *BillAccountRepository) FindOneByUsername(ctx context.Context, username string) (
	*dao.BillAccount,
	bool,
	error,
) {
	tx := r.getDB(ctx)

	var res dao.BillAccount
	if err := tx.Where("username = ?", username).First(&res).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, false, nil
		}
		return nil, false, err
	}

	return &res, true, nil
}

func (r *BillAccountRepository) Save(ctx context.Context, account *dao.BillAccount) error {
	tx := r.getDB(ctx)
	if err := tx.Where("id = ?", account.ID).Save(account).Error; err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return err
		}
		return nil
	}
	return nil
}

func (r *BillAccountRepository) FindByCode(ctx context.Context, sallerCode string) (*dao.BillAccount, error) {
	tx := r.getDB(ctx)

	var res dao.BillAccount
	if err := tx.Where("code = ?", sallerCode).First(&res).Error; err != nil {
		return nil, err
	}

	return &res, nil
}

func (r *BillAccountRepository) List(ctx context.Context, page, pageSize int) ([]*dao.BillAccount, int64, error) {
	tx := r.getDB(ctx)

	var total int64
	if err := tx.Model(&dao.BillAccount{}).Count(&total).Error; err != nil {
		return nil, 0, err
	}

	var accounts []*dao.BillAccount
	if err := tx.Offset((page - 1) * pageSize).Limit(pageSize).Find(&accounts).Error; err != nil {
		return nil, 0, err
	}

	return accounts, total, nil
}
