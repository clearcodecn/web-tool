package repository

import (
	"context"
	"errors"
	"time"

	"gorm.io/gorm"

	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql"
	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql/dao"
	xlogger "smartkf.top/smart-kf/kf-api/pkg/log"
)

type KFMessageRepository struct{}

func (r *KFMessageRepository) SaveOne(ctx context.Context, chat *dao.KFMessage) error {
	tx := mysql.GetDBFromContext(ctx)
	res := tx.Model(&dao.KFMessage{}).Save(chat)
	if err := res.Error; err != nil {
		xlogger.Error(ctx, "SaveOne-failed", xlogger.Err(err))
		return err
	}
	return nil
}

func (r *KFMessageRepository) BatchCreate(ctx context.Context, chat []*dao.KFMessage) error {
	tx := mysql.GetDBFromContext(ctx)
	res := tx.Model(&dao.KFMessage{}).CreateInBatches(chat, len(chat))
	if err := res.Error; err != nil {
		xlogger.Error(ctx, "SaveOne-failed", xlogger.Err(err))
		return err
	}
	return nil
}

type ListMsgOption struct {
	CardID      string
	GuestId     string
	LastMsgTime time.Time
	PageSize    int
}

func (r *KFMessageRepository) List(ctx context.Context, options *ListMsgOption) ([]*dao.KFMessage, error) {
	tx := mysql.GetDBFromContext(ctx).Debug()
	if len(options.CardID) == 0 {
		return nil, errors.New("cardID is required")
	}
	var msgList []*dao.KFMessage

	tx = tx.Where("card_id = ?", options.CardID)
	tx = tx.Where("guest_id = ?", options.GuestId)
	if !options.LastMsgTime.IsZero() {
		tx = tx.Where("created_at < ?", options.LastMsgTime)
	}
	err := tx.
		Order("created_at desc").
		Limit(options.PageSize).
		Find(&msgList).Error

	if err != nil {
		return nil, err
	} // a55a6158-e68e-4635-acc6-cec6fb899f2d
	return msgList, nil
}

func (r *KFMessageRepository) ByIDs(ctx context.Context, cardID string, ids []string) ([]*dao.KFMessage, error) {
	if len(ids) == 0 {
		return nil, nil
	}

	tx := mysql.GetDBFromContext(ctx)
	tx = tx.Where("card_id = ?", cardID)
	tx = tx.Where("msg_id in ?", ids)
	res := make([]*dao.KFMessage, 0)
	result := tx.Select("guest_id,msg_type,content,msg_id,status").Find(&res)
	if result.Error != nil {
		return nil, result.Error
	}
	return res, nil
}

// Revert 撤回
func (r *KFMessageRepository) Revert(ctx context.Context, msgId string) error {
	tx := mysql.GetDBFromContext(ctx)

	// First get the message to be deleted
	var msg dao.KFMessage
	if err := tx.Where("msg_id = ?", msgId).First(&msg).Error; err != nil {
		return err
	}

	// Delete the message
	if err := tx.Where("msg_id = ?", msgId).Delete(&dao.KFMessage{}).Error; err != nil {
		return err
	}

	// Check if this was the last message
	var lastMsg dao.KFMessage
	if err := tx.Where(
		"card_id = ? AND guest_id = ?",
		msg.CardId, msg.GuestId,
	).
		Order("created_at DESC").
		First(&lastMsg).Error; err != nil {
		if err == gorm.ErrRecordNotFound {
			// No previous message, update last_message_id to empty
			if err := tx.Model(&dao.KfUser{}).
				Where("card_id = ? AND uuid = ?", msg.CardId, msg.GuestId).
				Updates(
					map[string]interface{}{
						"last_message_id": "",
						"last_chat_at":    0,
					},
				).Error; err != nil {
				return err
			}
		} else {
			return err
		}
	} else {
		// Update last_message_id to the previous message
		if err := tx.Model(&dao.KfUser{}).
			Where("card_id = ? AND uuid = ?", msg.CardId, msg.GuestId).
			Updates(
				map[string]interface{}{
					"last_message_id": lastMsg.MsgId,
					"last_chat_at":    lastMsg.CreatedAt.Unix(),
				},
			).Error; err != nil {
			return err
		}
	}

	return nil
}

func (r *KFMessageRepository) DeleteByGuestID(ctx context.Context, cardId string, guestId string) error {
	tx := mysql.GetDBFromContext(ctx)
	err := tx.Model(&dao.KFMessage{}).
		Where("card_id = ? and guest_id = ?", cardId, guestId).
		Delete(&dao.KFMessage{}).Error
	if err != nil {
		return err
	}
	return nil
}

// GetCardMessageCount 获取卡密的总消息数
func (r *KFMessageRepository) GetCardMessageCount(ctx context.Context, cardID string) (int64, error) {
	tx := mysql.GetDBFromContext(ctx)
	var count int64
	err := tx.Model(&dao.KFMessage{}).
		Where("card_id = ?", cardID).
		Count(&count).Error
	if err != nil {
		return 0, err
	}
	return count, nil
}

// GetCardDailyMessageCount 获取卡密的每日消息数
func (r *KFMessageRepository) GetCardDailyMessageCount(ctx context.Context, cardID string, date time.Time) (
	int64,
	error,
) {
	tx := mysql.GetDBFromContext(ctx)
	var count int64
	startOfDay := time.Date(date.Year(), date.Month(), date.Day(), 0, 0, 0, 0, date.Location())
	endOfDay := startOfDay.Add(24 * time.Hour)

	err := tx.Model(&dao.KFMessage{}).
		Where("card_id = ? AND created_at >= ? AND created_at < ?", cardID, startOfDay, endOfDay).
		Count(&count).Error
	if err != nil {
		return 0, err
	}
	return count, nil
}
