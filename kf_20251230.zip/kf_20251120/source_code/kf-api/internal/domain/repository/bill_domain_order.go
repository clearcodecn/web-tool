package repository

import (
	"context"

	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql"
	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql/dao"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/common/constant"
)

type BillDomainOrderRepository struct{}

// CreateOne 创建订单
func (r *BillDomainOrderRepository) CreateOne(ctx context.Context, order *dao.DomainOrder) error {
	tx := mysql.GetDBFromContext(ctx)
	if err := tx.Create(order).Error; err != nil {
		return err
	}
	return nil
}

func (r *BillDomainOrderRepository) FindByOrderNo(ctx context.Context, orderNo string) (*dao.DomainOrder, error) {
	tx := mysql.GetDBFromContext(ctx)
	var order dao.DomainOrder
	if err := tx.Where("order_no = ?", orderNo).First(&order).Error; err != nil {
		return nil, err
	}
	return &order, nil
}

func (r *BillDomainOrderRepository) UpdateStatus(ctx context.Context, order *dao.DomainOrder) error {
	tx := mysql.GetDBFromContext(ctx)
	if err := tx.Model(order).Where("id = ?", order.ID).Update("status", order.Status).Error; err != nil {
		return err
	}
	return nil
}

func (r *BillDomainOrderRepository) CheckUnPayedByCardId(ctx context.Context, cardId string) (bool, error) {
	tx := mysql.GetDBFromContext(ctx)
	var cnt int64
	if err := tx.Model(&dao.DomainOrder{}).Where(
		"card_id = ? and status = ?", cardId,
		constant.OrderStatusCreated,
	).Count(&cnt).Error; err != nil {
		return false, err
	}
	if cnt > 0 {
		return true, nil
	}
	return false, nil
}

func (r *BillDomainOrderRepository) List(ctx context.Context, params ListOrderOptions) (
	[]*dao.DomainOrder, int64,
	error,
) {
	var (
		orders []*dao.DomainOrder
		total  int64
	)
	tx := mysql.GetDBFromContext(ctx)
	tx = tx.Model(&dao.DomainOrder{})
	if params.OrderNo != "" {
		tx = tx.Where("order_no = ?", params.OrderNo)
	}
	if params.TradeId != "" {
		tx = tx.Where("trade_id = ?", params.TradeId)
	}
	if params.FromAddress != "" {
		tx = tx.Where("from_address = ?", params.FromAddress)
	}
	if params.ToAddress != "" {
		tx = tx.Where("to_address = ?", params.ToAddress)
	}
	if params.Status != 0 {
		tx = tx.Where("status = ?", params.Status)
	}
	if params.CardId != "" {
		tx = tx.Where("card_id = ?", params.CardId)
	}
	if params.Domain != "" {
		tx = tx.Where("domain = ?", params.Domain)
	}
	if err := tx.Count(&total).Error; err != nil {
		return nil, 0, err
	}
	page := params.GetPage()
	size := params.GetPageSize()

	err := tx.Offset(int((page - 1) * size)).Limit(int(size)).Order("id desc").Find(&orders).Error
	if err != nil {
		return nil, 0, err
	}

	return orders, total, nil
}
