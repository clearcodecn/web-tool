package repository

import (
	"context"
	"database/sql"
	"errors"

	"gorm.io/gorm"

	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql"
	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql/dao"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/common"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/common/constant"
)

type BillOrderRepository struct{}

// CreateOne 创建订单
func (r *BillOrderRepository) CreateOne(ctx context.Context, order *dao.Orders) error {
	tx := mysql.GetDBFromContext(ctx)
	if err := tx.Create(order).Error; err != nil {
		return err
	}
	return nil
}

func (r *BillOrderRepository) UpdateOrder(ctx context.Context, order *dao.Orders) error {
	tx := mysql.GetDBFromContext(ctx)
	version := order.Version
	order.Version++
	if err := tx.Where("id = ? and version = ?", order.ID, version).Updates(order).Error; err != nil {
		return err
	}
	return nil
}

func (r *BillOrderRepository) GetOrderByID(ctx context.Context, id int64) (*dao.Orders, bool, error) {
	tx := mysql.GetDBFromContext(ctx)
	var order dao.Orders
	err := tx.Where("id = ?", id).First(&order).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, false, nil
		}
		return nil, false, err
	}
	return &order, true, nil
}

func (r *BillOrderRepository) GetOrderByOrderNo(ctx context.Context, orderNo string) (*dao.Orders, bool, error) {
	tx := mysql.GetDBFromContext(ctx)
	var order dao.Orders
	err := tx.Where("order_no = ?", orderNo).First(&order).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, false, nil
		}
		return nil, false, err
	}
	return &order, true, nil
}

type ListOrderOptions struct {
	common.PageRequest
	OrderNo     string `json:"orderNo" doc:"订单id"`
	TradeId     string `json:"tradeId" doc:"区块链上交易id"`
	FromAddress string `json:"fromAddress" doc:"客户地址"`
	ToAddress   string `json:"toAddress" doc:"接收地址"`
	Status      int    `json:"status" doc:"1=等待支付,2=支付成功,3=已取消"`
	CardId      string `json:"cardId"`
	Domain      string `json:"domain"`
	SallerId    int64  `json:"saller_id"`
}

func (r *BillOrderRepository) ListOrder(ctx context.Context, req ListOrderOptions) ([]*dao.Orders, int64, error) {
	tx := mysql.GetDBFromContext(ctx)
	if req.FromAddress != "" {
		tx = tx.Where("from_address = ?", req.FromAddress)
	}
	if req.ToAddress != "" {
		tx = tx.Where("to_address = ?", req.ToAddress)
	}
	if req.TradeId != "" {
		tx = tx.Where("trade_id = ?", req.TradeId)
	}
	if req.OrderNo != "" {
		tx = tx.Where("order_no = ?", req.OrderNo)
	}
	if req.Status != 0 {
		tx = tx.Where("status = ?", req.Status)
	}
	if req.SallerId != 0 {
		tx = tx.Where("saller_id = ?", req.SallerId)
	}
	return common.Paginate[*dao.Orders](tx, &req.PageRequest)
}

type CntOptions struct {
	SallerId  int64
	StartTime string
	EndTime   string
}

// 成交订单数量
func (r *BillOrderRepository) CountOrder(ctx context.Context, req CntOptions) int64 {
	tx := mysql.GetDBFromContext(ctx)
	var cnt int64
	// 获取今日开始时间.
	if req.StartTime != "" {
		tx = tx.Where("created_at >= ?", req.StartTime)
	}
	if req.EndTime != "" {
		tx = tx.Where("created_at <= ?", req.StartTime)
	}
	tx = tx.Where("status = ?", constant.OrderStatusPay)
	if req.SallerId != 0 {
		tx = tx.Where("saller_id = ?", req.SallerId)
	}
	tx.Model(&dao.Orders{}).Count(&cnt)
	return cnt
}

// 成交金额
func (r *BillOrderRepository) SumAmount(ctx context.Context, req CntOptions) int64 {
	tx := mysql.GetDBFromContext(ctx)
	var cnt sql.NullInt64
	// 获取今日开始时间.
	if req.StartTime != "" {
		tx = tx.Where("created_at >= ?", req.StartTime)
	}
	if req.EndTime != "" {
		tx = tx.Where("created_at <= ?", req.StartTime)
	}
	tx = tx.Where("status = ?", constant.OrderStatusPay)
	if req.SallerId != 0 {
		tx = tx.Where("saller_id = ?", req.SallerId)
	}
	tx.Model(&dao.Orders{}).Select("sum(price) as cnt").Scan(&cnt)
	return cnt.Int64 / 1e6
}
