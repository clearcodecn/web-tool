package repository

import (
	"context"
	"time"

	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql"
	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql/dao"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/http/vo/kfbackend"
	xlogger "smartkf.top/smart-kf/kf-api/pkg/log"

	"gorm.io/gorm"
)

type KFUserRepository struct{}

func (r *KFUserRepository) SaveOne(ctx context.Context, kfUser *dao.KfUser) error {
	tx := mysql.GetDBFromContext(ctx)
	res := tx.Model(&dao.KfUser{})
	if kfUser.ID > 0 {
		res = res.Where("id = ?", kfUser.ID)
	}
	res = res.Save(kfUser)
	if err := res.Error; err != nil {
		xlogger.Error(ctx, "SaveOne-failed", xlogger.Err(err))
		return err
	}
	return nil
}

func (r *KFUserRepository) IncrScanCount(ctx context.Context, kfUser *dao.KfUser) error {
	tx := mysql.GetDBFromContext(ctx)
	res := tx.Model(&dao.KfUser{})
	if kfUser.ID > 0 {
		res = res.Where("id = ?", kfUser.ID)
	}
	res = res.Where("id = ?", kfUser.ID).Update("scan_count", gorm.Expr("scan_count + ?", 1))
	if err := res.Error; err != nil {
		xlogger.Error(ctx, "SaveOne-failed", xlogger.Err(err))
		return err
	}
	return nil
}

func (r *KFUserRepository) IncrStaySeconds(ctx context.Context, cardId string, guestId string) error {
	tx := mysql.GetDBFromContext(ctx)
	res := tx.Model(&dao.KfUser{})
	res = res.Where("uuid = ? and card_id = ?", guestId, cardId).Update(
		"stay_seconds",
		gorm.Expr("stay_seconds + ?", 2),
	)
	if err := res.Error; err != nil {
		xlogger.Error(ctx, "SaveOne-failed", xlogger.Err(err))
		return err
	}
	return nil
}

func (r *KFUserRepository) FindByToken(ctx context.Context, cardId string, token string) (
	*dao.KfUser, bool, error,
) {
	var (
		kfUser dao.KfUser
		err    error
	)
	tx := mysql.GetDBFromContext(ctx)
	err = tx.Model(&dao.KfUser{}).Where("card_id = ? and uuid = ?", cardId, token).First(&kfUser).Error
	if err != nil {
		if err == gorm.ErrRecordNotFound {
			return nil, false, nil
		}
		xlogger.Error(ctx, "FindByToken-failed", xlogger.Err(err))
		return nil, false, nil
	}
	return &kfUser, true, nil
}

func (r *KFUserRepository) FindByIp(ctx context.Context, cardId string, ip string) (
	*dao.KfUser, bool, error,
) {
	var (
		kfUser dao.KfUser
		err    error
	)
	tx := mysql.GetDBFromContext(ctx)
	err = tx.Model(&dao.KfUser{}).Where("card_id = ? and ip = ?", cardId, ip).First(&kfUser).Error
	if err != nil {
		if err == gorm.ErrRecordNotFound {
			return nil, false, nil
		}
		xlogger.Error(ctx, "FindByToken-failed", xlogger.Err(err))
		return nil, false, nil
	}
	return &kfUser, true, nil
}

type ListUserOption struct {
	CardID    string
	SearchBy  string
	UUids     []string
	Blocked   bool
	ListType  kfbackend.ChatListType
	Page      int
	PageSize  int
	BeginTime int64
	EndTime   int64
}

func (r *KFUserRepository) List(ctx context.Context, options *ListUserOption) ([]*dao.KfUser, int64, error) {
	tx := mysql.GetDBFromContext(ctx)
	tx = tx.Where("card_id = ?", options.CardID)

	// 用户id/昵称/手机号/备注
	if options.SearchBy != "" {
		searchBy := "%" + options.SearchBy + "%"
		tx = tx.Where("remark_name LIKE ? or mobile like ? or nick_name like ?", searchBy, searchBy, searchBy)
	}

	if len(options.UUids) != 0 {
		tx = tx.Where("uuid in ?", options.UUids) // 有未读消息的访客
	}
	if options.Blocked {
		tx = tx.Where("block_at > 0") // 用拉黑时间来判断
	}
	if options.BeginTime > 0 {
		tx = tx.Where("created_at >= ?", options.BeginTime)
	}
	if options.EndTime > 0 {
		tx = tx.Where("created_at <= ?", options.EndTime)
	}
	var (
		res []*dao.KfUser
	)
	var cnt int64
	tx.Model(&dao.KfUser{}).Count(&cnt)

	tx = tx.Order("top_at desc,block_at asc, last_chat_at desc")
	err := tx.Limit(options.PageSize).Offset((options.Page - 1) * options.PageSize).Find(&res).Error
	if err != nil {
		return nil, 0, err
	}
	return res, cnt, nil
}

func (r *KFUserRepository) BatchUpdate(ctx context.Context, ids []string, u dao.KfUser) error {
	tx := mysql.GetDBFromContext(ctx)
	res := tx.Model(&dao.KfUser{}).Where("uuid in ?", ids).Updates(u)
	if err := res.Error; err != nil {
		xlogger.Error(ctx, "BatchUpdate-failed", xlogger.Err(err))
		return err
	}
	return nil
}

func (r *KFUserRepository) Offline(ctx context.Context, id string) error {
	tx := mysql.GetDBFromContext(ctx)
	res := tx.Model(&dao.KfUser{}).Where("uuid = ?", id).Update("offline_at", time.Now().Unix())
	if err := res.Error; err != nil {
		xlogger.Error(ctx, "Offline-failed", xlogger.Err(err))
		return err
	}
	return nil
}

type UpdateColOption struct {
	UUID          string
	LastChatAt    int64
	LastMessageId string
	TopAt         int64
	BlockAt       int64
	ScanCount     int64
	LastMsgReadAt int64 // 最后一次已读消息时间
	IsWs          bool
	IsSendWelcome bool
}

func (r *KFUserRepository) UpdateCol(ctx context.Context, cardID string, opt UpdateColOption) error {
	tx := mysql.GetDBFromContext(ctx)
	tx = tx.Model(&dao.KfUser{}).Where("card_id = ? and uuid = ?", cardID, opt.UUID)
	var updateCols = make(map[string]interface{})
	if opt.LastChatAt > 0 {
		updateCols["last_chat_at"] = opt.LastChatAt
	}
	if opt.LastMessageId != "" {
		updateCols["last_message_id"] = opt.LastMessageId
	}
	if opt.TopAt > 0 {
		updateCols["top_at"] = opt.TopAt
	}
	if opt.BlockAt > 0 {
		updateCols["block_at"] = opt.BlockAt
	}
	if opt.ScanCount > 0 {
		updateCols["scan_count"] = opt.ScanCount
	}
	if opt.LastMsgReadAt > 0 {
		updateCols["last_read_msg_at"] = opt.LastMsgReadAt
	}
	if opt.IsWs {
		updateCols["is_ws"] = true // 标识链接过ws
	}
	if opt.IsSendWelcome {
		updateCols["is_send_welcome"] = true // 标识发送了欢迎语
	}
	if len(updateCols) > 0 {
		return tx.Updates(updateCols).Error
	}

	return nil
}

func (r *KFUserRepository) DeleteUser(ctx context.Context, cardID string, guestId string) error {
	tx := mysql.GetDBFromContext(ctx)
	return tx.Model(&dao.KfUser{}).Where(
		"card_id = ? and uuid = ?", cardID,
		guestId,
	).Delete(&dao.KfUser{}).Error
}

// Find7DaysIncr 查询近7日增长
func (r *KFUserReportRepository) Find7DaysIncr(ctx context.Context, cardId string) ([]dao.KfUserCount, error) {
	var cnts []dao.KfUserCount
	tx := mysql.GetDBFromContext(ctx)
	sql := `SELECT DATE(created_at) AS date,
       COUNT(1)         AS cnt
FROM kf_users
WHERE card_id = ? and stay_seconds > 5 and created_at BETWEEN ? AND ?
GROUP BY DATE(created_at)
ORDER BY date ASC`

	var sevenDayAgo = time.Now().AddDate(0, 0, -6).Format("2006-01-02")
	var now = time.Now().Add(24 * time.Hour).Format("2006-01-02")
	err := tx.Raw(sql, cardId, sevenDayAgo, now).Find(&cnts).
		Error
	if err != nil {
		return nil, err
	}
	return cnts, nil
}

/*
*
有效有效访客
非国内无效访客 代表访问者ip地址非果内
非微信无效访客 代表访问者并非使用微信扫码进入
未WS无效访客 代表访问者通过访问入口，获取到了落地地址并访问，但是并未创建WS聊天的链接至服务器，
此情况最常见的是刷粉者通过脚本批量访问入口获取落地地址并访问，此时非正常打开页面的请求并不会发起WS链接。还有一种情况是目前果内有些地区不允许发起WS链接，发起必封，无药可救。
123.123.123.123注册IP显示本颜色 代表当前卡密中出现了IP前三段相同的访客例如：(8.8.8.8) (8.8.8.9) (8.8.8.10)
123.123.123.123注册IP显示本颜色 代表当前访客IP在系统中出现次数大于9且小于20
123.123.123.123注册IP显示本颜色 代表当前访客IP在系统中出现次数大于20
*/
type FindFansOptions struct {
	CardId    string
	BeginTime time.Time
	EndTime   time.Time
	Ip        []string
	Page      int64
	PageSize  int64
	IsExport  bool
	Status    int
	Platform  string
}

func (r *KFUserReportRepository) FindFans(ctx context.Context, options *FindFansOptions) ([]*dao.KfUser, int64, error) {
	tx := mysql.GetDBFromContext(ctx)
	tx = tx.Model(&dao.KfUser{}).Where("card_id = ?", options.CardId)
	if !options.BeginTime.IsZero() {
		tx = tx.Where("created_at >= ?", options.BeginTime)
	}
	if !options.EndTime.IsZero() {
		tx = tx.Where("created_at <= ?", options.EndTime)
	}
	if len(options.Ip) > 0 {
		tx = tx.Where("ip in ?", options.Ip)
	}

	var users []*dao.KfUser
	if options.IsExport {
		// 导出时不分页
		err := tx.Order("created_at desc").Find(&users).Error
		if err != nil {
			return nil, 0, err
		}
		return users, 0, nil
	} else {
		var cnt int64
		tx.Model(&dao.KfUser{}).Count(&cnt)
		err := tx.Limit(int(options.PageSize)).Offset(int((options.Page - 1) * options.PageSize)).Order("id desc").Find(
			&users,
		).
			Error
		if err != nil {
			return nil, 0, err
		}
		return users, cnt, nil
	}
}

func (r *KFUserReportRepository) SearchIp(ctx context.Context, cardId string, ip []string) (map[string]int64, error) {
	sql := `select ip, count(1) as cnt from kf_users where  card_id = ? and ip in ? group by ip`
	tx := mysql.GetDBFromContext(ctx)

	var res []dao.KfUserIp
	err := tx.Model(&dao.KfUser{}).Raw(sql, cardId, ip).Find(&res).Error
	if err != nil {
		return nil, err
	}

	var resMap = make(map[string]int64)
	for _, item := range res {
		resMap[item.Ip] = item.Cnt
	}
	return resMap, nil
}
