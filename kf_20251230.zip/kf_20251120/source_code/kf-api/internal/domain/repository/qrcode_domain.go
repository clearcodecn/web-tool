package repository

import (
	"context"

	"gorm.io/gorm"

	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql"
	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql/dao"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/common/constant"
)

type QRCodeDomainRepository struct{}

// FindByPath TODO:: cache
func (r *QRCodeDomainRepository) FindByPath(ctx context.Context, path string) (*dao.KFQRCodeDomain, bool, error) {
	tx := mysql.GetDBFromContext(ctx)
	var data dao.KFQRCodeDomain
	if err := tx.Where("path = ?", path).First(&data).Error; err != nil {
		if err == gorm.ErrRecordNotFound {
			return nil, false, nil
		}
		return nil, false, err
	}
	return &data, true, nil
}

// FindByCardID TODO:: cache
func (r *QRCodeDomainRepository) FindByCardID(ctx context.Context, cardID string) (*dao.KFQRCodeDomain, bool, error) {
	tx := mysql.GetDBFromContext(ctx)
	var data dao.KFQRCodeDomain
	if err := tx.Where("card_id = ?", cardID).Order("version desc").First(&data).Error; err != nil {
		if err == gorm.ErrRecordNotFound {
			return nil, false, nil
		}
		return nil, false, err
	}
	return &data, true, nil
}

// FindByCardID
func (r *QRCodeDomainRepository) FindByIdAndCardID(ctx context.Context, id int64, cardID string) (
	*dao.KFQRCodeDomain, bool,
	error,
) {
	tx := mysql.GetDBFromContext(ctx)
	var data dao.KFQRCodeDomain
	if err := tx.Where("id = ? and card_id = ?", id, cardID).First(&data).Error; err != nil {
		if err == gorm.ErrRecordNotFound {
			return nil, false, nil
		}
		return nil, false, err
	}
	return &data, true, nil
}

// FindDomain
func (r *QRCodeDomainRepository) FindDomain(ctx context.Context, cardId string) ([]*dao.KFQRCodeDomain, error) {
	tx := mysql.GetDBFromContext(ctx)
	var data []*dao.KFQRCodeDomain
	sql := `SELECT *
FROM (SELECT *,
             ROW_NUMBER() OVER (PARTITION BY domain ORDER BY version DESC) AS rn
      FROM kf_qrcode_domain where card_id = ? and deleted_at is null order by created_at desc) sub
WHERE rn = 1;`
	tx.Raw(sql, cardId).Find(&data)
	return data, nil
}

// FindDomain
func (r *QRCodeDomainRepository) FindDomainIdGroupBy(ctx context.Context, cardId string) (
	[]*dao.KFQRCodeDomain,
	error,
) {
	tx := mysql.GetDBFromContext(ctx)
	var data []*dao.KFQRCodeDomain
	err := tx.Where("card_id = ?", cardId).Group("domain_id").Select("domain_id").Find(&data).Error
	if err != nil {
		return nil, err
	}
	return data, nil
}

// CreateOne
func (r *QRCodeDomainRepository) CreateOne(ctx context.Context, qrCode *dao.KFQRCodeDomain) error {
	tx := mysql.GetDBFromContext(ctx)
	if err := tx.Create(qrCode).Error; err != nil {
		return err
	}
	return nil
}

func (r *QRCodeDomainRepository) DisableOld(ctx context.Context, cardId string, domain string, notId int64) error {
	tx := mysql.GetDBFromContext(ctx)
	if err := tx.Model(&dao.KFQRCodeDomain{}).Where(
		"card_id = ? and domain = ? and id != ?", cardId, domain,
		notId,
	).Update(
		"status",
		constant.QRCodeDisable,
	).Error; err != nil {
		return err
	}
	return nil
}

func (r *QRCodeDomainRepository) UpdateStatus(ctx context.Context, cardId string, id int64, status int) error {
	tx := mysql.GetDBFromContext(ctx)
	if err := tx.Model(&dao.KFQRCodeDomain{}).Where("card_id = ? and id = ?", cardId, id).Update(
		"status",
		status,
	).Error; err != nil {
		return err
	}
	return nil
}

func (r *QRCodeDomainRepository) UpdateCardId(ctx context.Context, oldCardId string, newCardId string) error {
	tx := mysql.GetDBFromContext(ctx)
	return tx.Model(&dao.KFCard{}).Where("card_id = ?", oldCardId).UpdateColumn("card_id", newCardId).Error
}

func (r *QRCodeDomainRepository) FindCardQrCodeDomain(ctx context.Context, cards []string) (
	[]*dao.KFQRCodeDomain,
	error,
) {
	var res []*dao.KFQRCodeDomain
	tx := mysql.GetDBFromContext(ctx)

	if len(cards) == 0 {
		return nil, nil
	}
	err := tx.Where("card_id in ?", cards).Find(&res).Error
	if err != nil {
		return nil, err
	}
	return res, err
}

func (r *QRCodeDomainRepository) BatchUpdateWechatStatus(ctx context.Context, domainId []int64, status int) error {
	tx := mysql.GetDBFromContext(ctx)
	if len(domainId) == 0 {
		return nil
	}
	err := tx.Model(&dao.KFQRCodeDomain{}).Where("domain_id in ?", domainId).Update("wechat_status", status).Error
	if err != nil {
		return err
	}
	return nil
}

func (r *QRCodeDomainRepository) DeleteByDomain(ctx context.Context, domainId int64, cardId string) error {
	tx := mysql.GetDBFromContext(ctx)
	if err := tx.Where(
		"domain_id = ? and card_id = ?",
		domainId,
		cardId,
	).Delete(&dao.KFQRCodeDomain{}).Error; err != nil {
		return err
	}
	return nil

}
