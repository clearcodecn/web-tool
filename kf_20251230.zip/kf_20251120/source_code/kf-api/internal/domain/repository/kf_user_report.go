package repository

import (
	"context"
	"time"

	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql"
	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql/dao"
)

type KFUserReportRepository struct{}

type ListUserReportOption struct {
	CardID   string
	SearchBy string
	StartAt  time.Time
	EndAt    time.Time
	Page     int
	PageSize int
}

func (r *KFUserReportRepository) List(ctx context.Context, options *ListUserReportOption) ([]*dao.KfUser, int64, error) {
	tx := mysql.GetDBFromContext(ctx)
	tx = tx.Model(&dao.KfUser{}).Where("card_id = ?", options.CardID)

	// 用户id/昵称/手机号/备注
	if options.SearchBy != "" {
		searchBy := "%" + options.SearchBy + "%"
		tx = tx.Where("remark_name LIKE ? or mobile like ? or uuid like ?", searchBy, searchBy, searchBy)
	}

	// 时间范围
	if !options.StartAt.IsZero() {
		tx = tx.Where("created_at >= ?", options.StartAt)
	}
	if !options.EndAt.IsZero() {
		tx = tx.Where("created_at <= ?", options.EndAt)
	}

	// 获取总数
	var total int64
	if err := tx.Count(&total).Error; err != nil {
		return nil, 0, err
	}

	// 获取分页数据
	var users []*dao.KfUser
	err := tx.Order("created_at desc").
		Limit(options.PageSize).
		Offset((options.Page - 1) * options.PageSize).
		Find(&users).Error

	if err != nil {
		return nil, 0, err
	}

	return users, total, nil
}

// GetDailyNewUserCount 获取每日新增用户数
func (r *KFUserReportRepository) GetDailyNewUserCount(ctx context.Context, cardID string, date time.Time) (int64, error) {
	tx := mysql.GetDBFromContext(ctx)
	var count int64
	startOfDay := time.Date(date.Year(), date.Month(), date.Day(), 0, 0, 0, 0, date.Location())
	endOfDay := startOfDay.Add(24 * time.Hour)

	err := tx.Model(&dao.KfUser{}).
		Where("card_id = ? AND created_at >= ? AND created_at < ?", cardID, startOfDay, endOfDay).
		Count(&count).Error

	return count, err
}

// GetDailyScanCount 获取每日扫码总次数
func (r *KFUserReportRepository) GetDailyScanCount(ctx context.Context, cardID string, date time.Time) (int64, error) {
	tx := mysql.GetDBFromContext(ctx)
	var count int64
	startOfDay := time.Date(date.Year(), date.Month(), date.Day(), 0, 0, 0, 0, date.Location())
	endOfDay := startOfDay.Add(24 * time.Hour)

	err := tx.Model(&dao.KfUser{}).
		Where("card_id = ? AND created_at >= ? AND created_at < ?", cardID, startOfDay, endOfDay).
		Select("COALESCE(SUM(scan_count), 0)").
		Scan(&count).Error

	return count, err
}
