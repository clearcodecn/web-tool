package caches

import (
	"context"
	"fmt"
	"time"

	"smartkf.top/smart-kf/kf-api/internal/infrastructure/redis"
	xlogger "smartkf.top/smart-kf/kf-api/pkg/log"
)

type kfAuthCache struct{}

func (c *kfAuthCache) getKey(token string) string {
	return fmt.Sprintf("kfbe_auth.%s", token)
}

func (c *kfAuthCache) getFrontKey(token string) string {
	return fmt.Sprintf("kfbe_fe_auth.%s", token)
}

func (c *kfAuthCache) SetBackendToken(ctx context.Context, token string, cardId string) error {
	redisClient := redis.GetRedisClient()
	err := redisClient.Set(ctx, c.getKey(token), cardId, time.Hour*24).Err()
	if err != nil {
		return err
	}
	return nil
}

func (c *kfAuthCache) GetBackendToken(ctx context.Context, token string) (string, error) {
	redisClient := redis.GetRedisClient()
	res, err := redisClient.Get(ctx, c.getKey(token)).Result()
	if err != nil {
		xlogger.Error(
			ctx,
			"token not found in cache",
			xlogger.Any("token", token), xlogger.Err(err),
		)
		return "", fmt.Errorf("token not found")
	}
	return res, nil
}

func (c *kfAuthCache) SetFrontToken(ctx context.Context, token string, cardId string) error {
	redisClient := redis.GetRedisClient()
	err := redisClient.Set(ctx, c.getFrontKey(token), cardId, time.Hour*24).Err()
	if err != nil {
		return err
	}
	return nil
}

func (c *kfAuthCache) GetFrontToken(ctx context.Context, token string) (string, error) {
	redisClient := redis.GetRedisClient()
	res, err := redisClient.Get(ctx, c.getFrontKey(token)).Result()
	if res == "" {
		xlogger.Error(
			ctx,
			"fetoken not found in cache",
			xlogger.Any("token", token), xlogger.Err(err),
		)
		return "", fmt.Errorf("token not found")
	}
	return res, nil
}

func (c *kfAuthCache) DelFrontToken(ctx context.Context, token string) {
	redisClient := redis.GetRedisClient()
	redisClient.Del(ctx, c.getFrontKey(token)).Result()
}
