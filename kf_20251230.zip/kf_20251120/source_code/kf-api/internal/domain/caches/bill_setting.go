package caches

import (
	"context"
	"encoding/json"
	"time"

	redis2 "github.com/redis/go-redis/v9"

	"smartkf.top/smart-kf/kf-api/internal/domain/repository"
	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql/dao"
	"smartkf.top/smart-kf/kf-api/internal/infrastructure/redis"
)

type BillSettingCache struct {
}

func (c *BillSettingCache) GetNotice() dao.Notice {
	ctx := context.Background()
	setting := c.GetSetting(ctx)
	if setting == nil {
		return dao.Notice{}
	}
	return setting.Notice
}

func (c *BillSettingCache) GetDomainPrice() int {
	ctx := context.Background()
	setting := c.GetSetting(ctx)
	if setting == nil {
		return 0
	}
	return setting.DomainPrice
}

func (c BillSettingCache) GetTestingCardMinute() int {
	ctx := context.Background()
	setting := c.GetSetting(ctx)
	if setting == nil {
		return 15
	}
	return setting.TestingCardMinute
}

func (s *BillSettingCache) OneDayCardPrice() float64 {
	ctx := context.Background()
	setting := s.GetSetting(ctx)
	if setting == nil {
		return 0
	}
	return setting.DailyPackage.Price
}

func (c *BillSettingCache) GetSetting(ctx context.Context) *dao.BillSettingModel {
	cli := redis.GetRedisClient()
	data, err := cli.Get(ctx, "bill_setting").Bytes()
	if err != nil {
		if err == redis2.Nil {
			var repo repository.BillSettingRepository
			setting, err := repo.GetSetting(ctx)
			if err != nil {
				return nil
			}
			settingBytes, err := json.Marshal(setting)
			if err != nil {
				return nil
			}
			cli.SetEx(ctx, "bill_setting", settingBytes, time.Hour*24)
			data = settingBytes
		}
	}

	var setting dao.BillSettingModel
	err = json.Unmarshal(data, &setting)
	if err != nil {
		return nil
	}
	return &setting
}

func (BillSettingCache) DeleteCache(ctx context.Context) {
	cli := redis.GetRedisClient()
	cli.Del(ctx, "bill_setting")
}
