package caches

import (
	"sync"

	"smartkf.top/smart-kf/kf-api/internal/infrastructure/redis"
)

var (
	BillSettingCacheInstance       *BillSettingCache
	cacheOnce                      = sync.Once{}
	CaptchaCacheInstance           *CaptchaCache
	KfCardCacheInstance            *kfCardCacheInstance
	UserUnReadCacheInstance        *userUnReadCache
	UserOnLineCacheInstance        *userOnLineCache
	ImSessionCacheInstance         *imSessionCache
	KfUserCacheInstance            *kfUserCache
	KfAuthCacheInstance            *kfAuthCache
	IdAtomicCacheInstance          *idAtomicCache
	KfSettingCache                 *kfSettingCache
	WelcomeMessageCacheInstance    *WelcomeMessageCache
	KfUserOnfflineMessagesInstance *KfUserOnfflineMessages
)

func InitCacheInstances() {
	cacheOnce.Do(
		func() {
			BillSettingCacheInstance = &BillSettingCache{}
			CaptchaCacheInstance = NewCaptchaCache(redis.GetRedisClient())
			KfCardCacheInstance = &kfCardCacheInstance{}
			UserUnReadCacheInstance = &userUnReadCache{}
			UserOnLineCacheInstance = &userOnLineCache{}
			ImSessionCacheInstance = &imSessionCache{}
			KfUserCacheInstance = &kfUserCache{}
			KfAuthCacheInstance = &kfAuthCache{}
			IdAtomicCacheInstance = &idAtomicCache{}
			KfSettingCache = &kfSettingCache{}
			WelcomeMessageCacheInstance = &WelcomeMessageCache{}
			KfUserOnfflineMessagesInstance = &KfUserOnfflineMessages{}
		},
	)
}
