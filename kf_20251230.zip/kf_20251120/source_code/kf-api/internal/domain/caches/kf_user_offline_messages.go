package caches

import (
	"context"
	"fmt"
	"time"

	"smartkf.top/smart-kf/kf-api/internal/infrastructure/redis"
)

const (
	kfUserOfflineMessagesKey = "offline.%s.%s"
)

type KfUserOnfflineMessages struct{}

func (KfUserOnfflineMessages) getKey(cardId string, guestId string) string {
	return fmt.Sprintf(kfUserOfflineMessagesKey, cardId, guestId)
}

func (m *KfUserOnfflineMessages) AddOffLineMessage(ctx context.Context, cardId string, guestId string, msgId string) {
	cli := redis.GetRedisClient()
	n, _ := cli.LLen(ctx, m.getKey(cardId, guestId)).Result()
	if n >= 99 {
		return
	}
	redis.GetRedisClient().LPush(ctx, m.getKey(cardId, guestId), msgId)
	// 设置过期时间 为 10min
	cli.Expire(ctx, m.getKey(cardId, guestId), 10*time.Minute)
}

func (m *KfUserOnfflineMessages) GetAll(ctx context.Context, cardId string, guestId string) []string {
	res, _ := redis.GetRedisClient().LRange(ctx, m.getKey(cardId, guestId), 0, -1).Result()
	redis.GetRedisClient().Del(ctx, m.getKey(cardId, guestId))
	return res
}
