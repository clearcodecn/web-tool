package caches

import (
	"context"
	"errors"
	"fmt"
	"math/rand"
	"strconv"
	"time"

	"smartkf.top/smart-kf/kf-api/internal/infrastructure/redis"
)

const (
	idKey = "atomic.id"
)

type idAtomicCache struct{}

// GetOneId 全局自增id. 不管什么业务都可以直接用于主键.
func (c *idAtomicCache) GetOneId(ctx context.Context) (int64, error) {
	res, err := c.GetManyId(ctx, 1)
	if err != nil {
		return 0, err
	}
	if len(res) > 0 {
		return res[0], err
	}
	return 0, errors.New("getOneId failed")
}

// GetManyId 获取多个全局唯一id
func (c *idAtomicCache) GetManyId(ctx context.Context, n int) ([]int64, error) {
	cli := redis.GetRedisClient()
	result, err := cli.IncrBy(ctx, idKey, int64(n)).Result()
	if err != nil {
		return nil, err
	}
	var res = make([]int64, 0, n)
	for i := result - int64(n); i <= result; i++ {
		res = append(res, i)
	}
	return res, nil
}

// GetBizId 获取唯一主键id，参考PHP uniqid实现
// [microtime][rand4][atomicId]
func (c *idAtomicCache) GetBizId(ctx context.Context) (int64, error) {
	gid, err := c.GetOneId(ctx)
	if err != nil {
		return 0, err
	}
	// 获取微秒时间戳的最后8位
	micro := time.Now().UnixMicro() % 100000000
	// 生成4位随机数
	randNum := rand.Intn(9000) + 1000
	// 组合：微秒时间戳(8位) + 随机数(4位) + 原子计数器(8位)
	// 确保总长度不超过19位，避免int64溢出
	atomicId := gid % 100000000 // 限制原子计数器为8位
	x, _ := strconv.Atoi(fmt.Sprintf("%d%d%d", micro, randNum, atomicId))
	return int64(x), nil
}

func (c *idAtomicCache) GetBizIds(ctx context.Context, n int) ([]int64, error) {
	gids, err := c.GetManyId(ctx, n)
	if err != nil {
		return nil, err
	}
	for index, val := range gids {
		micro := time.Now().UnixMicro() % 100000000
		randNum := rand.Intn(9000) + 1000
		atomicId := val % 100000000
		x, _ := strconv.Atoi(fmt.Sprintf("%d%d%d", micro, randNum, atomicId))
		gids[index] = int64(x)
	}
	return gids, nil
}

func (c *idAtomicCache) GetCardMainId(ctx context.Context, n int) ([]int64, error) {
	gids, err := c.GetManyId(ctx, n)
	if err != nil {
		return nil, err
	}
	for index, val := range gids {
		x, _ := strconv.Atoi(fmt.Sprintf("%d", val))
		gids[index] = int64(x)
	}
	return gids, nil
}
