package card

import (
	"context"
	"fmt"
	"strings"
	"time"

	repository2 "smartkf.top/smart-kf/kf-api/internal/domain/repository"
	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql"
	dao2 "smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql/dao"
	constant2 "smartkf.top/smart-kf/kf-api/internal/interfaces/common/constant"
	xlogger "smartkf.top/smart-kf/kf-api/pkg/log"

	"smartkf.top/smart-kf/kf-api/pkg/utils"
	"smartkf.top/smart-kf/kf-api/pkg/xerrors"
)

func SellOneCard(ctx context.Context, card *dao2.KFCard) error {
	tx := mysql.GetDBFromContext(ctx)
	card.SaleStatus = constant2.SaleStatusSold

	var cardRepo repository2.KFCardRepository
	if err := cardRepo.UpdateOne(ctx, card); err != nil {
		xlogger.Error(ctx, "UpdateOne failed", xlogger.Err(err))
		return xerrors.NewCustomError("UpdateOne failed")
	}

	var (
		domainRepo repository2.BillDomainRepository
		domain     *dao2.BillDomain
		err        error
	)
	domain, err = domainRepo.FindAvailableDomain(ctx, nil)
	if err != nil {
		return xerrors.NewCustomError("域名数量不足")
	}
	topName := domain.TopName
	topName = strings.TrimPrefix(topName, "http://")
	topName = strings.TrimPrefix(topName, "https://")
	topName = domain.Protocol + "://" + topName

	// 分配公共域名
	qrCodeDomain := dao2.KFQRCodeDomain{
		Version:          1,
		ChangeQRCodeTime: time.Now().Unix(),
		Status:           constant2.QRCodeNormal,
		Path:             fmt.Sprintf("/s/%v/%s", card.ID, utils.RandomPath()),
		CardID:           card.CardID,
		Domain:           topName,
		DomainId:         int64(domain.ID),
		IsPrivate:        false,
		WechatStatus:     1,
		Protocol:         domain.Protocol,
	}

	if err := tx.Create(&qrCodeDomain).Error; err != nil {
		xlogger.Error(
			ctx,
			"Create-KFQRCodeDomain failed",
			xlogger.Any("qrCodeDomain", qrCodeDomain),
			xlogger.Err(err),
		)
		return xerrors.NewCustomError("Create-KFQRCodeDomain failed")
	}
	// 分配默认系统配置.
	kfSetting := dao2.NewDefaultKFSettings(card.CardID)
	if err := tx.Create(&kfSetting).Error; err != nil {
		xlogger.Error(
			ctx,
			"Create-KFSetting failed",
			xlogger.Err(err),
			xlogger.Any("setting", kfSetting),
		)
		return xerrors.NewCustomError("Create-KFSetting failed")
	}

	return nil
}
