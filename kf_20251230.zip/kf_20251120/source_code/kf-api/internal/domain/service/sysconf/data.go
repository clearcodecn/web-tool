package sysconf

import (
	"context"

	"github.com/samber/lo"

	caches2 "smartkf.top/smart-kf/kf-api/internal/domain/caches"
	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql"
	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql/dao"
)

type SystemConfService struct{}

func (s *SystemConfService) DeleteAll(ctx context.Context, cardID string) error {
	tx, ctx := mysql.Begin(ctx)
	defer func() {
		tx.Rollback()
	}()

	if err := s.DeleteChat(ctx, cardID); err != nil {
		return err
	}
	if err := s.DeleteUser(ctx, cardID); err != nil {
		return err
	}
	if err := s.DeleteChat(ctx, cardID); err != nil {
		return err
	}
	if err := s.delWelcomeMsg(ctx, cardID); err != nil {
		return err
	}
	tx.Model(&dao.KFLog{}).Where("card_id = ?", cardID).Delete(&dao.KFLog{})
	tx.Commit()
	return nil
}

func (SystemConfService) DeleteUser(ctx context.Context, cardID string) error {
	tx := mysql.GetDBFromContext(ctx)

	batch := 100
	for {
		var users []dao.KfUser
		err := tx.Model(&dao.KfUser{}).Select("uuid").Where("card_id = ?", cardID).Order("id asc").Limit(batch).Find(
			&users,
		).
			Error
		if err != nil {
			return err
		}
		var uuids []string
		lo.ForEach(
			users, func(item dao.KfUser, index int) {
				uuids = append(uuids, item.UUID)
			},
		)
		err = tx.Model(&dao.KfUser{}).Where("card_id = ? and uuid in ?", cardID, uuids).Delete(&dao.KFMessage{}).Error
		if err != nil {
			return err
		}
		// redis token
		for _, user := range uuids {
			caches2.KfUserCacheInstance.DelDBUserCache(ctx, cardID, user)
			caches2.KfAuthCacheInstance.DelFrontToken(ctx, user)
		}

		caches2.ImSessionCacheInstance.DeleteAll(ctx, cardID)

		if len(users) < batch {
			break
		}
	}

	tx.Model(&dao.KfUserVisit{}).Where("card_id = ?", cardID).Delete(&dao.KfUserVisit{})
	return nil
}

func (s *SystemConfService) DeleteChat(ctx context.Context, cardID string) error {
	tx := mysql.GetDBFromContext(ctx)
	err := tx.Model(&dao.KFMessage{}).Where("card_id = ?", cardID).Delete(&dao.KFMessage{}).Error
	if err != nil {
		return err
	}
	return nil
}

func (s *SystemConfService) delWelcomeMsg(ctx context.Context, cardID string) error {
	tx := mysql.GetDBFromContext(ctx)
	caches2.WelcomeMessageCacheInstance.DeleteCache(ctx, cardID)
	err := tx.Model(&dao.KfWelcomeMessage{}).Where("card_id = ?", cardID).Delete(&dao.KfWelcomeMessage{}).Error
	if err != nil {
		return err
	}
	return nil
}
