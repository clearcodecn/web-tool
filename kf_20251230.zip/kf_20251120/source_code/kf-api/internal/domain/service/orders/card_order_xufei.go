package orders

import (
	"context"
	"fmt"
	"time"

	"smartkf.top/smart-kf/kf-api/internal/domain/caches"
	"smartkf.top/smart-kf/kf-api/internal/domain/repository"
	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/common/constant"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/cron/kflog"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/http/vo/kfbackend"
	"smartkf.top/smart-kf/kf-api/pkg/xerrors"
)

type XufeiService struct{}

func (s *XufeiService) Handle(ctx context.Context, req *kfbackend.XufeiRequest, ip string) (int64, error) {
	// 1. 查询新卡密.
	var repo repository.KFCardRepository
	newCard, ok, err := repo.FindByCardID(ctx, req.NewCardID)
	if err != nil {
		return 0, err
	}
	if !ok {
		return 0, xerrors.NewCustomError("新卡密不存在")
	}
	if newCard.LastLoginTime != 0 {
		return 0, xerrors.NewCustomError("新卡密已被使用, 无法续费")
	}
	if newCard.SaleStatus != constant.SaleStatusSold {
		return 0, xerrors.NewCustomError("旧卡密不存在,请重试")
	}
	if newCard.ExpireTime > 0 {
		return 0, xerrors.NewCustomError("新卡密已过期")
	}
	if newCard.CardType != constant.CardTypeNormal {
		return 0, xerrors.NewCustomError("卡密类型错误")
	}
	
	// 2. 查询旧卡密.
	oldCard, ok, err := repo.FindByCardID(ctx, req.CardID)
	if err != nil {
		return 0, err
	}
	if !ok {
		return 0, xerrors.NewCustomError("旧卡密不存在")
	}

	if oldCard.SaleStatus != constant.SaleStatusSold {
		return 0, xerrors.NewCustomError("旧卡密不存在,请重试")
	}
	if oldCard.CardType != constant.CardTypeNormal {
		return 0, xerrors.NewCustomError("旧卡密类型错误")
	}

	now := time.Now().Unix()
	if oldCard.HasExpire() {
		oldCard.ExpireTime = now
	}
	oldCard.ExpireTime += int64(newCard.Day * 86400)

	tx, newCtx := mysql.Begin(ctx)

	// 设置新卡过期.
	newCard.ExpireTime = now
	if err := repo.UpdateOne(newCtx, oldCard); err != nil {
		return 0, err
	}
	if err := repo.UpdateOne(newCtx, newCard); err != nil {
		return 0, err
	}
	caches.KfCardCacheInstance.Delete(newCtx, oldCard.CardID)
	caches.KfCardCacheInstance.Delete(newCtx, newCard.CardID)

	// 查询新卡密的域名，设置到旧卡密.
	var qrcodeDomainRepo repository.QRCodeDomainRepository
	qrcodeDomainRepo.UpdateCardId(newCtx, oldCard.CardID, newCard.CardID)

	tx.Commit()

	kflog.AddKFLog(oldCard.CardID, "续费", fmt.Sprintf("使用卡密: %s 续费%d天", newCard.CardID, newCard.Day), ip)
	return oldCard.ExpireTime, nil
}
