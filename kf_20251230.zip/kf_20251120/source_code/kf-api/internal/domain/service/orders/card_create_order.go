package orders

import (
	"context"
	"fmt"
	"time"

	"gorm.io/gorm"

	"smartkf.top/smart-kf/kf-api/internal/domain/caches"
	"smartkf.top/smart-kf/kf-api/internal/domain/repository"
	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql"
	dao2 "smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql/dao"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/common/constant"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/http/vo/billfrontend"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/nsq/producer"
	xlogger "smartkf.top/smart-kf/kf-api/pkg/log"

	"smartkf.top/smart-kf/kf-api/config"
	sdk "smartkf.top/smart-kf/kf-api/pkg/usdtpayment"
	"smartkf.top/smart-kf/kf-api/pkg/xerrors"
)

type KfCardOrderService struct{}

func (KfCardOrderService) CreateOrder(reqCtx context.Context, ipAddress string, req *billfrontend.CreateOrderRequest) (
	*billfrontend.CreateOrderResponse, error,
) {
	setting := caches.BillSettingCacheInstance.GetSetting(reqCtx)
	var cardPackage dao2.Package
	if req.PackageId == setting.DailyPackage.Id {
		cardPackage = setting.DailyPackage
	}
	if req.PackageId == setting.WeeklyPackage.Id {
		cardPackage = setting.WeeklyPackage
	}
	if req.PackageId == setting.MonthlyPackage.Id {
		cardPackage = setting.MonthlyPackage
	}
	if cardPackage.Id == "" {
		return nil, xerrors.NewCustomError("套餐不存在")
	}

	tx, reqCtx := mysql.Begin(reqCtx)
	defer tx.Rollback()

	var orderRepository repository.BillOrderRepository
	orderNo, err := caches.IdAtomicCacheInstance.GetBizId(reqCtx)
	if err != nil {
		return nil, xerrors.NewCustomError("系统错误")
	}
	no := fmt.Sprintf("N%d", orderNo)
	var orderExpireDelay = int64(setting.Payment.Expire * 60)
	var orderExpireTime = time.Now().UnixMicro() + orderExpireDelay*1000 // 使用毫秒.

	client := sdk.NewUsdtPaymentClient(setting.Payment.PayUrl, setting.Payment.Token, 30*time.Second)

	// 1. 创建订单.
	var order = dao2.Orders{
		Model: gorm.Model{
			ID: uint(orderNo),
		},
		PackageId:   cardPackage.Id,
		PackageDay:  cardPackage.Days,
		OrderNo:     no,
		Price:       int64(cardPackage.Price * 1e6), // 1 后面6个0
		Status:      constant.OrderStatusCreated,    //
		ExpireTime:  orderExpireTime,
		Ip:          ipAddress,
		FromAddress: req.FromAddress,
		SallerCode:  req.SallerCode,
		SallerId:    0,
	}

	// 查询分销商
	if req.SallerCode != "" {
		var accRepo repository.BillAccountRepository
		acc, _ := accRepo.FindByCode(reqCtx, req.SallerCode)
		if acc != nil {
			order.SallerId = int64(acc.ID)
		}
	}

	createOrderResp, err := client.CreateOrder(
		reqCtx, &sdk.CreateOrderRequest{
			AppId:       setting.Payment.AppId,
			OrderId:     no,
			Name:        fmt.Sprintf("客服系统-%d日套餐", cardPackage.Days),
			Amount:      order.Price,
			FromAddress: order.FromAddress,
			Expire:      int(orderExpireDelay),
		},
	)

	if err != nil {
		xlogger.Error(reqCtx, "orderCreateOne-usdtpayment-CreateOrder-失败:"+no, xlogger.Err(err))
		return nil, err
	}
	order.TradeId = createOrderResp.TradeId
	if err := orderRepository.CreateOne(reqCtx, &order); err != nil {
		xlogger.Error(reqCtx, "orderCreateOne-失败:"+no, xlogger.Err(err))
		return nil, err
	}

	var (
		topic = config.GetConfig().NSQ.OrderExpireTopic
	)

	if err := producer.NSQProducer.DeferredPublish(
		topic, time.Duration(orderExpireDelay)*time.Second,
		[]byte(order.OrderNo),
	); err != nil {
		xlogger.Error(reqCtx, "createOrder-DeferredPublish-失败:"+no, xlogger.Err(err))
		return nil, err
	}

	// 3. 返回订单号.
	if err := tx.Commit().Error; err != nil {
		xlogger.Error(reqCtx, "createOrder-Commit-失败:"+no, xlogger.Err(err))
		return nil, err
	}

	return &billfrontend.CreateOrderResponse{
		PaymentUrl: createOrderResp.PayUrl,
		OrderNo:    order.OrderNo,
	}, nil
}
