package orders

import (
	"context"
	"fmt"
	"time"

	"smartkf.top/smart-kf/kf-api/internal/domain/caches"
	repository2 "smartkf.top/smart-kf/kf-api/internal/domain/repository"
	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql"
	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql/dao"
	constant2 "smartkf.top/smart-kf/kf-api/internal/interfaces/common/constant"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/http/vo/billfront"
	xlogger "smartkf.top/smart-kf/kf-api/pkg/log"

	"smartkf.top/smart-kf/kf-api/pkg/utils"
	"smartkf.top/smart-kf/kf-api/pkg/xerrors"
)

func DomainOrderNotify(ctx context.Context, req *billfront.OrderNotifyRequest) error {
	tx, ctx := mysql.Begin(ctx)
	defer tx.Rollback()

	var orderRepo repository2.BillDomainOrderRepository
	order, err := orderRepo.FindByOrderNo(ctx, req.OrderId)
	if err != nil {
		return err
	}
	// 如果订单状态是已支付, 则不处理
	if order.Status == constant2.OrderStatusPay {
		return nil
	}

	if req.Status == 3 {
		// 失败
		order.Status = constant2.OrderStatusCancel
		order.ConfirmTime = time.Now().Unix()
		if err := tx.Where("id = ?", order.ID).Select(
			"status",
			"confirm_time",
		).Updates(order).Error; err != nil {
			xlogger.Error(ctx, "UpdateOrder failed", xlogger.Any("order", order), xlogger.Err(err))
			return nil
		}
		xlogger.Info(ctx, "收到订单失败回调", xlogger.Any("req", req))
		tx.Commit()
		return nil
	}

	order.TradeId = req.TradeId
	order.ConfirmTime = req.Timestamp
	order.Status = constant2.OrderStatusPay
	order.ToAddress = req.Address

	err = tx.Model(order).Where("id = ?", order.ID).Updates(
		map[string]interface{}{
			"status":       order.Status,
			"confirm_time": order.ConfirmTime,
			"trade_id":     order.TradeId,
			"to_address":   order.ToAddress,
		},
	).Error

	if err != nil {
		return err
	}

	// 分配域名.
	var domainRepo repository2.BillDomainRepository
	domain, ok, err := domainRepo.FindByID(ctx, int64(order.DomainId))
	if err != nil {
		return err
	}
	if !ok {
		xlogger.Error(ctx, "域名不存在", xlogger.Any("orderNo", req.OrderId))
		return nil
	}
	domain.Status = constant2.DomainStatusSOld
	domain.IsBind = true
	if err := domainRepo.Update(ctx, domain); err != nil {
		xlogger.Error(ctx, "更新域名失败", xlogger.Any("orderNo", req.OrderId), xlogger.Err(err))
		return nil
	}

	kfcard, err := caches.KfCardCacheInstance.GetCardByID(ctx, order.CardID)
	if err != nil {
		return err
	}

	// 插入域名表.
	// 分配公共域名
	qrCodeDomain := dao.KFQRCodeDomain{
		Version:          1,
		ChangeQRCodeTime: time.Now().Unix(),
		Status:           constant2.QRCodeNormal,
		Path:             fmt.Sprintf("/s/%v/%s", kfcard.ID, utils.RandomPath()),
		CardID:           order.CardID,
		Domain:           domain.TopName,
		DomainId:         int64(domain.ID),
		IsPrivate:        true,
		Protocol:         domain.Protocol,
	}
	if err := tx.Create(&qrCodeDomain).Error; err != nil {
		xlogger.Error(
			ctx,
			"Create-KFQRCodeDomain failed",
			xlogger.Any("qrCodeDomain", qrCodeDomain),
			xlogger.Err(err),
		)
		return xerrors.NewCustomError("Create-KFQRCodeDomain failed")
	}

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}
