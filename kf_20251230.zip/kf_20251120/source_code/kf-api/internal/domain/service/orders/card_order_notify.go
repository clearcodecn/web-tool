package orders

import (
	"context"
	"errors"
	"time"

	"gorm.io/gorm"

	"smartkf.top/smart-kf/kf-api/internal/domain/caches"
	repository2 "smartkf.top/smart-kf/kf-api/internal/domain/repository"
	card2 "smartkf.top/smart-kf/kf-api/internal/domain/service/card"
	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql"
	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql/dao"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/common/constant"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/cron/billlog"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/http/vo/billfront"
	xlogger "smartkf.top/smart-kf/kf-api/pkg/log"
	"smartkf.top/smart-kf/kf-api/pkg/utils"
)

func CardOrderNotify(reqCtx context.Context, req *billfront.OrderNotifyRequest) error {
	tx, reqCtx := mysql.Begin(reqCtx)
	defer tx.Rollback()

	var orderRepository repository2.BillOrderRepository
	order, ok, err := orderRepository.GetOrderByOrderNo(reqCtx, req.OrderId)
	if err != nil {
		xlogger.Error(reqCtx, "查询订单失败", xlogger.Err(err))
		return errors.New("查询订单失败")
	}

	if !ok {
		xlogger.Error(reqCtx, "订单不存在")
		return errors.New("订单不存在")
	}

	// 如果订单状态是已支付, 则不处理
	if order.Status == constant.OrderStatusPay {
		return nil
	}

	if req.Status == 3 {
		// 失败
		order.Status = constant.OrderStatusCancel
		order.ConfirmTime = time.Now().Unix()
		if err := tx.Where("id = ?", order.ID).Select(
			"status",
			"confirm_time",
		).Updates(order).Error; err != nil {
			xlogger.Error(reqCtx, "UpdateOrder failed", xlogger.Any("order", order), xlogger.Err(err))
			return nil
		}
		xlogger.Info(reqCtx, "收到订单失败回调", xlogger.Any("req", req))
		tx.Commit()
		return nil
	}

	order.TradeId = req.TradeId
	order.ConfirmTime = req.Timestamp
	order.Status = constant.OrderStatusPay
	order.ToAddress = req.Address
	// 查询一个卡密分配给他.
	var cardRepo repository2.KFCardRepository
	card, exist, err := cardRepo.FindFirstCardByDay(reqCtx, order.PackageDay)
	if err != nil {
		return err
	}
	if !exist {
		mainIds, err := caches.IdAtomicCacheInstance.GetBizIds(reqCtx, 1)
		if err != nil {
			return err
		}
		// 创建一个卡密:
		card = &dao.KFCard{
			Model: gorm.Model{
				ID: uint(mainIds[0]),
			},
			CardID:      utils.RandomCard(10),
			SaleStatus:  constant.SaleStatusOnSale,
			LoginStatus: constant.LoginStatusUnLogin,
			CardType:    constant.CardTypeNormal,
			Day:         order.PackageDay,
			Price:       float64(order.Price / 1e6),
		}
		err = cardRepo.CreateOne(reqCtx, card)
		if err != nil {
			xlogger.Info(reqCtx, "创建卡密失败", xlogger.Any("req", req))
			return err
		}
	}

	// 更新订单数据
	order.CardID = card.CardID // 卡密id
	card.SallerId = order.SallerId

	if err := tx.Where("id = ?", order.ID).Select(
		"card_id",
		"status",
		"confirm_time",
		"trade_id",
		"pay_usdt_address",
	).Updates(order).Error; err != nil {
		xlogger.Error(reqCtx, "UpdateOrder failed", xlogger.Any("order", order), xlogger.Err(err))
		return err
	}

	if err := card2.SellOneCard(reqCtx, card); err != nil {
		xlogger.Error(reqCtx, "SellOneCard failed", xlogger.Any("card", card), xlogger.Err(err))
		return err
	}
	billlog.AddBillLog("system", "订单", "出售卡密成功: "+card.CardID)

	if err := tx.Commit().Error; err != nil {
		return err
	}

	return nil
}
