package service

import (
	"context"
	"time"

	"smartkf.top/smart-kf/kf-api/internal/domain/repository"
)

// UserReportService 用户报告服务
type UserReportService struct {
	messageRepo    *repository.KFMessageRepository
	userReportRepo *repository.KFUserReportRepository
}

// GetMessageStats 获取消息统计
func (s *UserReportService) GetMessageStats(ctx context.Context, cardID string, date time.Time) (*struct {
	TotalMessageCount int64 `json:"totalMessageCount" doc:"总消息数"`
	DailyMessageCount int64 `json:"dailyMessageCount" doc:"今日消息数"`
	DailyNewUserCount int64 `json:"dailyNewUserCount" doc:"今日新增用户数"`
}, error) {
	totalCount, err := s.messageRepo.GetCardMessageCount(ctx, cardID)
	if err != nil {
		return nil, err
	}

	dailyCount, err := s.messageRepo.GetCardDailyMessageCount(ctx, cardID, date)
	if err != nil {
		return nil, err
	}

	dailyNewUserCount, err := s.userReportRepo.GetDailyNewUserCount(ctx, cardID, date)
	if err != nil {
		return nil, err
	}

	return &struct {
		TotalMessageCount int64 `json:"totalMessageCount" doc:"总消息数"`
		DailyMessageCount int64 `json:"dailyMessageCount" doc:"今日消息数"`
		DailyNewUserCount int64 `json:"dailyNewUserCount" doc:"今日新增用户数"`
	}{
		TotalMessageCount: totalCount,
		DailyMessageCount: dailyCount,
		DailyNewUserCount: dailyNewUserCount,
	}, nil
}
