package im

import (
	"context"

	"smartkf.top/smart-kf/kf-api/internal/domain/dto"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/common/constant"
)

type MessageHandler interface {
	Init(ctx context.Context, msg *dto.Message) error
	Handle(ctx context.Context)
}

func FactoryMessageHandler(eventType string, platform string, msgType string) MessageHandler {
	switch eventType {
	case constant.EventMessage:
		if msgType == constant.MsgTypeRead {
			return &KfReadService{}
		}
		if msgType == constant.MsgTypeKfUserRead {
			return &KfUserReadService{}
		}
		if msgType == constant.MsgTypeSmartReply {
			return &kfUserKeywordService{}
		}
		if platform == constant.PlatformKfBe {
			return &KfMsgToKfUserService{}
		} else {
			return &KfUserMsgToKfService{}
		}
	case constant.EventOnline:
		if platform == constant.PlatformKfFe {
			return &KFUserOnlineService{}
		} else {
			return &KfOnlineService{}
		}
	case constant.EventOffline:
		if platform == constant.PlatformKfFe {
			return &KfUserOfflineService{}
		} else {
			return &KfOfflineService{}
		}
	case constant.EventRevert:
		return &KfRevertService{}
	}

	return nil
}
