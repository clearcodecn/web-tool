package im

import (
	"context"
	"errors"
	"time"

	"smartkf.top/smart-kf/kf-api/internal/domain/caches"
	"smartkf.top/smart-kf/kf-api/internal/domain/dto"
	"smartkf.top/smart-kf/kf-api/internal/domain/repository"
	xlogger "smartkf.top/smart-kf/kf-api/pkg/log"

	"smartkf.top/smart-kf/kf-api/pkg/wsclient"
)

type KfImBaseService struct {
	cardId         string
	guestId        string
	kfSessionId    string
	guestSessionId string
}

func (s *KfImBaseService) setCardIdByGuestId(ctx context.Context) error {
	cardId, err := caches.ImSessionCacheInstance.GetCardIDByKFFEToken(ctx, s.guestId)
	if err != nil {
		xlogger.Error(ctx, "处理消息失败-GetCardIDByToken", xlogger.Err(err))
		return err
	}
	s.cardId = cardId

	if CheckCardExpire(ctx, cardId) {
		s.cleanCard(ctx, cardId)
		return errors.New("卡片已过期")
	}
	return nil
}

func (s *KfImBaseService) setCardIdByBackendToken(ctx context.Context, backendToken string) error {
	cardId, err := caches.KfAuthCacheInstance.GetBackendToken(ctx, backendToken)
	if err != nil {
		xlogger.Error(ctx, "处理消息失败-GetBackendToken", xlogger.Err(err))
		return err
	}
	s.cardId = cardId

	if CheckCardExpire(ctx, cardId) {
		s.cleanCard(ctx, cardId)
		return errors.New("卡片已过期")
	}

	return nil
}

func (s *KfImBaseService) getKfbeSessionIds(ctx context.Context, cardId string) []string {
	sessionIds, err := caches.ImSessionCacheInstance.GetKfbeSessionIds(ctx, cardId)
	if err != nil {
		xlogger.Error(ctx, "处理消息失败-getKfbeSessionIds", xlogger.Err(err))
		return nil
	}
	if len(sessionIds) == 0 {
		return nil
	}
	return sessionIds
}

func (s *KfImBaseService) setKfUserSessionId(ctx context.Context) error {
	sid, err := caches.ImSessionCacheInstance.GetKFFESessionIdByUserId(ctx, s.cardId, s.guestId)
	if err != nil {
		xlogger.Error(ctx, "处理消息失败-getKfbeSessionIds", xlogger.Err(err))
		return err
	}
	s.guestSessionId = sid
	return nil
}

func (s *KfImBaseService) pushMessage(
	ctx context.Context,
	event string,
	message *dto.Message,
	sessionIds ...string,
) []string {
	var pushClient = wsclient.WsClient{}
	if res, err := pushClient.Push(ctx, event, message, sessionIds...); err != nil {
		xlogger.Error(ctx, "pushManyMessage-failed", xlogger.Err(err))
		return nil
	} else {
		xlogger.Info(ctx, "push callback", xlogger.Any("sessionIds", sessionIds))
		return res
	}
}

func (s *KfImBaseService) updateUserLastMessage(ctx context.Context, msgId string) error {
	userRepository := repository.KFUserRepository{}
	// 更新用户信息.
	opt := repository.UpdateColOption{}
	opt.UUID = s.guestId
	opt.LastChatAt = time.Now().Unix()
	opt.LastMessageId = msgId
	err := userRepository.UpdateCol(ctx, s.cardId, opt)
	if err != nil {
		xlogger.Error(ctx, "msgHandler 更新用户信息失败", xlogger.Err(err))
		return err
	}
	return nil
}

func (s *KfImBaseService) cleanCard(ctx context.Context, cardId string) {
	sids, _ := caches.ImSessionCacheInstance.GetKfbeSessionIds(ctx, cardId)
	beSids, _ := caches.ImSessionCacheInstance.GetAllKffeSessionIds(ctx, cardId)
	sids = append(sids, beSids...)
	if len(sids) > 0 {
		var pushClient = wsclient.WsClient{}
		pushClient.DisConnect(ctx, sids...)
	}
	caches.ImSessionCacheInstance.DeleteAll(ctx, cardId)
}
