package im

import (
	"context"
	"encoding/json"

	uuid2 "github.com/google/uuid"

	"smartkf.top/smart-kf/kf-api/internal/domain/caches"
	"smartkf.top/smart-kf/kf-api/internal/domain/dto"
	"smartkf.top/smart-kf/kf-api/internal/domain/repository"
	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql/dao"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/common"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/common/constant"
	xlogger "smartkf.top/smart-kf/kf-api/pkg/log"
)

type KfUserMsgToKfService struct {
	KfImBaseService
	msg        *dto.Message
	newMessage *dao.KFMessage
}

func (s *KfUserMsgToKfService) Init(ctx context.Context, msg *dto.Message) error {
	s.guestId = msg.Token
	if err := s.setCardIdByGuestId(ctx); err != nil {
		return err
	}
	s.msg = msg
	return nil
}

func (s *KfUserMsgToKfService) saveMessage() error {
	var msgRepository = repository.KFMessageRepository{}
	// 插入db.
	newMessage := &dao.KFMessage{
		MsgId:   uuid2.NewString(),
		MsgType: common.MessageType(s.msg.MsgType),
		GuestId: s.guestId,
		Content: s.msg.Content,
		CardId:  s.cardId,
		IsKf:    constant.IsNotKf,
		Status:  1,
	}
	if err := msgRepository.SaveOne(context.Background(), newMessage); err != nil {
		xlogger.Error(context.Background(), "msgHandler 插入消息失败", xlogger.Err(err))
		return err
	}
	s.newMessage = newMessage
	return nil
}

func (s *KfUserMsgToKfService) increaseUnRead(ctx context.Context) {
	// 未读 + 1
	caches.UserUnReadCacheInstance.IncrUserUnRead(ctx, s.cardId, s.guestId, 1)
}

// Handle 前台消息发给后台
func (s *KfUserMsgToKfService) Handle(ctx context.Context) {
	// 1. 存储消息入库
	if err := s.saveMessage(); err != nil {
		return
	}
	// 2. 更新用户信息
	if err := s.updateUserLastMessage(ctx, s.newMessage.MsgId); err != nil {
		return
	}
	s.increaseUnRead(ctx)

	sessionIds := s.getKfbeSessionIds(ctx, s.cardId)
	if len(sessionIds) == 0 {
		s.fallbackToAIAnswer(ctx)
		return
	}
	pushMessage := dto.NewMessage(s.msg, constant.PlatformKfBe)
	s.pushMessage(ctx, constant.EventMessage, pushMessage, sessionIds...)
}

// 智能答复.
func (s *KfUserMsgToKfService) fallbackToAIAnswer(ctx context.Context) {
	var welcomeMsgRepo repository.KfWelcomeMessageRepository
	msgList, _, err := welcomeMsgRepo.ListEnable(ctx, s.cardId, constant.SmartMsg, 1, 20)
	if err != nil {
		return
	}

	setting, err := caches.KfSettingCache.GetOne(ctx, s.cardId)
	if err != nil {
		return
	}

	text := "猜您想问"
	if setting.OfflineReply != "" {
		text = setting.OfflineReply
	}

	var data = make([]map[string]interface{}, 0)
	// 查询话术，并返回.
	newMessage := dto.NewSmartReplyMessage()
	if len(msgList) > 0 {
		for _, item := range msgList {
			data = append(
				data, map[string]interface{}{
					"id":    item.ID,
					"title": item.Title,
				},
			)
		}

		content := map[string]interface{}{
			"describe": text,
			"list":     data,
		}
		bs, _ := json.Marshal(content)
		newMessage.Content = string(bs)
	} else {
		// 如果没有设置，就不回复了
		if setting.OfflineReply == "" {
			return
		}
		content := map[string]interface{}{
			"describe": text,
			"list":     []string{},
		}
		bs, _ := json.Marshal(content)
		newMessage.Content = string(bs)
	}

	var msgRepository = repository.KFMessageRepository{}
	// 插入db.
	saveMessage := &dao.KFMessage{
		MsgId:   uuid2.NewString(),
		MsgType: common.MessageSmartMsg,
		GuestId: s.guestId,
		Content: newMessage.Content,
		CardId:  s.cardId,
		IsKf:    constant.IsKf,
		Status:  1,
	}
	if err := msgRepository.SaveOne(context.Background(), saveMessage); err != nil {
		xlogger.Error(context.Background(), "msgHandler 插入消息失败", xlogger.Err(err))
		return
	}

	// 存储消息.
	s.pushMessage(ctx, constant.EventMessage, newMessage, s.msg.SessionId)
}
