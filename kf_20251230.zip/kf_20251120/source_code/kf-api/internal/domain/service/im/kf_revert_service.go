package im

import (
	"context"

	"smartkf.top/smart-kf/kf-api/internal/domain/dto"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/common/constant"
)

type KfRevertService struct {
	KfImBaseService
	msgId string
}

func (s *KfRevertService) Init(ctx context.Context, msg *dto.Message) error {
	s.guestId = msg.Token
	s.msgId = msg.MsgId
	if err := s.setCardIdByGuestId(ctx); err != nil {
		return err
	}
	if err := s.setKfUserSessionId(ctx); err != nil {
		return err
	}
	return nil
}

// Handle 推送给前台，撤回消息
func (s *KfRevertService) Handle(ctx context.Context) {
	// 删除消息.
	msg := dto.NewRevertMessage(s.msgId, constant.PlatformKfFe)
	s.pushMessage(ctx, constant.EventRevert, msg, s.guestSessionId)
}
