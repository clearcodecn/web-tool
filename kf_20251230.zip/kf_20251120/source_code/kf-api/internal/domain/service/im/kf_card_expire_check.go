package im

import (
	"context"

	"smartkf.top/smart-kf/kf-api/internal/domain/caches"
)

func CheckCardExpire(ctx context.Context, cardId string) bool {
	card, err := caches.KfCardCacheInstance.GetCardByID(ctx, cardId)
	if err != nil {
		return true
	}
	if card.HasExpire() {
		return true
	}
	return false
}
