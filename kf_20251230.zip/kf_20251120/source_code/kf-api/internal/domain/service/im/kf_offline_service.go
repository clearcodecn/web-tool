package im

import (
	"context"

	"smartkf.top/smart-kf/kf-api/internal/domain/caches"
	"smartkf.top/smart-kf/kf-api/internal/domain/dto"
)

type KfOfflineService struct {
	KfImBaseService
	msg *dto.Message
}

func (s *KfOfflineService) Init(ctx context.Context, msg *dto.Message) error {
	s.msg = msg
	if err := s.setCardIdByBackendToken(ctx, msg.Token); err != nil {
		return err
	}
	return nil
}

func (s *KfOfflineService) Handle(ctx context.Context) {
	caches.ImSessionCacheInstance.DeleteKfBeOnlineSession(ctx, s.cardId, s.msg.SessionId)
}
