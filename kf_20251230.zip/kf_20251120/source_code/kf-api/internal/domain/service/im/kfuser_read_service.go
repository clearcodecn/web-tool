package im

import (
	"context"
	"time"

	"smartkf.top/smart-kf/kf-api/internal/domain/caches"
	"smartkf.top/smart-kf/kf-api/internal/domain/dto"
	"smartkf.top/smart-kf/kf-api/internal/domain/repository"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/common/constant"
	xlogger "smartkf.top/smart-kf/kf-api/pkg/log"
)

type KfUserReadService struct {
	KfImBaseService

	msg *dto.Message
}

func (s *KfUserReadService) Init(ctx context.Context, msg *dto.Message) error {
	s.guestId = msg.Token
	s.guestSessionId = msg.SessionId
	s.msg = msg

	err := s.setCardIdByGuestId(ctx)
	if err != nil {
		xlogger.Error(ctx, "处理消息失败-KfUserReadService-Init", xlogger.Any("msg", msg))
		return err
	}
	return nil
}

func (s *KfUserReadService) Handle(ctx context.Context) {
	// 1. 入库存储.
	// 在 xx 时间点以前的消息 ，都算作已读.
	// 查找前台用户信息.
	dbUser, err := caches.KfUserCacheInstance.GetDBUser(ctx, s.cardId, s.guestId)
	if err != nil {
		xlogger.Error(ctx, "处理消息失败-GetDBUser", xlogger.Err(err))
		return
	}
	dbUser.LastReadMsgAt = time.Now().Unix()
	var userRepo repository.KFUserRepository
	err = userRepo.UpdateCol(
		ctx, s.cardId, repository.UpdateColOption{
			UUID:          dbUser.UUID,
			LastMsgReadAt: dbUser.LastReadMsgAt,
		},
	)
	if err != nil {
		xlogger.Error(ctx, "处理消息失败-SaveOne", xlogger.Err(err), xlogger.Any("user", dbUser))
		return
	}
	caches.KfUserCacheInstance.DelDBUserCache(ctx, s.cardId, dbUser.UUID)

	// 推送消息给管理端.
	kfSessionIds := s.getKfbeSessionIds(ctx, s.cardId)
	if len(kfSessionIds) == 0 {
		return
	}

	onlineMsg := dto.NewKfuserReadMessage(dbUser.UUID, s.cardId, s.guestSessionId)
	s.pushMessage(ctx, constant.EventMessage, onlineMsg, kfSessionIds...)

	return
}
