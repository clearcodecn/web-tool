package im

import (
	"context"
	"encoding/json"
	"time"

	uuid2 "github.com/google/uuid"
	"gorm.io/gorm"

	"smartkf.top/smart-kf/kf-api/internal/domain/caches"
	"smartkf.top/smart-kf/kf-api/internal/domain/dto"
	"smartkf.top/smart-kf/kf-api/internal/domain/repository"
	dao2 "smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql/dao"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/common"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/common/constant"
	xlogger "smartkf.top/smart-kf/kf-api/pkg/log"
)

type KFUserOnlineService struct {
	KfImBaseService

	msg *dto.Message
}

func (s *KFUserOnlineService) Init(ctx context.Context, msg *dto.Message) error {
	s.guestId = msg.Token
	s.guestSessionId = msg.SessionId
	s.msg = msg

	err := s.setCardIdByGuestId(ctx)
	if err != nil {
		xlogger.Error(ctx, "处理消息失败-KFUserOnlineService-Init", xlogger.Any("msg", msg))
		return err
	}
	return nil
}

func (s *KFUserOnlineService) saveSession(ctx context.Context) {
	// 将客户session存储至redis
	caches.ImSessionCacheInstance.SetKffeOnlineSession(ctx, s.cardId, s.guestId, s.guestSessionId)
}

func (s *KFUserOnlineService) setUserOnline(ctx context.Context) {
	// 修改客户在线状态: set
	_ = caches.UserOnLineCacheInstance.SetUserOnline(ctx, s.cardId, s.guestId)
}

func (s *KFUserOnlineService) Handle(ctx context.Context) {
	s.saveSession(ctx)
	s.setUserOnline(ctx)

	// 查找前台用户信息.
	dbUser, err := caches.KfUserCacheInstance.GetDBUser(ctx, s.cardId, s.guestId)
	if err != nil {
		xlogger.Error(ctx, "处理消息失败-GetDBUser", xlogger.Err(err))
		return
	}

	// 查找离线消息.
	s.pushOfflineMessage(ctx, dbUser)

	s.pushWelcomeMessage(ctx, dbUser)

	kfSessionIds := s.getKfbeSessionIds(ctx, s.cardId)
	if len(kfSessionIds) > 0 {
		onlineMsg := dto.NewGuestOnlineMessage(dbUser.NickName, dbUser.UUID, dbUser.Avatar, s.cardId, s.guestSessionId)
		s.pushMessage(ctx, constant.EventOnline, onlineMsg, kfSessionIds...)
	}
	return
}

func (s *KFUserOnlineService) pushOfflineMessage(ctx context.Context, dbuser *dao2.KfUser) {
	ids := caches.KfUserOnfflineMessagesInstance.GetAll(ctx, s.cardId, dbuser.UUID)
	if len(ids) == 0 {
		return
	}
	var msgRepo repository.KFMessageRepository
	msgs, err := msgRepo.ByIDs(ctx, s.cardId, ids)
	if err != nil {
		return
	}
	for _, msg := range msgs {
		pushMsg := dto.NewPushMessage(string(msg.MsgType), msg.MsgId, msg.Content, dbuser)
		s.pushMessage(ctx, constant.EventMessage, pushMsg, s.guestSessionId)
	}
}

func (s *KFUserOnlineService) pushWelcomeMessage(ctx context.Context, dbUser *dao2.KfUser) {
	if dbUser.IsSendWelcome {
		return
	}
	dbUser.IsSendWelcome = true
	var userRepo repository.KFUserRepository
	userRepo.UpdateCol(
		ctx, dbUser.CardID, repository.UpdateColOption{
			UUID:          dbUser.UUID,
			IsSendWelcome: true,
		},
	)
	caches.KfUserCacheInstance.DelDBUserCache(ctx, dbUser.CardID, dbUser.UUID)
	// 查找欢迎语.
	welcomeMsg := caches.WelcomeMessageCacheInstance.FindWelcomeMessages(ctx, s.cardId)
	if len(welcomeMsg) == 0 {
		return
	}
	// 二次确认，查看该客户是否发送过消息.
	if dbUser.LastMessageId != "" {
		return
	}
	dbMsgs := make([]*dao2.KFMessage, 0, len(welcomeMsg))
	now := time.Now()
	n := 0
	for _, msg := range welcomeMsg {
		if !msg.Enable {
			continue
		}
		var content = msg.Content
		if msg.Type == string(common.MessageTypeVideo) {
			bs, _ := json.Marshal(
				map[string]interface{}{
					"url":   msg.Content,
					"thumb": msg.Thumb,
				},
			)
			content = string(bs)
		}

		dbMsg := dao2.KFMessage{
			MsgId:   uuid2.NewString(),
			MsgType: common.MessageType(msg.Type),
			GuestId: dbUser.UUID,
			CardId:  s.cardId,
			Content: content,
			IsKf:    constant.IsKf,
			Status:  1,
			Model: gorm.Model{
				CreatedAt: now.Add(time.Duration(n) * time.Second), // 为了让他延时排序
			},
		}
		n++
		dbMsgs = append(dbMsgs, &dbMsg)
	}

	if len(dbMsgs) == 0 {
		return
	}

	var msgRepo repository.KFMessageRepository
	if err := msgRepo.BatchCreate(ctx, dbMsgs); err != nil {
		xlogger.Error(ctx, "处理消息失败-BatchCreate", xlogger.Err(err))
		return
	}
	for _, msg := range dbMsgs {
		pushMsg := dto.NewPushMessage(string(msg.MsgType), msg.MsgId, msg.Content, dbUser)
		time.Sleep(100 * time.Millisecond)
		s.pushMessage(ctx, constant.EventMessage, pushMsg, s.guestSessionId)
	}
	s.updateUserLastMessage(ctx, dbMsgs[len(dbMsgs)-1].MsgId)
}
