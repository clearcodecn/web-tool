package im

import (
	"context"
	"encoding/json"
	"time"

	uuid2 "github.com/google/uuid"
	"gorm.io/gorm"

	"smartkf.top/smart-kf/kf-api/internal/domain/caches"
	"smartkf.top/smart-kf/kf-api/internal/domain/dto"
	"smartkf.top/smart-kf/kf-api/internal/domain/repository"
	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql/dao"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/common"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/common/constant"
	xlogger "smartkf.top/smart-kf/kf-api/pkg/log"
)

// 智能回复处理.
type kfUserKeywordService struct {
	KfImBaseService

	smartMsgId int64
	kfMsg      *dao.KFMessage
	userMsg    *dao.KFMessage
}

func (s *kfUserKeywordService) Init(ctx context.Context, msg *dto.Message) error {
	s.guestId = msg.Token
	if err := s.setCardIdByGuestId(ctx); err != nil {
		return err
	}
	if err := s.setKfUserSessionId(ctx); err != nil {
		return err
	}
	s.smartMsgId = msg.SmartMsgId
	return nil
}

// Handle 推送给客服后台，客户离线消息
func (s *kfUserKeywordService) Handle(ctx context.Context) {
	// 查询消息.
	msg := caches.WelcomeMessageCacheInstance.FindSmartMsg(ctx, s.cardId, s.smartMsgId)
	if msg == nil {
		return
	}

	if !msg.Enable {
		return
	}

	if err := s.saveMessage(msg.Type, msg.Title, msg.Content, msg.Thumb); err != nil {
		return
	}

	// 2. 更新用户信息
	if err := s.updateUserLastMessage(ctx, s.kfMsg.MsgId); err != nil {
		return
	}

	// 推送给前台
	pushMessage := dto.NewReplyMessage(
		constant.PlatformKfFe,
		string(s.kfMsg.MsgType),
		s.kfMsg.MsgId,
		s.kfMsg.Content,
		s.guestId,
	)
	s.pushMessage(ctx, constant.EventMessage, pushMessage, s.guestSessionId)

	sessionIds := s.getKfbeSessionIds(ctx, s.cardId)
	if len(sessionIds) == 0 {
		return
	}
	pushMessage.Platform = constant.PlatformKfBe
	pushMessage.Content = s.userMsg.Content
	pushMessage.MsgId = s.userMsg.MsgId
	pushMessage.MsgType = string(s.userMsg.MsgType)
	s.pushMessage(ctx, constant.EventMessage, pushMessage, sessionIds...)

	pushMessageBackend := dto.NewReplyMessage(
		constant.PlatformKfBe,
		string(s.kfMsg.MsgType),
		s.kfMsg.MsgId,
		s.kfMsg.Content,
		s.guestId,
	)

	s.pushMessage(ctx, constant.EventMessage, pushMessageBackend, sessionIds...)
}

func (s *kfUserKeywordService) saveMessage(typ string, title string, content string, thumb string) error {
	var msgRepository = repository.KFMessageRepository{}
	// 插入db.
	kfUserMsg := &dao.KFMessage{
		MsgId:   uuid2.NewString(),
		MsgType: common.MessageTypeText,
		GuestId: s.guestId,
		Content: title,
		CardId:  s.cardId,
		IsKf:    constant.IsNotKf,
		Status:  1,
	}
	if err := msgRepository.SaveOne(context.Background(), kfUserMsg); err != nil {
		xlogger.Error(context.Background(), "msgHandler 插入消息失败", xlogger.Err(err))
		return err
	}
	// 插入db.
	kfMsg := &dao.KFMessage{
		Model: gorm.Model{
			CreatedAt: time.Now().Add(1 * time.Second),
		},
		MsgId:   uuid2.NewString(),
		MsgType: common.MessageType(typ),
		GuestId: s.guestId,
		Content: content,
		CardId:  s.cardId,
		IsKf:    constant.IsKf,
		Status:  1,
	}
	if common.MessageType(typ) == common.MessageTypeVideo {
		bs, _ := json.Marshal(
			map[string]interface{}{
				"url":   content,
				"thumb": thumb,
			},
		)
		kfMsg.Content = string(bs)
	}

	if err := msgRepository.SaveOne(context.Background(), kfMsg); err != nil {
		xlogger.Error(context.Background(), "msgHandler 插入消息失败", xlogger.Err(err))
		return err
	}

	s.userMsg = kfUserMsg
	s.kfMsg = kfMsg
	return nil
}
