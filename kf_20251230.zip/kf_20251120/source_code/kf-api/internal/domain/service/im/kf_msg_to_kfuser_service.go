package im

import (
	"context"

	"github.com/samber/lo"

	"smartkf.top/smart-kf/kf-api/internal/domain/caches"
	"smartkf.top/smart-kf/kf-api/internal/domain/dto"
	"smartkf.top/smart-kf/kf-api/internal/domain/repository"
	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql/dao"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/common"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/common/constant"
	xlogger "smartkf.top/smart-kf/kf-api/pkg/log"
)

type KfMsgToKfUserService struct {
	KfImBaseService
	msg        *dto.Message
	newMessage *dao.KFMessage
}

func (s *KfMsgToKfUserService) Init(ctx context.Context, msg *dto.Message) error {
	s.msg = msg
	s.guestId = msg.GuestId
	if err := s.setCardIdByGuestId(ctx); err != nil {
		return err
	}
	return nil
}

func (s *KfMsgToKfUserService) saveMessage(ctx context.Context) error {
	var msgRepository = repository.KFMessageRepository{}
	// 插入db.
	newMessage := &dao.KFMessage{
		MsgId:   s.msg.MsgId,
		MsgType: common.MessageType(s.msg.MsgType),
		GuestId: s.guestId,
		CardId:  s.cardId,
		Content: s.msg.Content,
		IsKf:    constant.IsKf,
		Status:  1,
	}
	if err := msgRepository.SaveOne(ctx, newMessage); err != nil {
		xlogger.Error(ctx, "msgHandler 插入消息失败", xlogger.Err(err))
		return err
	}
	s.newMessage = newMessage
	return nil
}

func (s *KfMsgToKfUserService) Handle(ctx context.Context) {
	if err := s.saveMessage(ctx); err != nil {
		return
	}

	if err := s.updateUserLastMessage(ctx, s.newMessage.MsgId); err != nil {
		return
	}

	if err := s.setKfUserSessionId(ctx); err != nil {
		return
	}

	if s.guestSessionId == "" {
		xlogger.Info(ctx, "增加离线消息", xlogger.Any("msg", s.newMessage))
		caches.KfUserOnfflineMessagesInstance.AddOffLineMessage(ctx, s.cardId, s.guestId, s.newMessage.MsgId)
		return
	}

	newMessage := dto.NewMessage(s.msg, constant.PlatformKfFe)
	sessionIds := s.pushMessage(ctx, constant.EventMessage, newMessage, s.guestSessionId)
	if len(sessionIds) == 0 || !lo.Contains(sessionIds, s.guestSessionId) {
		xlogger.Info(ctx, "增加离线消息bypush", xlogger.Any("msg", s.newMessage))
		caches.KfUserOnfflineMessagesInstance.AddOffLineMessage(ctx, s.cardId, s.guestId, s.newMessage.MsgId)
	}
}
