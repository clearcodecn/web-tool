package session

import (
	"context"
	"time"

	"github.com/samber/lo"

	"smartkf.top/smart-kf/kf-api/internal/domain/caches"
	"smartkf.top/smart-kf/kf-api/internal/domain/repository"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/common"
	xlogger "smartkf.top/smart-kf/kf-api/pkg/log"
	"smartkf.top/smart-kf/kf-api/pkg/wsclient"
)

type SessionCheckTask struct{}

func (s *SessionCheckTask) Run(ch chan struct{}) {
	for {
		select {
		case <-ch:
			return
		default:
		}
		s.runOnce()
		<-time.After(1 * time.Minute)
	}
}

func (SessionCheckTask) runOnce() {
	var (
		ctx           = context.Background()
		page     uint = 1
		pageSize uint = 100
		client   wsclient.WsClient
		cardRepo repository.KFCardRepository
	)
	for {
		// repo.
		cards, _, err := cardRepo.List(
			ctx, &repository.ListCardOption{
				ExpireStart: time.Now().Unix(),
				PageRequest: &common.PageRequest{
					Page:     &page,
					PageSize: &pageSize,
					OrderBy:  "id",
					Asc:      true,
				},
			},
		)
		if err != nil {
			xlogger.Error(ctx, "cardRepo.List failed", xlogger.Err(err))
			return
		}
		for _, card := range cards {
			sids, err := caches.ImSessionCacheInstance.GetKfbeSessionIds(ctx, card.CardID)
			if err != nil {
				xlogger.Error(ctx, "GetKfbeSessionIds failed", xlogger.Err(err))
				continue
			}

			if len(sids) == 0 {
				continue
			}

			res, err := client.CheckSessions(ctx, sids...)
			if err != nil {
				xlogger.Error(ctx, "CheckSessions failed", xlogger.Err(err))
				continue
			}
			// 求差集
			oldMap := lo.SliceToMap(
				sids, func(item string) (string, bool) {
					return item, true
				},
			)
			for _, r := range res {
				delete(oldMap, r)
			}
			// 剩下的删除
			if len(oldMap) > 0 {
				offLine := lo.MapToSlice(
					oldMap, func(key string, v bool) string {
						return key
					},
				)

				if len(offLine) > 0 {
					for _, id := range offLine {
						caches.ImSessionCacheInstance.DeleteKfBeOnlineSession(ctx, card.CardID, id)
					}
				}
			}
		}

		page++
		if len(cards) < int(pageSize) {
			break
		}
	}

}
