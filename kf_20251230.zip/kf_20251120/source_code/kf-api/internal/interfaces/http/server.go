package http

import (
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"

	router2 "smartkf.top/smart-kf/kf-api/internal/interfaces/http/router"
	xlogger "smartkf.top/smart-kf/kf-api/pkg/log"
	"smartkf.top/smart-kf/kf-api/pkg/version"

	"smartkf.top/smart-kf/kf-api/config"
	"smartkf.top/smart-kf/kf-api/pkg/utils"
)

func RunApiServer() error {
	conf := config.GetConfig()
	g := gin.New()
	g.Use(gin.Recovery())
	g.Use(
		func(ctx *gin.Context) {
			origin := ctx.Request.Header.Get("Origin")
			ctx.Header("Access-Control-Allow-Origin", origin)
			ctx.Header("Access-Control-Allow-Methods", ctx.Request.Header.Get("access-control-request-method"))
			// ctx.Header("Access-Control-Allow-Credentials", "true") // 如果需要凭据
			// 处理预检请求
			if ctx.Request.Method == http.MethodOptions {
				// 动态设置允许的请求头
				reqHeaders := ctx.Request.Header.Get("Access-Control-Request-Headers")
				if reqHeaders != "" {
					ctx.Header("Access-Control-Allow-Headers", reqHeaders)
				}
				ctx.AbortWithStatus(http.StatusNoContent)
				return
			}

			ctx.Next()
		},
	)

	var logConfig xlogger.GinLogConfigure
	logConfig.LogIP(utils.ClientIP)
	logConfig.SkipPrefix("/static", "/favico.ico")
	if conf.Debug {
		logConfig.EnableRequestBody()
	}
	g.Use(xlogger.GinLog(logConfig))

	g.GET(
		"/healthy", func(ctx *gin.Context) {
			ctx.String(200, "success")
		},
	)
	g.GET(
		"/version", func(ctx *gin.Context) {
			ctx.String(200, fmt.Sprintf("git-version is: %s", version.Version))
		},
	)

	g.RedirectTrailingSlash = true
	g.RedirectFixedPath = true

	registerRouter(g)

	return g.Run(conf.Web.String())
}

func registerRouter(g *gin.Engine) {
	api := g.Group("/api")
	router2.RegisterBillBackendRouter(api)
	router2.PublicRouter(api)
	router2.InternalRouter(g)
	router2.RegisterKfBackendRouter(api)
	router2.RegisterKfFrontend(api)
}

func RunStaticServer(id string, path string, addr string) error {
	fmt.Println("start static server: ", id, path, "listen at ", addr)
	g := gin.Default()
	g.StaticFS("/", http.Dir(path))
	return g.Run(addr)
}
