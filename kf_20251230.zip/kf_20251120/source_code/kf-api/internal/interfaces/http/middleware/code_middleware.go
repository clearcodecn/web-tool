package middleware

import (
	"github.com/gin-gonic/gin"
)

func SaleCodeMiddleware() gin.HandlerFunc {
	return func(ctx *gin.Context) {
		code := ctx.Query("c")
		if code != "" {
			ctx.SetCookie("sale_code", code, 3600, "/", "", false, true)
		}
		ctx.Next()
	}
}
