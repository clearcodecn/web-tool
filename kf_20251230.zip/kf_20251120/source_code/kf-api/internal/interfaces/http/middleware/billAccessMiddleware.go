package middleware

import (
	"github.com/gin-gonic/gin"

	"smartkf.top/smart-kf/kf-api/pkg/xerrors"
)

// BillAdminAccessMiddleware checks if the authenticated bill account has admin role
func BillAdminAccessMiddleware() gin.HandlerFunc {
	return func(ctx *gin.Context) {

		account := GetBillAccount(ctx)
		// Check if account has admin role
		if !account.IsAdmin() {
			var bc BaseController
			bc.Error(ctx, xerrors.NewCustomError("无权限访问"))
			ctx.Abort()
			return
		}

		ctx.Next()
	}
}
