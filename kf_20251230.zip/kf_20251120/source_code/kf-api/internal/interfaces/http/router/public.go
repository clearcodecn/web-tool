package router

import (
	"github.com/gin-gonic/gin"
	"smartkf.top/smart-kf/kf-api/pkg/captcha"

	"smartkf.top/smart-kf/kf-api/internal/interfaces/http/controller/kfbackend"
)

func PublicRouter(api *gin.RouterGroup) {
	public := api.Group("/public")
	{
		var publicController kfbackend.PublicController
		public.GET("/captchaId", publicController.GetCaptchaId)           // 获取验证码id
		public.GET("/captcha/*action", gin.WrapH(captcha.Server(80, 40))) // 显示验证码图片
	}
}
