package router

import (
	"github.com/gin-gonic/gin"

	kffrontend2 "smartkf.top/smart-kf/kf-api/internal/interfaces/http/controller/kffrontend"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/http/middleware"
)

func RegisterKfFrontend(api *gin.RouterGroup) {
	// 客服前台
	kffe := api.Group("/kf-fe")
	kffe.Use(middleware.KFFeAuthMiddleware())
	{
		var qr kffrontend2.QRCodeController
		kffe.POST("/qrcode/scan", qr.Scan)
		kffe.GET("/stay", qr.StayReport)
		kffe.POST("/qrcode/check", qr.Check)
		kffe.GET("/smartmsg", qr.GetSmartReplyKeywords)
		kffe.GET("/notice", qr.GetNotice)
	}
	// 客服前台 鉴权API
	kffe2 := api.Group("/kf-fe")
	kffe2.Use(middleware.KFFeMustAuthMiddleware())
	{
		var qr kffrontend2.MsgController
		kffe2.POST("/msg/list", qr.MsgList)
		kffe.POST("/upload", qr.Upload)
	}
}
