package router

import (
	"github.com/gin-gonic/gin"

	bill2 "smartkf.top/smart-kf/kf-api/internal/interfaces/http/controller/bill"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/http/middleware"
)

func RegisterBillBackendRouter(api *gin.RouterGroup) {

	// 计费
	var bc bill2.BaseController
	bgUnAuth := api.Group("/bill")
	{
		bgUnAuth.POST("/login", bc.Login)
	}

	bgAuth := api.Group("/bill", middleware.BillAuthMiddleware())
	{
		var cardController bill2.CardController
		var domainController bill2.DomainController
		cardGroup := bgAuth.Group("/card")
		{
			cardGroup.POST("/batch-add", cardController.BatchAddCard)
			cardGroup.POST("/updateStatus", cardController.UpdateStatus)
			cardGroup.POST("/updateCardExpire", cardController.ModifyCardExpireTime)
			cardGroup.POST("/list", cardController.List)
			cardGroup.POST("/assignDomain", domainController.AssignDomain)
			cardGroup.POST("/clearPassword", cardController.ClearPassword)
		}

		domainGroup := bgAuth.Group("/domain")
		{
			domainGroup.POST("/list", domainController.ListDomain)

			domainGroup.POST("/add", domainController.AddDomain)
			domainGroup.POST("/del", domainController.DeleteDomain)
			domainGroup.POST("/checkdomain", domainController.CheckDomain)
			domainGroup.POST("/wechatban", domainController.WechatBan)
			domainGroup.POST("/wechatunban", domainController.WechatUnBan)
		}

		var oc bill2.OrderController
		orderGroup := bgAuth.Group("/order")
		{
			orderGroup.POST("/list", oc.List)
			orderGroup.POST("/domainlist", oc.DomainOrderList)
			orderGroup.POST("/changeorderstatus", oc.ChangeOrderStatus)
		}

		var settingController bill2.SettingController
		settingGroup := bgAuth.Group("/setting")
		{
			access := settingGroup.Group("", middleware.BillAdminAccessMiddleware())

			access.GET("/get", settingController.Get)
			access.POST("/update", settingController.Set)

			// 地址管理.
			settingGroup.GET("/address/list", settingController.AddressList)
			access.POST("/address/del", settingController.DelAddress)
			access.POST(
				"/address/upsert",
				settingController.UpsertAddress,
			)

			// tron 配置.
			access.GET("/tron/get", settingController.GetTron)
			access.POST("/tron/update", settingController.UpsertTron)
			access.POST(
				"/change-password",
				settingController.UpdatePassword,
			)
		}
	}
}
