package router

import (
	"github.com/gin-gonic/gin"

	kfbackend2 "smartkf.top/smart-kf/kf-api/internal/interfaces/http/controller/kfbackend"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/http/middleware"
)

func RegisterKfBackendRouter(g *gin.RouterGroup) {
	var authController kfbackend2.AuthController
	g.POST("/kf-be/login", authController.Login)
	g.POST("/kf-be/renew", authController.Xufei)

	// 搜索页面.
	searchRouter := g.Group("/kf-be/search")
	{
		var searchController kfbackend2.SearchController
		searchRouter.POST("/cardstatus", searchController.SearchCardStatus)
		searchRouter.POST("/qrcode", searchController.SearchCardQRcode)
		searchRouter.POST("/7dayincr", searchController.Search7DaysIncr)
		searchRouter.POST("/fans", searchController.SearchFans)
	}

	// 客服后台
	kf := g.Group("/kf-be", middleware.KFBeAuthMiddleware())
	{
		var publicController kfbackend2.PublicController
		kf.POST("/upload", publicController.Upload)
		kf.POST("/logout", authController.Logout)
		kf.POST("/change-password", authController.ChangePassword)
		kf.POST("/renew2", authController.Xufei)

		var qrcodeController kfbackend2.QRCodeController
		var domainController kfbackend2.DomainOrderController
		qrCodeGroup := kf.Group("/qrcode")
		{
			qrCodeGroup.GET("", qrcodeController.List)
			qrCodeGroup.POST("/switch", qrcodeController.Switch)
			qrCodeGroup.POST("/switch-domain", qrcodeController.SwitchDomain)
			qrCodeGroup.POST("/on-off", qrcodeController.OnOff)
			qrCodeGroup.POST("/delete", qrcodeController.Delete)
			qrCodeGroup.GET("/domain-price", domainController.GetDomainPrice)
			qrCodeGroup.POST("/create-domain-order", domainController.CreateOrder)
			qrCodeGroup.GET("/domain-order-list", domainController.OrderList)
		}

		var chatController kfbackend2.ChatController
		chatGroup := kf.Group("/chat")
		{
			chatGroup.POST("/list", chatController.List)
			chatGroup.POST("/msgs", chatController.Msgs)
			chatGroup.POST("/batchsend", chatController.BatchSend)
			chatGroup.POST("/revert", chatController.Revert)
			chatGroup.POST("/del_user", chatController.DeleteUser)
		}

		var sysConfController kfbackend2.SysConfController
		settingGroup := kf.Group("/sysConf")
		{
			settingGroup.GET("", sysConfController.Get)
			settingGroup.POST("", sysConfController.Post)
			settingGroup.POST("deleteData", sysConfController.DeleteData)
		}

		var kfUserInfo kfbackend2.GuestController
		userInfoGroup := kf.Group("/user")
		{
			userInfoGroup.GET("", kfUserInfo.GetKfUserInfo)
			userInfoGroup.POST("/update", kfUserInfo.UpdateUserInfo)
		}

		var wc kfbackend2.WelcomeMsgController
		welGroup := kf.Group("/welcome")
		{
			welGroup.POST("/upsert", wc.Upsert)
			welGroup.GET("/list", wc.ListAll)
			welGroup.POST("/del", wc.Delete)
			welGroup.POST("/copy", wc.CopyCardMsg)
		}

		var logc kfbackend2.LogController
		logGroup := kf.Group("/log")
		{
			logGroup.GET("/list", logc.List)
		}

		// 用户报表
		var userReportController kfbackend2.UserReportController
		reportGroup := kf.Group("/report")
		{
			reportGroup.GET("/user", userReportController.List)
			reportGroup.GET("/user/export", userReportController.ExportCSV)
		}
	}
}
