package router

import (
	"github.com/gin-gonic/gin"

	notify2 "smartkf.top/smart-kf/kf-api/internal/interfaces/http/controller/notify"
)

func InternalRouter(g *gin.Engine) {
	// 内部调用: websocket on auth 回调.
	internal := g.Group("/internal")
	{
		api := internal.Group("/api")
		{
			var nc notify2.NotifyController
			api.POST("websocket-auth", nc.WebsocketAuth)
		}

	}
}
