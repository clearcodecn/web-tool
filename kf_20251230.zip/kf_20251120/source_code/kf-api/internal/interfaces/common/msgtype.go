package common

type MessageType string

const (
	MessageTypeText  MessageType = "text"      // 文本
	MessageTypeImage MessageType = "image"     // 图片
	MessageTypeVideo MessageType = "video"     // 视频
	MessageSmartMsg  MessageType = "smart_msg" // 智能消息
)
