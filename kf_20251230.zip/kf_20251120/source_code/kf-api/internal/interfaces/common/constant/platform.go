package constant

const (
	PlatformKfFe = "kf"
	PlatformKfBe = "kf-backend"
)

const (
	EventSessionId  = "sessionId"  // 新建连接、初始化sessionId事件
	EventMessage    = "message"    // 发送消息事件
	EventMessageAck = "messageAck" // 发送消息事件
	EventOnline     = "online"     // 上线事件
	EventOffline    = "offline"    // 下线事件
	EventRevert     = "revert"     // 撤回消息
)

const (
	MsgTypeRead       = "read"       // 读取消息事件
	MsgTypeKfUserRead = "kfuserread" // 读取消息事件
	MsgTypeSmartMsg   = "smart_msg"  // 智能回复
	MsgTypeSmartReply = "smartReply" // 用户点击智能回复
	MsgKeyword        = "keyword"    // 读取消息事件
)

const (
	IsKf    = 1
	IsNotKf = 2
)
