package common

import (
	"context"
	"fmt"
	"runtime"

	"github.com/gin-gonic/gin"

	xlogger "smartkf.top/smart-kf/kf-api/pkg/log"
)

// Context, kf 前台、kf后台通用，存储 cardId 信息, 做了 *gin.Context 兼容

var kfCardIDKey = "kf-card-key"
var kfTokenKey = "kf-token-key"

func WithKfCardID(ctx context.Context, cardId string) context.Context {
	return context.WithValue(ctx, kfCardIDKey, cardId)
}

func GetKFCardID(ctx context.Context) string {
	ginCtx, ok := ctx.(*gin.Context)
	if ok {
		ctx = ginCtx.Request.Context()
	}

	acc, ok := ctx.Value(kfCardIDKey).(string)
	if ok {
		return acc
	}
	_, file, line, _ := runtime.Caller(1)
	_, file2, line2, _ := runtime.Caller(2)

	caller := fmt.Sprintf("%s:%d", file, line)
	caller2 := fmt.Sprintf("%s:%d", file2, line2)
	xlogger.Warn(
		ctx, "GetKFCardID-failed, 未从context中获取到cardID,请检查路由设置: ", xlogger.Any("caller", caller),
		xlogger.Any("caller2", caller2),
	)
	return ""
}

func WithKFToken(ctx context.Context, token string) context.Context {
	return context.WithValue(ctx, kfTokenKey, token)
}

func GetKFToken(ctx context.Context) string {
	ginCtx, ok := ctx.(*gin.Context)
	if ok {
		ctx = ginCtx.Request.Context()
	}
	acc, ok := ctx.Value(kfTokenKey).(string)
	if ok {
		return acc
	}
	xlogger.Warn(ctx, "GetKFCardID-failed, 未从context中获取到kfToken,请检查路由设置")
	return ""
}
