package task

import (
	"context"
	"strings"
	"time"

	"github.com/jasonlvhit/gocron"
	"github.com/samber/lo"

	"smartkf.top/smart-kf/kf-api/internal/domain/repository"
	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql/dao"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/common"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/common/constant"
	"smartkf.top/smart-kf/kf-api/pkg/domaincheck"
	xlogger "smartkf.top/smart-kf/kf-api/pkg/log"
)

type DomainCheckBackgroundTask struct{}

func (t *DomainCheckBackgroundTask) Start(stopChan chan struct{}) {
	gocron.Every(1).Day().At("12:00").Do(t.Do)
	ch := gocron.Start()

	<-stopChan

	close(ch)
}

func (t *DomainCheckBackgroundTask) Do() {
	var (
		page      uint = 1
		pageSize  uint = 1000
		domainMap      = make(map[string]*dao.BillDomain)
	)

	// 不检测时间.
	now := time.Now()
	if now.Hour() < 8 && now.Hour() > 0 {
		xlogger.Info(context.Background(), "当前时间不在域名检测时间范围内，跳过本次检测")
		return
	}

	ctx := context.Background()
	// 1. 查询系统的域名
	var domainRepo repository.BillDomainRepository
	domain, _, err := domainRepo.List(
		ctx, &repository.ListDomainOption{
			PageRequest: &common.PageRequest{
				Page:     &page,
				PageSize: &pageSize,
				OrderBy:  "id",
				Asc:      false,
			},
			DomainStatus: []int{constant.WechatStatusOK, constant.WechatStatusRedirect},
		},
	)
	if err != nil {
		return
	}
	var domains []string
	for _, item := range domain {
		topName := item.TopName
		arr := strings.Split(topName, ".") // 只要最后2段
		if len(arr) == 2 {
			domains = append(domains, topName)
			domainMap[topName] = item
		}
	}

	if len(domains) == 0 {
		return
	}
	domains = lo.Uniq(domains)

	// 更新域名检测时间.
	domainRepo.BatchUpdateCheckTime(ctx, domains, time.Now())

	ret, err := domaincheck.BatchCheckDomain(ctx, domains)
	if err != nil {
		xlogger.Error(ctx, "域名检测失败", xlogger.Err(err))
		return
	}
	var (
		failedDomain   []string
		redirectDomain []string
	)
	for k, v := range ret {
		if v.Banned() {
			failedDomain = append(failedDomain, k)
		}
		if v.Redirect() {
			redirectDomain = append(redirectDomain, k)
		}
	}
	xlogger.Info(ctx, "本次域名检测结果-封禁", xlogger.Any("domain", failedDomain))
	xlogger.Info(ctx, "本次域名检测结果-正常", xlogger.Any("domain", redirectDomain))

	if len(failedDomain) > 0 {
		// 2. 更新域名状态
		if err := domainRepo.BatchUpdateWechatStatus(ctx, failedDomain, constant.WechatStatusBanned); err != nil {
			xlogger.Error(ctx, "批量更新域名状态失败", xlogger.Err(err))
			return
		}
	}

	if len(redirectDomain) > 0 {
		// 2. 更新域名状态
		if err := domainRepo.BatchUpdateWechatStatus(ctx, redirectDomain, constant.WechatStatusRedirect); err != nil {
			xlogger.Error(ctx, "批量更新域名状态失败", xlogger.Err(err))
			return
		}
	}
	// 3. 同步二维码状态.
	// 先找域名id.
	var (
		banned   []int64
		redirect []int64
	)
	for _, top := range failedDomain {
		if v, ok := domainMap[top]; ok {
			banned = append(banned, int64(v.ID))
		}
	}
	for _, top := range redirectDomain {
		if v, ok := domainMap[top]; ok {
			redirect = append(redirect, int64(v.ID))
		}
	}
	// TODO:: 减少量更新
	var qrCodeRepo repository.QRCodeDomainRepository
	if len(banned) > 0 {
		qrCodeRepo.BatchUpdateWechatStatus(ctx, banned, constant.WechatStatusBanned)
	}
	if len(redirect) > 0 {
		qrCodeRepo.BatchUpdateWechatStatus(ctx, redirect, constant.WechatStatusRedirect)
	}
}
