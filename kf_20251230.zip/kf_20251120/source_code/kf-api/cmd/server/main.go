package main

import (
	"flag"
	"log"
	"time"

	"golang.org/x/sync/errgroup"

	"smartkf.top/smart-kf/kf-api/internal/domain/caches"
	"smartkf.top/smart-kf/kf-api/internal/domain/repository"
	"smartkf.top/smart-kf/kf-api/internal/infrastructure/mysql"
	"smartkf.top/smart-kf/kf-api/internal/infrastructure/nsq"
	"smartkf.top/smart-kf/kf-api/internal/infrastructure/redis"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/cron/billlog"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/cron/kflog"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/http"
	"smartkf.top/smart-kf/kf-api/internal/interfaces/nsq/producer"
	task2 "smartkf.top/smart-kf/kf-api/internal/task"
	xlogger "smartkf.top/smart-kf/kf-api/pkg/log"

	"smartkf.top/smart-kf/kf-api/config"
)

var configName string

func init() {
	flag.StringVar(&configName, "c", "./config/dev.yaml", "配置文件")
}

func main() {
	flag.Parse()
	conf := config.Load(configName)
	initLogger(conf)
	caches.InitCacheInstances()
	mysql.Load()
	redis.InitRedis()
	nsq.InitNSQ()
	producer.InitProducer()

	go func() {
		setRepo := repository.BillSettingRepository{}
		setRepo.InitDefault()
	}()

	var (
		eg       errgroup.Group
		stopChan = make(chan struct{})
	)
	eg.Go(
		func() error {
			task := billlog.InitBillLogBackgroundTask(1*time.Minute, 100) // 1分钟清空buffer
			task.Start(stopChan)
			return nil
		},
	)
	eg.Go(
		func() error {
			task := kflog.InitKFLogBackgroundTask(1*time.Minute, 10000)
			task.Start(stopChan)
			return nil
		},
	)
	eg.Go(
		func() error {
			nsq.StartConsume(stopChan)
			return nil
		},
	)

	eg.Go(
		func() error {
			var task task2.DomainCheckBackgroundTask
			task.Start(stopChan)
			return nil
		},
	)

	eg.Go(
		func() error {
			// var task session.SessionCheckTask
			// task.Run(stopChan)
			return nil
		},
	)

	if err := http.RunApiServer(); err != nil {
		close(stopChan)
		return
	}

	log.Fatal(eg.Wait())
}

func initLogger(conf *config.Config) {
	logger, err := xlogger.NewLog(
		xlogger.Config{
			Level:  conf.Log.Level,
			Format: conf.Log.Format,
			File:   conf.Log.File,
		},
	)

	if err != nil {
		panic(err)
	}

	xlogger.SetGlobal(logger)
}
