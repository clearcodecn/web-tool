package config

import (
	"fmt"
)

type Config struct {
	Debug       bool          `json:"debug"`
	Web         Web           `json:"web"`
	Log         Log           `json:"log"`
	DB          Db            `json:"db"`
	JwtKey      string        `json:"jwtKey"`
	RedisConfig RedisConfig   `json:"redis"`
	NSQ         NSQ           `json:"nsq"`
	HttpClient  HttpClient    `json:"httpClient"`
	Payment     Payment       `json:"payment"`
	Ip2Region   Ip2Region     `json:"ip2Region"`
	SocketIO    SocketIO      `json:"socketIo"`
	DomainCheck DomainCheck   `json:"domainCheck"`
	BillAccount []BillAccount `json:"billAccount"`
}

type BillAccount struct {
	Username string `json:"username"`
	Password string `json:"password"`
	Role     string `json:"role"`
}

type DomainCheck struct {
	DomainCheckType string `json:"domainCheckType"`
	ApiKey          string `json:"apiKey"`
}

type Ip2Region struct {
	XDBPath        string `json:"xdbPath"`
	RegistryApiKey string `json:"registryApiKey"`
	Proxy          string `json:"proxy"`
	Timeout        int    `json:"timeout"`
}

type Payment struct {
	Host     string `json:"host"`
	Token    string `json:"token"`
	AppId    string `json:"appId"`
	FromMail string `json:"fromMail"` // 发邮件的来源地址
}

type Web struct {
	Addr            string `json:"addr" default:"127.0.0.1"`
	Port            int    `json:"port" default:"8081"`
	CdnHost         string `json:"cdnHost"`         // cdnHost
	CdnHostFrontend string `json:"cdnHostFrontend"` // 前端
	UploadDir       string `json:"uploadDir"`       // 上传文件夹
	DisableIP       bool   `json:"disableIp"`       // debug
}

type KfDist struct {
	Path string `json:"path"`
	Addr string `json:"addr"`
}

func (w Web) String() string {
	return fmt.Sprintf("%s:%d", w.Addr, w.Port)
}

type Db struct {
	Dsn    string `json:"dsn"`    // 连接
	Driver string `json:"driver"` // 默认 sqlite3
}

type Log struct {
	Level  string `json:"level" default:"info"`
	Format string `json:"format" default:"json"`
	File   string `json:"file"`
}

type RedisConfig struct {
	DB       int    `json:"db"`
	Address  string `json:"address"`
	Password string `json:"password"`
}

type NSQ struct {
	Addrs             []string `json:"addrs"`
	Timeout           int      `json:"timeout" default:"60"`
	MessageTopic      string   `json:"messageTopic" default:"im_message"`
	MessageTopicGroup string   `json:"messageTopicGroup" default:"im_message_group"`
	OrderExpireTopic  string   `json:"orderExpireTopic" default:"order_expire_notify"`
	OrderExpireGroup  string   `json:"orderExpireGroup" default:"order_expire_notify_group"`
}

type HttpClient struct {
	SocketServerClient string `json:"socketServerAddress"`
	Timeout            int    `json:"timeout"`
	Proxy              string `json:"proxy"`
}

type SocketIO struct {
	Host string `json:"host"` // 域名:
}

type CaddyConfig struct {
	Caddyfile string `json:"caddyfile"`
	CaddyAPI  string `json:"caddyApi"`
}
