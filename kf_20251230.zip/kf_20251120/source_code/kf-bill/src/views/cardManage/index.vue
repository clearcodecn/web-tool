<!-- 二维码页面 -->
<template>
  <div class="kf-body">
    <div>
      <a-form :model="searchParams" class="search-form">
        <a-form-item label="卡密ID">
          <a-input v-model:value="searchParams.cardID" placeholder="请输入卡密ID" allowClear />
        </a-form-item>
        <a-form-item label="卡片类型">
          <a-select v-model:value="searchParams.cardType" placeholder="请选择卡片类型" :options="state.typeOptions" allowClear> </a-select>
        </a-form-item>
        <a-form-item label="卡密天数">
          <a-select v-model:value="searchParams.days" placeholder="卡密天数" :options="state.daysOptions" allowClear> </a-select>
        </a-form-item>
        <a-form-item label="登录状态">
          <a-select v-model:value="searchParams.loginStatus" placeholder="请选择登录状态" :options="state.loginOptions" allowClear> </a-select>
        </a-form-item>
        <a-form-item label="销售状态">
          <a-select v-model:value="searchParams.saleStatus" placeholder="请选择销售状态" :options="state.saleOptions" allowClear> </a-select>
        </a-form-item>
        <a-form-item label="上次登录时间">
          <a-range-picker v-model:value="searchParams.loginTime" />
        </a-form-item>
        <a-form-item label="过期时间">
          <a-range-picker v-model:value="searchParams.expireTime" />
        </a-form-item>
        <a-form-item>
          <a-space>
            <a-button @click="onReset">重置</a-button>
            <a-button type="primary" @click="onSearch">查询</a-button>
            <a-button type="primary" @click="onAddMsg">批量新增卡号</a-button>
          </a-space>
        </a-form-item>
      </a-form>
    </div>
    <a-table bordered :data-source="state.dataSource" :loading="state.loading" :columns="columns" size="middle" :scroll="{ x: 'max-content' }" :pagination="false">
      <template #bodyCell="{ column, text, record }">
        <template v-if="column.dataIndex === 'saleStatusText'">
          <a-tag v-if="record.saleStatus === 1" color="blue">{{ record.saleStatusText }}</a-tag>
          <a-tag v-if="record.saleStatus === 2" color="gray">{{ record.saleStatusText }}</a-tag>
          <a-tag v-if="record.saleStatus === 3" color="#87d068">{{ record.saleStatusText }}</a-tag>
        </template>
        <template v-if="column.dataIndex === 'cardTypeText'">
          <a-tag v-if="record.cardType === 1" color="blue">{{ record.cardTypeText }}</a-tag>
          <a-tag v-if="record.cardType === 2" color="gray">{{ record.cardTypeText }}</a-tag>
        </template>
        <template v-if="column.dataIndex === 'day'">
          <a-tag v-if="record.cardType === 1" color="blue">{{ record.day }}</a-tag>
          <a-tag v-if="record.cardType === 2" color="gray"> - </a-tag>
        </template>

         <template v-if="column.dataIndex === 'domains'">
          <span v-if="record.domains && record.domains.length > 0">
            <span v-for="(domain, index) in record.domains" :key="index">{{ domain }}<span v-if="index < record.domains.length - 1">, </span></span>
          </span>
          <span v-else> - </span>
        </template>
        <template v-if="column.dataIndex === 'loginStatusText'">
          <span v-if="record.loginStatus === 1" style="color: gray">{{ record.loginStatusText }}</span>
          <span v-if="record.loginStatus === 2" style="color: #87d068">{{ record.loginStatusText }}</span>
        </template>
        <template v-if="column.dataIndex === 'expireTimeText'">
          <a-space>
            <span :class="timeOutCheck(record)">{{ record.expireTimeText }}</span>
            <span v-if="record.expireTime > 0" class="table-link-action" @click="onEditTime(record)"> 更新 </span>
          </a-space>
        </template>
        <template v-if="column.dataIndex === 'password'">
          <span v-if="record.password.length > 0">
            有
          </span>
          <span v-else> - </span>
        </template>
        <template v-if="column.dataIndex === 'operation'">
          <a-space>
            <span v-if="record.saleStatus == 1" class="table-link-action" @click="onStatusChangeOk(record, 2)"> 下架 </span>
            <span v-if="record.saleStatus == 1" class="table-link-action" @click="onStatusChangeOk(record, 3)"> 发放卡密 </span>
            <!-- <span v-if="record.saleStatus == 3" class="table-link-action" @click="assignDomain(record)"> 自动新增域名 </span> -->
            <span v-if="record.password.length > 0" class="table-link-action" @click="clearPassword(record)"> 清空密码 </span>
          </a-space>
        </template>
      </template>
    </a-table>
    <a-pagination size="small" v-model:current="searchParams.page" :total="state.total" @change="onPageChange" show-size-changer show-quick-jumper :show-total="(total) => `共 ${total} 条`" />
    <a-modal v-model:visible="state.showTimeDia" title="更新过期时间" @ok="onTimeChangeOk">
      <div>
        <a-form>
          <a-form-item label="过期时间">
            <a-date-picker show-time placeholder="请选择" style="width: 80%" v-model:value="state.updateTime" format="YYYY-MM-DD HH:mm:ss">
              <template #renderExtraFooter>
                <a-space>
                  <a-button type="primary" size="small" @click="setTime(1)">1天</a-button>
                  <a-button type="primary" size="small" @click="setTime(7)">7天</a-button>
                  <a-button type="primary" size="small" @click="setTime(30)">30天</a-button>
                </a-space>
              </template>
            </a-date-picker>
          </a-form-item>
        </a-form>
      </div>
    </a-modal>
    <AddModal v-model:model-value="state.showDia" :action-type="state.actionType" @refesh="onSearch"></AddModal>
  </div>
</template>

<script lang="ts" setup>
import { computed, ref, onMounted, reactive } from 'vue'
import { h } from 'vue'
import { message as Message } from 'ant-design-vue'
import { CardApi } from '@/webapi'
import AddModal from './components/addModal/index.vue'
import dayjs, { Dayjs } from 'dayjs'
type RangeValue = [Dayjs, Dayjs]
const state = reactive({
  dataSource: [],
  editableData: {},
  editData: {} as any,
  actionType: 'add',
  showDia: false,
  loading: false,
  showStatusDia: false,
  showTimeDia: false,
  updateTime: null as any,
  total: 0,
  nowTime: 0, // 当前时间，用于计算是否过期
  typeOptions: [
    {
      value: 1,
      label: '正式卡'
    },
    {
      value: 2,
      label: '测试卡'
    }
  ],
  daysOptions: [
    {
      value: 0,
      label: '请选择卡密天数',
    },
    {
      value: 1,
      label: '日卡'
    },
    {
      value: 7,
      label: '周卡'
    },
    {
      value: 30,
      label: '月卡'
    }
  ],
  loginOptions: [
    {
      value: 1,
      label: '未登录过'
    },
    {
      value: 2,
      label: '登录过'
    }
  ],
  saleOptions: [
    {
      value: 1,
      label: '销售中'
    },
    {
      value: 2,
      label: '下架'
    },
    {
      value: 3,
      label: '已出售'
    }
  ]
})

const searchParams = reactive({
  page: 1,
  pageSize: 10,
  expireTime: [],
  loginTime: [],
  cardID: '',
  cardType: 1,
  loginStatus: null,
  saleStatus: null,
  days: 0,
})

const columns = [
  {
    title: '卡密ID',
    key: 'cardId',
    fixed: 'left',
    align: 'center',
    dataIndex: 'cardId',
    width: 150
  },
  {
    title: '备注',
    key: 'remark',
    fixed: 'left',
    align: 'center',
    dataIndex: 'remark',
    width: 150
  },
  {
    title: '类型',
    key: 'cardTypeText',
    align: 'center',
    dataIndex: 'cardTypeText',
    width: 100
  },
  {
    title: '有效天数',
    align: 'center',
    dataIndex: 'day',
    key: 'day',
    width: 100
  },
  {
    title: '域名',
    align: 'center',
    dataIndex: 'domains',
    key: 'domains',
    width: 100
  },  
  {
    title: '密码',
    align: 'center',
    dataIndex: 'password',
    key: 'password',
    width: 100
  },
  {
    title: '上次登录时间',
    align: 'center',
    dataIndex: 'lastLoginTimeText',
    key: 'lastLoginTimeText',
    width: 180
  },
  {
    title: '登录状态',
    align: 'center',
    dataIndex: 'loginStatusText',
    key: 'loginStatusText',
    width: 100
  },
  {
    title: '过期时间',
    align: 'center',
    dataIndex: 'expireTimeText',
    key: 'expireTimeText',
    width: 200
  },
  {
    title: '销售状态',
    align: 'center',
    dataIndex: 'saleStatusText',
    key: 'saleStatusText',
    width: 120
  },
  {
    title: '操作',
    align: 'center',
    fixed: 'right',
    dataIndex: 'operation',
    width: 200
  }
]

const timeOutCheck = (record: any) => {
  const { expireTime } = record
  if (expireTime === 0) return ''
  return state.nowTime > expireTime ? 'red-time' : 'green-time'
}

const onReset = () => {
  searchParams.page = 1
  searchParams.expireTime = []
  searchParams.loginTime = []
  searchParams.cardID = ''
  searchParams.cardType = 1
  searchParams.loginStatus = null
  searchParams.saleStatus = null
  searchParams.pageSize = 10
  searchParams.days = 0
  getTableList()
}

const onSearch = () => {
  searchParams.page = 1
  getTableList()
}

// 新增卡密ID
const onAddMsg = () => {
  state.actionType = 'add'
  state.showDia = true
}

const setTime = (num: number) => {
  state.updateTime = dayjs().add(num, 'day')
}

// 更新过期时间
const onEditTime = (item) => {
  state.actionType = 'edit'
  state.editData = { ...item }
  console.log(dayjs(item.expireTimeText))
  state.updateTime = dayjs(item.expireTimeText)
  state.showTimeDia = true
}
const onEdit = (item) => {
  state.actionType = 'edit'
  state.editData = { ...item }
  state.showStatusDia = true
}

const onStatusChangeOk = async (row, toStatus) => {
  let params = {
    cardId: row.cardId,
    status: toStatus
  }
  state.loading = true
  let { code, data = {}, message }: any = await CardApi.updateStatus(params)
  state.loading = false
  if (code === 200) {
    Message.success('更新成功')
    state.showStatusDia = false
    getTableList()
  } else {
    state.showStatusDia = false
    Message.error(message || '请求失败')
  }
}

const assignDomain = async (row) => {
  let params = {
    cardId: row.cardId,
  }
  state.loading = true
  let { code, data = {}, message }: any = await CardApi.assignDomain(params)
  state.loading = false
  if (code === 200) {
    Message.success('操作成功')
    state.showStatusDia = false
    getTableList()
  } else {
    state.showStatusDia = false
    Message.error(message || '请求失败')
  }
}

const clearPassword = async (row) => {
  let params = {
    cardId: row.cardId,
  }
  state.loading = true
  let { code, data = {}, message }: any = await CardApi.clearPassword(params)
  state.loading = false
  if (code === 200) {
    Message.success('操作成功')
    state.showStatusDia = false
    getTableList()
  } else {
    state.showStatusDia = false
    Message.error(message || '请求失败')
  }
}

const onTimeChangeOk = async () => {
  if (!state.updateTime) {
    Message.error('请选择时间')
    return
  }
  let expireTime = Math.floor(dayjs(state.updateTime).valueOf() / 1000)
  let params = {
    id: state.editData.cardId,
    expireTime: expireTime
  }
  state.loading = true
  let { code, data = {}, message }: any = await CardApi.updateCardExpire(params)
  state.loading = false
  if (code === 200) {
    Message.success('更新成功')
    state.showTimeDia = false
    getTableList()
  } else {
    state.showTimeDia = false
    Message.error(message || '请求失败')
  }
}

const onPageChange = (page, pageSize) => {
  searchParams.page = page
  searchParams.pageSize = pageSize
  getTableList()
}
const getTableList = async () => {
  let params: any = {
    ...searchParams
  }
  if (params.loginTime && params.loginTime.length) {
    params.lastLoginTimeEnd = dayjs(params.loginTime[1]).valueOf()
    params.lastLoginTimeStart = dayjs(params.loginTime[0]).valueOf()
  }
  if (params.expireTime && params.expireTime.length) {
    params.expireEndTime = dayjs(params.expireTime[1]).valueOf()
    params.expireStartTime = dayjs(params.expireTime[0]).valueOf()
  }
  state.loading = true
  let { code, data = {}, message }: any = await CardApi.getCardList(params)
  state.loading = false
  if (code === 200) {
    state.dataSource = (data.list || []).map((el) => {
      el.expireTime = el.expireTime * 1000
      el.expireTimeText = (el.expireTime === 0 ) ? '--' : dayjs(el.expireTime).format('YYYY-MM-DD HH:mm:ss')
      el.lastLoginTimeText = el.lastLoginTime === 0 ? '--' : dayjs(el.lastLoginTime * 1000).format('YYYY-MM-DD HH:mm:ss')
      let cardItem = state.typeOptions.find((v) => v.value === el.cardType)
      el.cardTypeText = (cardItem && cardItem.label) || '-'
      let loginItem = state.loginOptions.find((v) => v.value === el.loginStatus)
      el.loginStatusText = (loginItem && loginItem.label) || '-'
      let saleItem = state.saleOptions.find((v) => v.value === el.saleStatus)
      el.saleStatusText = ( (saleItem  && el.cardType === 1) && saleItem.label) || '-'
      return el
    })
    state.nowTime = dayjs().valueOf()
    state.total = data.total || 0
  } else {
    Message.error(message || '请求失败')
  }
}

onMounted(() => {
  getTableList()
})
</script>
<style lang="less" scoped>
.top-action {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding-bottom: 12px;
}
.refesh {
  cursor: pointer;
  width: 27px;
  height: 27px;
  line-height: 24px;
  text-align: center;
  display: inline-block;
  border-radius: 50%;
  border: 1px solid #eee;
  background-color: #fff;
  &:hover {
    background-color: #eee;
  }
}
.anticon-edit span {
  margin-inline-start: 0;
}
.search-form {
  display: flex;
  flex-wrap: wrap;
  .ant-form-item {
    width: 30%;
    padding-right: 3%;
    .ant-form-item-label {
      width: 120px;
    }
  }
}
.search-btn {
  text-align: center;
  padding-bottom: 12px;
}
.green-time {
  color: #87d068;
}
.red-time {
  color: #ff4d4f;
}
</style>
