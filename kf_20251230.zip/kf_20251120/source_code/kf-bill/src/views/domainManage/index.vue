<!-- 二维码页面 -->
<template>
  <div class="kf-body">
    <div class="top-action">
      <a-button type="primary" @click="onAddMsg" style="margin-left: 20px;">批量新增域名</a-button>
      <a-button type="primary" @click="checkDomain">域名检测</a-button>
      <a-button type="primary" @click="onSearch">刷新</a-button>
    </div>
    <a-form-item>
          <a-alert
            message="创建域名之前需要将域名解析至服务器，并且配置到Caddyfile，否则不会生效"
            type="warning"
            closable
          />
        </a-form-item>
    <a-table bordered :data-source="state.dataSource" :loading="state.loading" :columns="columns" size="middle" :scroll="{ x: 'max-content' }" :pagination="false">
      <template #bodyCell="{ column, text, record }">
        <template v-if="column.dataIndex === 'status'">
          <a-tag v-if="record.status === 1" color="green">正常</a-tag>
          <a-tag v-if="record.status === 2" color="gray">禁用</a-tag>
        </template>
        <template v-if="column.dataIndex === 'wechatStatus'">
          <a-tag v-if="record.wechatStatus === 1" color="green">正常</a-tag>
          <a-tag v-if="record.wechatStatus === 2" color="gray">封禁</a-tag>
          <a-tag v-if="record.wechatStatus === 3" color="warning">跳转</a-tag>
        </template>
        <template v-if="column.dataIndex === 'operation'">
          <a-space>
            <a-popconfirm title="确定要删除吗？" @confirm="onDelete(record)">
              <span class="table-link-action"> <DeleteOutlined />删除 </span>
            </a-popconfirm>
            <a-popconfirm title="确认操作" @confirm="changeToWechatBan(record)">
              <span class="table-link-action"> 设置微信封禁 </span>
            </a-popconfirm>
          </a-space>
        </template>
      </template>
    </a-table>
    <a-pagination size="small" v-model:current="searchParams.page" :total="state.total" @change="onPageChange" show-size-changer show-quick-jumper :show-total="(total) => `共 ${total} 条`" />
  </div>
  <AddModal v-model:model-value="state.showDia" :action-type="state.actionType" @refesh="onSearch"></AddModal>
</template>

<script lang="ts" setup>
import { computed, ref, onMounted, reactive } from 'vue'
import { h } from 'vue'
import { ReloadOutlined, EditOutlined, DeleteOutlined } from '@ant-design/icons-vue'
import { message as Message } from 'ant-design-vue'
import { DomainApi } from '@/webapi'
import AddModal from './components/addModal/index.vue'
import dayjs from 'dayjs'

const state = reactive({
  dataSource: [],
  editableData: {},
  editData: {},
  actionType: 'add',
  showDia: false,
  loading: false,
  total: 0
})

const searchParams = reactive({
  page: 1,
  pageSize: 10
})

const columns = [
  {
    title: '域名名称',
    key: 'topName',
    align: 'center',
    dataIndex: 'topName',
    width: 120
  },
  {
    title: '域名状态',
    key: 'status',
    align: 'center',
    dataIndex: 'status',
    width: 100
  },
  {
    title: '协议',
    key: 'protocol',
    align: 'center',
    dataIndex: 'protocol',
    width: 100
  },
  {
    title: '微信状态',
    key: 'wechatStatus',
    align: 'center',
    dataIndex: 'wechatStatus',
    width: 100
  },
  {
    title: '域名检测时间',
    key: 'checkTimeText',
    align: 'center',
    dataIndex: 'checkTimeText',
    width: 180
  },
  {
    title: '创建时间',
    key: 'CreatedAtText',
    align: 'center',
    dataIndex: 'CreatedAtText',
    width: 180
  },
  {
    title: '操作',
    align: 'center',
    fixed: 'right',
    dataIndex: 'operation',
    width: 100
  }
]

const onReset = () => {
  searchParams.page = 1
  searchParams.pageSize = 10
  getTableList()
}

const onSearch = () => {
  searchParams.page = 1
  getTableList()
}

const onDelete = async (record) => {
  let params = {
    id: record.id
  }
  let { code, data = {}, message }: any = await DomainApi.delDomain(params)
  if (code === 200) {
    Message.success('删除成功')
    getTableList()
  } else {
    Message.error(message || '请求失败')
  }
}

const changeToWechatBan = async (record) => {
  let params = {
    id: record.id
  }
  let { code, data = {}, message }: any = await DomainApi.wechatBan(params)
  if (code === 200) {
    Message.success('操作成功')
    getTableList()
  } else {
    Message.error(message || '请求失败')
  }
}

const checkDomain = async () => {
  let { code, data = {}, message }: any = await DomainApi.checkDomain()
  if (code === 200) {
    Message.success('已在后台执行，请勿重复多次点击，将消耗实际费用')
    setTimeout(() => {
      getTableList()
    }, 2000);
  } else {
    Message.error(message || '请求失败')
  }
}

// 新增卡密ID
const onAddMsg = () => {
  state.actionType = 'add'
  state.showDia = true
}
const onPageChange = (page, pageSize) => {
  searchParams.page = page
  searchParams.pageSize = pageSize
  getTableList()
}
const getTableList = async () => {
  let params = {
    ...searchParams
  }
  state.loading = true
  let { code, data = {}, message }: any = await DomainApi.getDomainList(params)
  state.loading = false
  if (code === 200) {
    state.dataSource = (data.list || []).map((el) => {
      el.CreatedAtText = dayjs(el.createTime * 1000).format('YYYY-MM-DD HH:mm:ss')
      el.checkTimeText = el.checkTime ? dayjs(el.checkTime * 1000).format('YYYY-MM-DD HH:mm:ss') : '未检测'
      el.isBindText = el.isBind ? '是' : '否'
      el.isPublicText = el.isPublic ? '是' : '否'
      el.isForTestingText = el.isForTesting ? '是' : '否'
      return el
    })
    state.total = data.total || 0
  } else {
    Message.error(message || '请求失败')
  }
}

onMounted(() => {
  getTableList()
})
</script>
<style lang="less" scoped>
.top-action {
  display: flex;
  align-items: flex-start;
  padding-bottom: 12px;
  gap: 20px;
}
.refesh {
  cursor: pointer;
  width: 27px;
  height: 27px;
  line-height: 24px;
  text-align: center;
  display: inline-block;
  border-radius: 50%;
  border: 1px solid #eee;
  background-color: #fff;
  &:hover {
    background-color: #eee;
  }
}
.anticon-edit span {
  margin-inline-start: 0;
}
.search-form {
  display: flex;
  flex-wrap: wrap;
  .ant-form-item {
    width: 30%;
    padding-right: 3%;
    .ant-form-item-label {
      width: 120px;
    }
  }
}
.search-btn {
  text-align: center;
  padding-bottom: 12px;
}
</style>
