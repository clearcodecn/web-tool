import baseService from '@/utils/http/axios'

// 获取订单列表
export const getOrderList = (data: any) => {
  return baseService.post(`api/bill/order/list`, data)
}

// 获取订单列表
export const getDomainOrderList = (data: any) => {
  return baseService.post(`api/bill/order/domainlist`, data)
}

// 获取订单列表
export const userChangeOrderStatus = (data: any) => {
  return baseService.post(`api/bill/order/changeorderstatus`, data)
}
