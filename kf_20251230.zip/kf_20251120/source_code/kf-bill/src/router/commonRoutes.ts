import { UserLayout } from '@/layouts'
import { h } from 'vue'
import { BasicLayout, RouteView } from '@/layouts'
import { MailOutlined, AppstoreOutlined, SettingOutlined } from '@ant-design/icons-vue'
import { type Router } from './types'
export default [
  {
    path: '/',
    name: 'index',
    component: BasicLayout,
    redirect: '/cardManage',
    meta: {roles: ['admin', 'saller']},
    children: [
      // {
      //   path: '/orderManage',
      //   name: 'orderManage',
      //   meta: { title: '订单管理', icon: 'icon-erweima', keepAlive: false, roles: ['admin', 'saller'] },
      //   component: () => import('@/views/orderManage/index.vue'),
      // },
      // {
      //   path: '/domainOrderManage',
      //   name: 'domainOrderManage',
      //   meta: { title: '域名订单', icon: 'icon-erweima', keepAlive: false, roles: ['admin', 'saller'], },
      //   component: () => import('@/views/orderManage/domain.vue'),
      // },
      {
        path: '/cardManage',
        name: 'cardManage',
        component: () => import('@/views/cardManage/index.vue'),
        meta: { title: '卡密管理', icon: 'icon-xiaoxi1', keepAlive: false, roles: ['admin', 'saller'], },
      },
      {
        path: '/domainManage',
        name: 'domainManage',
        meta: { title: '域名管理', icon: 'icon-huanyingyu', keepAlive: false, roles: ['admin', 'saller'], },
        component: () => import('@/views/domainManage/index.vue'),

      },
      {
        path: '/systemSetting',
        name: 'systemSetting',
        meta: { title: '系统设置', icon: 'icon-shezhi', keepAlive: false, roles: ['admin'], },
        component: () => import('@/views/systemSetting/index.vue'),
        roles: ['admin'],
      },
      // {
      //   path: '/system/address',
      //   name: 'address',
      //   meta: { title: '地址管理', icon: 'icon-shezhi', keepAlive: false, roles: ['admin','saller'], },
      //   component: () => import('@/views/systemSetting/address.vue'),
      //   roles: ['admin'],
      // }
    ]
  },
  {
    path: '/user',
    name: 'user',
    component: UserLayout,
    redirect: '/user/login',
    hidden: true,
    children: [
      {
        path: 'login',
        name: 'login',
        component: () => import(/* webpackChunkName: "user" */ '@/views/user/Login.vue'),
        meta: { title: '登录' }
      }
    ]
  },
  {
    path: '/:path(.*)',
    name: 'NoMatch',
    component: () => import('@/views/exception/404.vue')
  }
] as Router[]
