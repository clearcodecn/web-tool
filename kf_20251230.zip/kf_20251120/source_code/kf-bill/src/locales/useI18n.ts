import { createI18n } from 'vue-i18n'
import ls from '@/utils/Storage'
import { genLangs } from '@/utils/batchImportFiles'

const includePath = ['locales', 'views', 'components']
let en = (import.meta as any).glob('/src/**/en.ts', { eager: true })
let cn = (import.meta as any).glob('/src/**/cn.ts', { eager: true })

en = genLangs(en, includePath)
cn = genLangs(cn, includePath)

const i18n = createI18n({
  locale: ls.get('lang') || 'zh-CN',
  legacy: false,
  globalInjection: true,
  messages: {
    'zh-CN': cn,
    'en-US': en
  }
})

export default i18n
