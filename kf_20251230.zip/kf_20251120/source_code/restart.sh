#!/bin/bash

# 天马云客服系统重启脚本

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_step() {
    echo -e "${BLUE}[STEP]${NC} $1"
}

# 获取安装路径
get_install_path() {
    if [[ -f "/www/install.conf" ]]; then
        echo "/www"
    elif [[ -f "./install.conf" ]]; then
        echo "$(pwd)"
    else
        read -p "请输入安装路径: " INSTALL_PATH
        echo "$INSTALL_PATH"
    fi
}

# 停止服务
stop_services() {
    log_step "停止服务..."
    
    # 停止kf-message服务
    if [[ -d "$INSTALL_PATH/kf-message" ]]; then
        cd "$INSTALL_PATH/kf-message"
        docker-compose down
        log_info "kf-message服务已停止"
        cd "$INSTALL_PATH"
    fi
    
    # 停止kf-api服务
    if [[ -d "$INSTALL_PATH/kf-api" ]]; then
        cd "$INSTALL_PATH/kf-api"
        docker-compose down
        log_info "kf-api服务已停止"
        cd "$INSTALL_PATH"
    fi
    
    # 停止基础Docker服务
    if [[ -d "$INSTALL_PATH/kf-containers" ]]; then
        cd "$INSTALL_PATH/kf-containers"
        docker-compose down
        log_info "基础Docker服务已停止"
        cd "$INSTALL_PATH"
    fi
}

# 启动服务
start_services() {
    log_step "启动服务..."
    
    # 启动基础服务 (MySQL, Redis, NSQ)
    if [[ -d "$INSTALL_PATH/kf-containers" ]]; then
        cd "$INSTALL_PATH/kf-containers"
        docker-compose up -d
        log_info "基础服务已启动"
        cd "$INSTALL_PATH"
    fi
    
    # 等待MySQL启动
    log_info "等待MySQL服务启动..."
    sleep 10
    
    # 启动kf-api服务
    if [[ -d "$INSTALL_PATH/kf-api" ]]; then
        cd "$INSTALL_PATH/kf-api"
        docker-compose up -d
        log_info "kf-api服务已启动"
        cd "$INSTALL_PATH"
    fi
    
    # 启动kf-message服务
    if [[ -d "$INSTALL_PATH/kf-message" ]]; then
        cd "$INSTALL_PATH/kf-message"
        docker-compose up -d
        log_info "kf-message服务已启动"
        cd "$INSTALL_PATH"
    fi
    
    # 重启Nginx
    systemctl restart nginx
    log_info "Nginx服务已重启"
}

# 检查服务状态
check_services() {
    log_step "检查服务状态..."
    
    # 检查基础Docker服务
    if docker ps | grep -q "kf-containers"; then
        log_info "基础Docker服务运行正常"
    else
        log_warn "基础Docker服务未运行"
    fi
    
    # 检查kf-api服务
    if docker ps | grep -q "kf-api"; then
        log_info "kf-api服务运行正常"
    else
        log_warn "kf-api服务未运行"
    fi
    
    # 检查kf-message服务
    if docker ps | grep -q "socket-server"; then
        log_info "kf-message服务运行正常"
    else
        log_warn "kf-message服务未运行"
    fi
    
    # 检查Nginx
    if systemctl is-active --quiet nginx; then
        log_info "Nginx服务运行正常"
    else
        log_warn "Nginx服务未运行"
    fi
}

# 主函数
main() {
    log_info "开始重启天马云客服系统..."
    
    INSTALL_PATH=$(get_install_path)
    
    if [[ ! -d "$INSTALL_PATH" ]]; then
        log_error "安装路径不存在: $INSTALL_PATH"
        exit 1
    fi
    
    log_info "使用安装路径: $INSTALL_PATH"
    
    stop_services
    sleep 2
    start_services
    sleep 3
    check_services
    
    log_info "服务重启完成！"
    echo
    echo "查看日志:"
    echo "kf-api日志: docker-compose logs -f (在 $INSTALL_PATH/kf-api 目录下)"
    echo "kf-message日志: docker-compose logs -f (在 $INSTALL_PATH/kf-message 目录下)"
    echo "基础服务日志: docker-compose logs -f (在 $INSTALL_PATH/kf-containers 目录下)"
    echo "查看所有容器: docker ps"
}

# 运行主函数
main "$@" 