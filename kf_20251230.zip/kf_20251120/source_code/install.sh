#!/bin/bash

# 天马云客服系统自动安装脚本
# 适用于 Ubuntu 20.04+

set -e  # 遇到错误立即退出

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_step() {
    echo -e "${BLUE}[STEP]${NC} $1"
}

# 检查是否为root用户
check_root() {
    if [[ $EUID -ne 0 ]]; then
        log_error "此脚本需要root权限运行"
        exit 1
    fi
}

# 生成随机密码
generate_password() {
    openssl rand -base64 12 | tr -d "=+/" | cut -c1-12
}

# 获取用户输入
get_user_input() {
    log_step "开始配置安装参数..."
    
    # 获取域名
    while true; do
        read -p "请输入域名 (例如: example.com): " DOMAIN
        if [[ -n "$DOMAIN" ]]; then
            break
        else
            log_error "域名不能为空"
        fi
    done
    
    # 询问是否自动生成密码
    read -p "是否自动生成密码? (y/n, 默认y): " AUTO_GEN_PASS
    AUTO_GEN_PASS=${AUTO_GEN_PASS:-y}
    
    if [[ "$AUTO_GEN_PASS" =~ ^[Yy]$ ]]; then
        MYSQL_PASSWORD=$(generate_password)
        REDIS_PASSWORD=$(generate_password)
        ADMIN_PASSWORD=$(generate_password)
        log_info "自动生成密码:"
        log_info "MySQL密码: $MYSQL_PASSWORD"
        log_info "Redis密码: $REDIS_PASSWORD"
        log_info "管理员密码: $ADMIN_PASSWORD"
    else
        # 手动输入密码
        read -s -p "请输入MySQL密码: " MYSQL_PASSWORD
        echo
        read -s -p "请输入Redis密码: " REDIS_PASSWORD
        echo
        read -s -p "请输入管理员密码: " ADMIN_PASSWORD
        echo
    fi
    
    # 确认安装路径
    read -p "请输入安装路径 (默认: /www): " INSTALL_PATH
    INSTALL_PATH=${INSTALL_PATH:-/www}
    
    log_info "安装配置确认:"
    log_info "域名: $DOMAIN"
    log_info "安装路径: $INSTALL_PATH"
    log_info "MySQL密码: $MYSQL_PASSWORD"
    log_info "Redis密码: $REDIS_PASSWORD"
    log_info "管理员密码: $ADMIN_PASSWORD"
    
    read -p "确认开始安装? (y/n): " CONFIRM
    if [[ ! "$CONFIRM" =~ ^[Yy]$ ]]; then
        log_info "安装已取消"
        exit 0
    fi
}

# 更新系统包
update_system() {
    log_step "更新系统包..."
    apt update
}

# 安装基础依赖
install_basic_deps() {
    log_step "安装基础依赖..."
    apt install -y curl wget git unzip gnupg lsb-release make
}

# 安装Docker
install_docker() {
    log_step "安装Docker..."
    
    # 卸载旧版本
    apt remove -y docker docker-engine docker.io containerd runc 2>/dev/null || true
    
    # 安装Docker
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
    sudo apt update && apt install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
    #sh get-docker.sh
    
    # 启动Docker服务
    systemctl start docker
    systemctl enable docker
    
    # 清理安装脚本
    #rm -f get-docker.sh
    
    log_info "Docker安装完成"
}

# 检查命令是否存在
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# 检查Go版本
check_go_version() {
    if command_exists go; then
       return 0
    else
        log_warn "Go未安装"
        return 1
    fi
}

# 检查Node.js版本
check_node_version() {
    if command_exists node; then
        NODE_VERSION=$(node --version | sed 's/v//')
        log_info "检测到Node.js版本: $NODE_VERSION"
        
        # 比较版本
        REQUIRED_VERSION="18.20.4"
        if [[ "$(printf '%s\n' "$REQUIRED_VERSION" "$NODE_VERSION" | sort -V | head -n1)" == "$REQUIRED_VERSION" ]]; then
            log_info "Node.js版本满足要求 (>= $REQUIRED_VERSION)"
            return 0
        else
            log_warn "Node.js版本过低，需要安装 $REQUIRED_VERSION 或更高版本"
            return 1
        fi
    else
        log_warn "Node.js未安装"
        return 1
    fi
}

# 检查NVM
check_nvm() {
    if [[ -s "$HOME/.nvm/nvm.sh" ]]; then
        log_info "检测到NVM已安装"
        return 0
    else
        log_warn "NVM未安装"
        return 1
    fi
}

# 安装Go
install_golang() {
    log_step "安装Go 1.23.2..."
    
    # 下载Go
    wget https://go.dev/dl/go1.23.2.linux-amd64.tar.gz
    
    # 解压到/usr/local
    tar -C /usr/local -xzf go1.23.2.linux-amd64.tar.gz
    
    # 设置环境变量
    echo 'export PATH=$PATH:/usr/local/go/bin' >> /etc/profile
    source /etc/profile
    
    # 清理下载文件
    rm -f go1.23.2.linux-amd64.tar.gz
    
    # 验证安装
    if command_exists go; then
        GO_VERSION=$(go version | awk '{print $3}' | sed 's/go//')
        log_info "Go安装完成，版本: $GO_VERSION"
    else
        log_error "Go安装失败"
        exit 1
    fi
}

# 安装NVM和Node.js
install_nodejs() {
    log_step "安装NVM和Node.js 18..."
    
    # 安装NVM
    curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
    
    # 加载NVM到当前shell
    export NVM_DIR="$HOME/.nvm"
    [ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
    [ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"
    
    # 重新加载环境变量
    source ~/.bashrc
    
    # 安装Node.js 18
    nvm install 18
    nvm use 18
    nvm alias default 18
    
    # 安装yarn
    npm install -g yarn
    
    # 验证安装
    if command_exists node; then
        NODE_VERSION=$(node --version | sed 's/v//')
        NPM_VERSION=$(npm --version)
        YARN_VERSION=$(yarn --version)
        log_info "Node.js安装完成，版本: $NODE_VERSION"
        log_info "npm版本: $NPM_VERSION"
        log_info "yarn版本: $YARN_VERSION"
    else
        log_error "Node.js安装失败"
        exit 1
    fi
}

# 检查Docker
check_docker() {
    if command_exists docker; then
        DOCKER_VERSION=$(docker --version | awk '{print $3}' | sed 's/,//')
        log_info "检测到Docker版本: $DOCKER_VERSION"
        return 0
    else
        log_warn "Docker未安装"
        return 1
    fi
}

# 检查Nginx
check_nginx() {
    if command_exists nginx; then
        NGINX_VERSION=$(nginx -v 2>&1 | awk '{print $3}' | sed 's/nginx\///')
        log_info "检测到Nginx版本: $NGINX_VERSION"
        return 0
    else
        log_warn "Nginx未安装"
        return 1
    fi
}

# 检查并安装所有依赖
check_and_install_all_deps() {
    log_step "检查并安装所有依赖..."
    
    # 检查Docker
    if check_docker; then
        log_info "Docker已安装，跳过安装"
    else
        install_docker
    fi
    
    # 检查Go
    if check_go_version; then
        log_info "Go已满足要求，跳过安装"
    else
        install_golang
    fi
    
    # 检查NVM
    if check_nvm; then
        log_info "NVM已安装，跳过安装"
        # 加载NVM环境
        export NVM_DIR="$HOME/.nvm"
        [ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
        [ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"
    else
        log_info "NVM未安装，将在安装Node.js时一起安装"
    fi
    
    # 检查Node.js
    if check_node_version; then
        log_info "Node.js已满足要求，跳过安装"
    else
        install_nodejs
    fi
    
    # 检查Nginx
    if check_nginx; then
        log_info "Nginx已安装，跳过安装"
    else
        install_nginx
    fi
}

# 安装Nginx
install_nginx() {
    log_step "安装Nginx..."
    apt install -y nginx
    
    # 启动Nginx服务
    systemctl start nginx
    systemctl enable nginx
    
    log_info "Nginx安装完成"
}

# 创建安装目录
create_directories() {
    log_step "创建安装目录..."
}

# 复制源码
copy_source_code() {
    log_step "复制源码..."

    if [[ -d "$INSTALL_PATH" ]]; then
        log_step "备份旧安装目录..."
        mv $INSTALL_PATH $INSTALL_PATH_$(date +%Y%m%d%H%M%S)
        mkdir -p $INSTALL_PATH
    else
        log_step "创建安装目录..."
        mkdir -p "$INSTALL_PATH"
    fi
    
    # 获取脚本所在目录
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    
    cd $SCRIPT_DIR
    cp -r kf-api kf-message kf-bill kf-manager kf-mobile kf-containers config_template cdn $INSTALL_PATH
    log_info "源码复制完成"
}

# 替换配置文件
replace_configs() {
    log_step "替换配置文件..."
    
    cd "$INSTALL_PATH"
    
    # 检测操作系统类型
    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        SED_CMD="sed -i ''"
    else
        # Linux
        SED_CMD="sed -i"
    fi
    
    # 替换kf-api配置
    if [[ -f "config_template/kf_api.yaml" ]]; then
        # 创建临时文件进行替换
        cp config_template/kf_api.yaml kf-api/config/prod.yaml
        $SED_CMD "s/__domain__/$DOMAIN/g" kf-api/config/prod.yaml
        $SED_CMD "s/__mysql__password__/$MYSQL_PASSWORD/g" kf-api/config/prod.yaml
        $SED_CMD "s/__redis__password__/$REDIS_PASSWORD/g" kf-api/config/prod.yaml
        $SED_CMD "s/__admin__password__/$ADMIN_PASSWORD/g" kf-api/config/prod.yaml
        log_info "kf-api配置已更新"
    fi
    
    # 替换kf-message配置
    if [[ -f "config_template/kf_message_prod.yaml" ]]; then
        # 创建临时文件进行替换
        cp config_template/kf_message_prod.yaml kf-message/prod/config.yaml
        $SED_CMD "s/__redis__password__/$REDIS_PASSWORD/g" kf-message/prod/config.yaml
        log_info "kf-message配置已更新"
    fi
    
    # 替换docker-compose配置
    if [[ -f "config_template/docker-compose.yaml" ]]; then
        # 创建临时文件进行替换
        cp config_template/docker-compose.yaml kf-containers/docker-compose.yaml
        $SED_CMD "s/__mysql__password__/$MYSQL_PASSWORD/g" kf-containers/docker-compose.yaml
        $SED_CMD "s/__redis__password__/$REDIS_PASSWORD/g" kf-containers/docker-compose.yaml
        log_info "docker-compose配置已更新"
    fi
    
    # 复制MySQL初始化脚本
    if [[ -f "config_template/init.sql" ]]; then
        cp config_template/init.sql kf-containers/init.sql
        log_info "MySQL初始化脚本已复制"
    fi
    
    # 替换前端环境变量
    replace_frontend_configs
}

# 替换前端配置
replace_frontend_configs() {
    log_info "替换前端配置..."
    
    # 检测操作系统类型
    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        SED_CMD="sed -i ''"
    else
        # Linux
        SED_CMD="sed -i"
    fi
    
    # 替换kf-bill环境变量
    if [[ -d "kf-bill" ]] && [[ -f "config_template/frontend-env.tmpl" ]]; then
        # 创建.env.production文件
        cp config_template/frontend-env.tmpl kf-bill/.env.production
        $SED_CMD "s/__domain__/$DOMAIN/g" kf-bill/.env.production
        log_info "kf-bill环境变量已更新"
    fi
    
    # 替换kf-manager环境变量
    if [[ -d "kf-manager" ]] && [[ -f "config_template/frontend-env.tmpl" ]]; then
        # 创建.env.production文件
        cp config_template/frontend-env.tmpl kf-manager/.env.production
        $SED_CMD "s/__domain__/$DOMAIN/g" kf-manager/.env.production
        log_info "kf-manager环境变量已更新"
    fi
    
    # 替换kf-mobile环境变量
    if [[ -d "kf-mobile" ]] && [[ -f "config_template/frontend-env.tmpl" ]]; then
        # 创建.env.production文件
        cp config_template/frontend-env.tmpl kf-mobile/.env.production
        $SED_CMD "s/__domain__/$DOMAIN/g" kf-mobile/.env.production
        log_info "kf-mobile环境变量已更新"
    fi
}

# 创建Docker网络
create_docker_network() {
    log_step "创建Docker网络..."
    docker network create kf_network 2>/dev/null || log_warn "网络kf_network已存在"
}

# 启动Docker服务
start_docker_services() {
    log_step "启动Docker服务..."
    
    cd "$INSTALL_PATH"
    
    # 启动基础服务 (MySQL, Redis, NSQ)
    if [[ -d "kf-containers" ]]; then
        cd kf-containers
        mkdir -p data/redis_data
        chmod -R 777 data/redis_data
        docker compose up -d
        log_info "基础服务 (MySQL, Redis, NSQ) 启动完成"
        cd ..
    fi
    
    # 启动kf-api服务
    if [[ -d "kf-api" ]]; then
        cd kf-api
        docker compose up -d
        log_info "kf-api服务启动完成"
        cd ..
    fi
    
    # 启动kf-message服务
    if [[ -d "kf-message" ]]; then
        cd kf-message
        docker compose up -d
        log_info "kf-message服务启动完成"
        cd ..
    fi
    
    # 等待MySQL服务完全启动（简化等待逻辑）
    log_info "等待MySQL服务完全启动..."
    
    # 等待最多60秒
    for i in {1..60}; do
        # 检查MySQL容器是否运行
        if docker ps | grep -q "kf-containers-mysql-1"; then
            # 尝试连接MySQL
            mysqlPassword=${MYSQL_PASSWORD:-root}
            
            if docker exec kf-containers-mysql-1 mysql -u root -p"$mysqlPassword" -e "SELECT 1;" >/dev/null 2>&1; then
                log_info "MySQL服务已完全启动"
                break
            fi
        fi
        
        # 等待1秒
        sleep 1
    done
    
    log_info "所有Docker服务启动完成"
}

# 构建后端服务
build_backend_services() {
    log_step "构建后端服务Docker镜像..."
    
    cd "$INSTALL_PATH"
    
    # 构建kf-api
    if [[ -d "kf-api" ]]; then
        cd kf-api
        log_info "构建kf-api Docker镜像..."
        
        # 先构建二进制文件
        make build
        
        # 构建Docker镜像
        make build-image
        
        log_info "kf-api Docker镜像构建完成"
        cd ..
    fi
    
    # 构建kf-message
    if [[ -d "kf-message" ]]; then
        cd kf-message
        log_info "构建kf-message Docker镜像..."
        
        # 先构建二进制文件
        make build
        
        # 构建Docker镜像
        make build-image
        
        log_info "kf-message Docker镜像构建完成"
        cd ..
    fi
}

# 构建前端服务
build_frontend_services() {
    log_step "构建前端服务..."
    
    cd "$INSTALL_PATH"
    
    # 加载NVM环境
    export NVM_DIR="$HOME/.nvm"
    [ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
    [ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"
    
    # 确保使用Node.js 18
    nvm use 18
    npm install -g yarn 
    
    # 构建kf-bill
    if [[ -d "kf-bill" ]]; then
        cd kf-bill
        yarn install
        yarn build
        log_info "kf-bill构建完成"
        cd ..
    fi
    
    # 构建kf-manager
    if [[ -d "kf-manager" ]]; then
        cd kf-manager
        yarn install 
        yarn build 
        log_info "kf-manager构建完成"
        cd ..
    fi
    
    # 构建kf-mobile
    if [[ -d "kf-mobile" ]]; then
        cd kf-mobile
        yarn install 
        yarn build
        log_info "kf-mobile构建完成"
        cd ..
    fi
}

# 配置Nginx
configure_nginx() {
    log_step "配置Nginx..."
    
    # 创建Nginx配置
    cat > /etc/nginx/conf.d/all.conf << EOF
server {
    listen 80;
    server_name bill.$DOMAIN;

    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;

    root $INSTALL_PATH/kf-bill/dist;
    index index.html;

    location /index.html {
        add_header cache-control "no-cache, no-store, must-revalidate";
        add_header pragma "no-cache";
        add_header expires "0";
    }

    location /api/ {
        proxy_pass http://127.0.0.1:8081;
        proxy_set_header x-real-ip \$remote_addr;
        proxy_set_header x-forwarded-for \$proxy_add_x_forwarded_for;
        proxy_set_header host \$host;
    }

    location / {
        try_files \$uri \$uri/ /index.html;
    }
}

server {
    listen 80;
    listen [::]:80;
    server_name manager.$DOMAIN;

    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;

    root $INSTALL_PATH/kf-manager/dist;
    index index.html;
    client_max_body_size 50M;


    location /index.html {
        add_header cache-control "no-cache, no-store, must-revalidate";
        add_header pragma "no-cache";
        add_header expires "0";
    }

    location /api/ {
        proxy_pass http://127.0.0.1:8081;
        proxy_set_header x-real-ip \$remote_addr;
        proxy_set_header x-forwarded-for \$proxy_add_x_forwarded_for;
        proxy_set_header host \$host;
    }

    location / {
        try_files \$uri \$uri/ /index.html;
    }
}

server {
    listen 80;
    listen [::]:80;
    server_name api.$DOMAIN;

    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;


    client_max_body_size 50M;

    location / {
        proxy_pass http://127.0.0.1:8081;
        proxy_set_header x-real-ip \$remote_addr;
        proxy_set_header x-forwarded-for \$proxy_add_x_forwarded_for;
        proxy_set_header host \$host;
    }
}

server {
    listen 80;
    listen [::]:80;
    server_name cdn.$DOMAIN;

    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;

    root $INSTALL_PATH/cdn;
    index index.html;

    location / {
        add_header Access-Control-Allow-Origin *;
        add_header Access-Control-Allow-Methods 'GET, POST, OPTIONS';
        add_header Access-Control-Allow-Headers 'DNT,X-Mx-ReqToken,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Authorization';
        if (\$request_method = 'OPTIONS') {
            return 204;
        }
        try_files \$uri \$uri/ =404;
    }
}
server {
    listen 80;
    server_name goim.$DOMAIN;
    
    # WebSocket服务
    location / {
        proxy_pass http://127.0.0.1:9000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF

    cat > /etc/nginx/sites-enabled/default << EOF
server {
	listen 80 default_server;
	listen [::]:80 default_server;
	gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;
    root $INSTALL_PATH/kf-mobile/dist;
    index index.html;
    location / {
        add_header Access-Control-Allow-Origin *;
        add_header Access-Control-Allow-Methods 'GET, POST, OPTIONS';
        add_header Access-Control-Allow-Headers 'DNT,X-Mx-ReqToken,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Authorization';
        if (\$request_method = 'OPTIONS') {
            return 204;
        }
        try_files \$uri \$uri/ /index.html;
    }
	server_name _;
}
EOF

    # 测试配置
    nginx -t
    
    # 重启Nginx
    systemctl restart nginx
    
    log_info "Nginx配置完成"
}

# 创建服务启动脚本
create_service_scripts() {
    log_step "创建服务管理脚本..."
    
    # 创建启动脚本
    cat > "$INSTALL_PATH/start.sh" << 'EOF'
#!/bin/bash

# 天马云客服系统启动脚本

set -e

INSTALL_PATH="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$INSTALL_PATH"

# 启动基础服务 (MySQL, Redis, NSQ)
echo "启动基础服务..."
cd kf-containers
docker compose up -d
cd ..

# 启动kf-api服务
echo "启动kf-api服务..."
cd kf-api
docker compose up -d
cd ..

# 启动kf-message服务
echo "启动kf-message服务..."
cd kf-message
docker compose up -d
cd ..

echo "所有服务启动完成"
echo "查看服务状态: docker ps"
echo "查看日志: docker compose logs -f (在各个服务目录下)"
EOF

    # 创建停止脚本
    cat > "$INSTALL_PATH/stop.sh" << 'EOF'
#!/bin/bash

# 天马云客服系统停止脚本

INSTALL_PATH="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$INSTALL_PATH"

# 停止kf-message服务
echo "停止kf-message服务..."
cd kf-message
docker compose down
cd ..

# 停止kf-api服务
echo "停止kf-api服务..."
cd kf-api
docker compose down
cd ..

# 停止基础服务
echo "停止基础服务..."
cd kf-containers
docker compose down
cd ..

echo "所有服务已停止"
EOF

    # 创建重启脚本
    cat > "$INSTALL_PATH/restart.sh" << 'EOF'
#!/bin/bash

# 天马云客服系统重启脚本

INSTALL_PATH="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$INSTALL_PATH"

echo "重启服务..."
./stop.sh
sleep 2
./start.sh
EOF

    # 设置执行权限
    chmod +x "$INSTALL_PATH"/{start.sh,stop.sh,restart.sh}
    
    log_info "服务管理脚本已创建"
}

# 保存配置信息
save_config() {
    log_step "保存配置信息..."
    
    cat > "$INSTALL_PATH/install.conf" << EOF
# 天马云客服系统安装配置
# 安装时间: $(date)

DOMAIN=$DOMAIN
INSTALL_PATH=$INSTALL_PATH
MYSQL_PASSWORD=$MYSQL_PASSWORD
REDIS_PASSWORD=$REDIS_PASSWORD
ADMIN_PASSWORD=$ADMIN_PASSWORD

# 服务端口
API_PORT=8081
MESSAGE_PORT=9000
NGINX_PORT=80

# 管理界面访问地址
ADMIN_URL=http://$DOMAIN
EOF
    
    log_info "配置信息已保存到 $INSTALL_PATH/install.conf"
}

# 显示安装完成信息
show_completion_info() {
    log_step "安装完成！"
    
    echo
    echo "=========================================="
    echo "天马云客服系统安装完成"
    echo "=========================================="
    echo "域名: $DOMAIN"
    echo "安装路径: $INSTALL_PATH"
    echo "客服后台: http://manager.$DOMAIN"
    echo "总后台: http://bill.$DOMAIN"
    echo "管理员账号: admin"
    echo "管理员密码: $ADMIN_PASSWORD"
    echo "MySQL密码: $MYSQL_PASSWORD"
    echo "Redis密码: $REDIS_PASSWORD"
    echo
    echo "服务管理命令:"
    echo "启动服务: $INSTALL_PATH/start.sh"
    echo "停止服务: $INSTALL_PATH/stop.sh"
    echo "重启服务: $INSTALL_PATH/restart.sh"
    echo
    echo "查看日志:"
    echo "kf-api日志: docker compose logs -f (在 $INSTALL_PATH/kf-api 目录下)"
    echo "kf-message日志: docker compose logs -f (在 $INSTALL_PATH/kf-message 目录下)"
    echo "基础服务日志: docker compose logs -f (在 $INSTALL_PATH/kf-containers 目录下)"
    echo "查看所有容器: docker ps"
    echo "=========================================="
}

# 主安装流程
main() {
    log_info "开始安装天马云客服系统..."
    
    check_root
    get_user_input
    update_system
    install_basic_deps
    check_and_install_all_deps
    create_directories
    copy_source_code
    replace_configs
    create_docker_network
    build_backend_services
    start_docker_services
    build_frontend_services
    configure_nginx
    create_service_scripts
    save_config
    show_completion_info
    
    log_info "安装完成！"
}

# 运行主函数
main "$@" 