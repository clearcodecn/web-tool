<template>
  <div>
    <a-table bordered :data-source="state.dataSource" :loading="state.loading" :columns="state.columns" size="middle"
      :scroll="{ x: 1200 }" :pagination="false">
      <template #bodyCell="{ column, text, record }">
        <template v-if="column.dataIndex === 'title'">
          <TextTip :text="record.title" />
        </template>
        <template v-if="column.dataIndex === 'content'">
          <template v-if="record.type === 'video'">
            <MaterialPreview mediaType="video" :url="mergeCdn(record.content)" :thumb="mergeCdn(record.thumb)">
            </MaterialPreview>
          </template>
          <template v-else-if="record.type === 'image'">
            <MaterialPreview :url="mergeCdn(record.content)"></MaterialPreview>
          </template>
          <template v-else>
            <TextTip :text="record.content" />
          </template>
        </template>
        <template v-if="column.dataIndex === 'sort'">
          <a-space>
            <a-input-number id="inputNumber" v-model:value="record.sort" :min="0" :max="999"
              @change="onChangeStatus(record)" />
          </a-space>
        </template>
        <template v-if="column.dataIndex === 'enable'">
          <a-switch v-model:checked="record.enable" @change="onChangeStatus(record)" />
        </template>
        <template v-if="column.dataIndex === 'operation'">
          <a-space>
            <span class="table-link-action" @click="onEdit(record)">
              <EditOutlined />修改
            </span>
            <a-popconfirm title="确定要删除吗？" @confirm="onDelete(record)">
              <span class="table-link-action">
                <DeleteOutlined />删除
              </span>
            </a-popconfirm>
          </a-space>
        </template>
      </template>
    </a-table>
    <a-pagination size="small" v-model:current="searchParams.page" :defaultPageSize="20" :total="state.total"
      @change="onPageChange" show-size-changer show-quick-jumper :show-total="(total) => `共 ${total} 条`" />

    <MaterialDrawer :max-sort="state.maxSort" v-model:model-value="state.showDia" :msgType="searchParams.msgType"
      :action-type="state.actionType" :edit-data="state.editData" @refesh="getTableList"></MaterialDrawer>
  </div>
</template>

<script lang="ts" setup>
import { computed, ref, onMounted, reactive } from 'vue'
import { ReloadOutlined, EditOutlined, DeleteOutlined, SaveTwoTone } from '@ant-design/icons-vue'
import MaterialDrawer from '@/components/MaterialDrawer/index.vue'
import TextTip from '@/components/TextTip/index.vue'
import MaterialPreview from '@/components/MaterialPreview/index.vue'
import { message as Message } from 'ant-design-vue'
import { MessageApi } from '@/webapi/index'
import { welcomColumns, quickColumns, smartColumns } from './config'
import { mergeCdn } from '@/utils/util'

const props = defineProps({
  type: {
    type: String,
    default: 'welcome_msg' //doc:"快捷回复=quick_reply, 欢迎语=welcome_msg, 智能回复
  }
})
const state = reactive({
  dataSource: [],
  editableData: {},
  editData: {},
  actionType: 'add',
  showDia: false,
  loading: false,
  total: 0,
  maxSort: 0,
  columns: []
})

const searchParams = reactive({
  page: 1,
  pageSize: 20,
  msgType: props.type
})

const onDelete = async (record) => {
  let params = {
    id: record.id
  }
  let { code, data = {}, message }: any = await MessageApi.delWelcome(params)
  if (code === 200) {
    Message.success('删除成功')
    getTableList()
  } else {
    Message.error(message || '请求失败')
  }
}
const onPageChange = (page, pageSize) => {
  searchParams.page = page
  searchParams.pageSize = pageSize
  getTableList()
}

const onRefesh = () => {
  getTableList()
}
// 新增欢迎语
const onAddMsg = () => {
  state.actionType = 'add'
  state.showDia = true
}
const onEdit = (item) => {
  state.actionType = 'edit'
  state.editData = item
  state.showDia = true
}

const onChangeStatus = async (record) => {
  let params: any = {
    ...record,
    msgType: searchParams.msgType
  }
  let { code, message }: any = await MessageApi.updateWelcome(params)
  if (code === 200) {
    Message.success('更新成功！')
    getTableList()
  } else {
    Message.error(message || '请求失败')
  }
}

const getTableList = async () => {
  let params: any = {
    ...searchParams
  }
  state.loading = true
  let { code, data = {}, message }: any = await MessageApi.getWelcomeList(params)
  state.loading = false
  if (code === 200) {
    state.dataSource = (data.list || []).map((el) => {
      if (el.sort > state.maxSort) {
        state.maxSort = el.sort
      }
      return el
    })
    state.total = data.total || 0
  } else {
    Message.error(message || '请求失败')
  }
}
defineExpose({
  getTableList,
  onAddMsg,
  onRefesh
})

onMounted(() => {
  if (props.type === 'welcome_msg') {
    state.columns = welcomColumns
  }
  if (props.type === 'quick_reply') {
    state.columns = quickColumns
  }
  if (props.type === 'smart_msg') {
    state.columns = smartColumns
  }
})
</script>
<style lang="less" scoped>
.anticon-edit span {
  margin-inline-start: 0;
}
</style>
