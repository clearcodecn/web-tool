export const welcomColumns = [
  {
    title: '回复内容',
    key: 'content',
    align: 'center',
    ellipsis: true,
    dataIndex: 'content'
  },
  {
    title: '排序',
    key: 'sort',
    align: 'center',
    dataIndex: 'sort',
    width: 200
  },
  {
    title: '是否启用',
    align: 'center',
    dataIndex: 'enable',
    key: 'enable',
    width: 150
  },
  {
    title: '操作',
    align: 'center',
    fixed: 'right',
    dataIndex: 'operation',
    width: 200
  }
]

export const quickColumns = [
  {
    title: '标题',
    key: 'title',
    align: 'center',
    ellipsis: true,
    dataIndex: 'title',
    width: 300
  },
  {
    title: '回复内容',
    key: 'content',
    align: 'center',
    ellipsis: true,
    dataIndex: 'content'
  },
  {
    title: '发送顺序(小到大)',
    key: 'sort',
    align: 'center',
    dataIndex: 'sort',
    width: 200
  },
  {
    title: '是否启用',
    align: 'center',
    dataIndex: 'enable',
    key: 'enable',
    width: 150
  },
  {
    title: '操作',
    align: 'center',
    fixed: 'right',
    dataIndex: 'operation',
    width: 200
  }
]


export const smartColumns = [
  {
    title: '标题',
    key: 'title',
    align: 'center',
    ellipsis: true,
    dataIndex: 'title',
    width: 300
  },
  {
    title: '回复内容',
    key: 'content',
    align: 'center',
    ellipsis: true,
    dataIndex: 'content'
  },
  {
    title: '发送顺序(小到大)',
    key: 'sort',
    align: 'center',
    dataIndex: 'sort',
    width: 200
  },
  {
    title: '是否启用',
    align: 'center',
    dataIndex: 'enable',
    key: 'enable',
    width: 150
  },
  {
    title: '操作',
    align: 'center',
    fixed: 'right',
    dataIndex: 'operation',
    width: 200
  }
]
