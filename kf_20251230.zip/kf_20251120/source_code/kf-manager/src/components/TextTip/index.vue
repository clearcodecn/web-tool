<template>
  <a-popover>
    <template #content>
      <div style="max-width: 600px;max-height: 400px;overflow-y: scroll; break-all" v-html="props.text"></div>
    </template>
    <span class="ellipsis-text">{{ stripHtml(props.text) }}</span>
  </a-popover>
</template>

<script lang="ts" setup name="HeaderNotice">
const props = defineProps({
  text: {
    type: String,
    default: ''
  }
})

const stripHtml = (value) => {
  if (!value) return ''
  // 去除 HTML 标签
  return value.replace(/<[^>]*>/g, '')
}
</script>

<style lang="less" scoped>
.ellipsis-text {
  display: inline-block;
  width: -webkit-fill-available;
  overflow: hidden;
  text-overflow: ellipsis;
}
</style>
