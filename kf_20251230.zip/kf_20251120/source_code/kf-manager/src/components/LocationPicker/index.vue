<template>
    <div class="location-picker">
        <div class="search-box">
            <a-input-search v-model:value="searchKeyword" placeholder="搜索地点" @search="onSearchLocation" />
        </div>
        <div class="map-container">
            <div id="map" class="map"></div>
        </div>
        <div class="location-list" v-if="searchResults.length > 0">
            <div v-for="item in searchResults" :key="item.uid" class="location-item" @click="selectLocation(item)">
                <div class="location-name">{{ item.title }}</div>
                <div class="location-address">{{ item.address }}</div>
            </div>
        </div>
        <div class="selected-location" v-if="selectedLocation">
            <div class="location-info">
                <div class="location-name">{{ selectedLocation.title }}</div>
                <div class="location-address">{{ selectedLocation.address }}</div>
            </div>
            <div class="action-buttons">
                <a-button type="primary" @click="confirmLocation">确认发送</a-button>
                <a-button @click="clearSelection">重新选择</a-button>
            </div>
        </div>
    </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, watch, nextTick } from 'vue';
import { message } from 'ant-design-vue';
import { loadBMapScript, getLocationByIP, getStaticMapUrl } from '@/utils/baiduMap';

const props = defineProps({
    visible: Boolean
});

const emit = defineEmits(['select', 'close']);

const searchKeyword = ref('');
const searchResults = ref([]);
const selectedLocation = ref(null);
let map = null;
let localSearch = null;
let marker = null;

// 初始化地图
const initMap = async () => {
    try {
        await loadBMapScript();
        await nextTick();

        const mapContainer = document.getElementById('map');
        if (!mapContainer) {
            console.error('Map container not found');
            return;
        }

        if (!map) {
            map = new BMap.Map('map');

            // 获取IP定位
            const location = await getLocationByIP();
            const point = new BMap.Point(location.lng, location.lat);

            map.centerAndZoom(point, 12);
            map.enableScrollWheelZoom();

            // 添加点击事件
            map.addEventListener('click', (e) => {
                const point = e.point;
                searchLocationByPoint(point);
            });
        }
    } catch (error) {
        console.error('Failed to load Baidu Maps:', error);
        message.error('地图加载失败');
    }
};

// 搜索位置
const onSearchLocation = (value) => {
    if (!value) return;

    if (!localSearch) {
        localSearch = new BMap.LocalSearch(map, {
            onSearchComplete: (results) => {
                if (!results) {
                    message.warning('搜索失败');
                    searchResults.value = [];
                    return;
                }

                const pois = [];
                // 遍历所有结果
                for (let i = 0; i < results.getNumPois(); i++) {
                    const poi = results.getPoi(i);
                    if (poi && poi.point) {
                        pois.push({
                            uid: `poi_${Date.now()}_${i}`,
                            title: poi.title || poi.name || '未知地点',
                            address: poi.address || '未知地址',
                            point: poi.point
                        });
                    }
                }

                if (pois.length > 0) {
                    searchResults.value = pois;
                    // 将地图中心移动到第一个结果
                    const firstResult = pois[0];
                    map.centerAndZoom(firstResult.point, 15);
                } else {
                    message.warning('未找到相关地点');
                    searchResults.value = [];
                }
            }
        });
    }

    localSearch.search(value);
};

// 根据坐标点搜索位置
const searchLocationByPoint = (point) => {
    const geocoder = new BMap.Geocoder();
    geocoder.getLocation(point, (result) => {
        if (result && result.address) {
            const location = {
                uid: `point_${Date.now()}`,
                title: result.address,
                address: result.address,
                point: point
            };
            selectLocation(location);
        } else {
            message.warning('无法获取该位置信息');
        }
    });
};

// 选择位置
const selectLocation = (location) => {
    if (!location || !location.point) {
        message.warning('无效的位置信息');
        return;
    }

    selectedLocation.value = location;
    // 更新地图标记
    if (marker) {
        marker.setPosition(location.point);
    } else {
        marker = new BMap.Marker(location.point);
        map.addOverlay(marker);
    }
    map.centerAndZoom(location.point, 15);
};

// 确认发送位置
const confirmLocation = () => {
    if (selectedLocation.value) {
        emit('select', {
            lat: selectedLocation.value.point.lat,
            lng: selectedLocation.value.point.lng,
            address: selectedLocation.value.address
        });
        emit('close');
    }
};

// 清除选择
const clearSelection = () => {
    selectedLocation.value = null;
    if (marker) {
        map.removeOverlay(marker);
        marker = null;
    }
};

onMounted(() => {
    if (props.visible) {
        nextTick(() => {
            initMap();
        });
    }
});

onUnmounted(() => {
    if (map) {
        map.clearOverlays();
        map = null;
    }
    if (localSearch) {
        localSearch = null;
    }
    if (marker) {
        marker = null;
    }
});

watch(() => props.visible, (newVal) => {
    if (newVal) {
        nextTick(() => {
            initMap();
        });
    }
});
</script>

<style lang="less" scoped>
.location-picker {
    display: flex;
    flex-direction: column;
    gap: 16px;

    .search-box {
        width: 100%;
    }

    .map-container {
        width: 100%;
        height: 400px;

        .map {
            width: 100%;
            height: 100%;
        }
    }

    .location-list {
        max-height: 200px;
        overflow-y: auto;

        .location-item {
            padding: 12px;
            border-bottom: 1px solid #eee;
            cursor: pointer;

            &:hover {
                background: #f5f5f5;
            }

            .location-name {
                font-weight: 500;
                margin-bottom: 4px;
            }

            .location-address {
                font-size: 12px;
                color: #666;
            }
        }
    }

    .selected-location {
        padding: 16px;
        background: #f5f5f5;
        border-radius: 4px;

        .location-info {
            margin-bottom: 16px;

            .location-name {
                font-weight: 500;
                margin-bottom: 4px;
            }

            .location-address {
                font-size: 12px;
                color: #666;
            }
        }

        .action-buttons {
            display: flex;
            gap: 8px;
            justify-content: flex-end;
        }
    }
}
</style>