<template>
  <a-popover overlayClassName="my-emoji-popover" placement="topLeft" trigger="click">
    <template #content>
      <EmojiPicker :native="true" @select="onSelectEmoji" />
    </template>
    <SvgIcon name="icon-smile" width="28px" height="28px" style="cursor: pointer" />
  </a-popover>
</template>
<script setup>
import { defineEmits } from 'vue'
import EmojiPicker from 'vue3-emoji-picker'
import 'vue3-emoji-picker/css'
import SvgIcon from '@/components/SvgIcon/index.vue'

const emits = defineEmits(['on-change'])
const onSelectEmoji = (emoji) => {
  emits('on-change', emoji)
}
</script>
<style lang="less" scoped>
.emoji-text {
  border: none;
  background: transparent;
  cursor: pointer;
}
</style>
<style lang="less">
.my-emoji-popover {
  .ant-popover-inner {
    padding: 0;
    box-shadow: none;
  }
}
</style>
