<template>
    <div class="location-message" @click="showDetail">
        <div class="location-preview">
            <img :src="staticMapUrl" alt="Location" class="map-preview" />
            <div class="location-info">
                <div class="location-name">{{ address }}</div>
                <div class="location-address">{{ address }}</div>
            </div>
        </div>
    </div>

    <a-modal v-model:visible="detailVisible" title="位置详情" :footer="null" width="600px" :destroyOnClose="true">
        <div class="location-detail">
            <div id="detail-map" class="detail-map"></div>
            <div class="detail-info">
                <div class="detail-name">{{ address }}</div>
                <div class="detail-address">{{ address }}</div>
            </div>
        </div>
    </a-modal>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted, nextTick, watch } from 'vue';
import { loadBMapScript, getStaticMapUrl } from '@/utils/baiduMap';

const props = defineProps({
    lat: {
        type: Number,
        required: true
    },
    lng: {
        type: Number,
        required: true
    },
    address: {
        type: String,
        required: true,
    },
});

const detailVisible = ref(false);
let detailMap = null;
let marker = null;

const staticMapUrl = computed(() => {
    if (!props.lat || !props.lng) {
        return '';
    }
    return getStaticMapUrl(props.lat, props.lng);
});

const initMap = async () => {
    try {
        await loadBMapScript();
        await nextTick();

        const mapContainer = document.getElementById('detail-map');
        if (!mapContainer) {
            console.error('Map container not found');
            return;
        }

        if (!detailMap) {
            detailMap = new BMap.Map('detail-map', {
                enableMapClick: false,
                displayOptions: {
                    building: false
                }
            });
            const point = new BMap.Point(props.lng, props.lat);
            detailMap.centerAndZoom(point, 15);
            detailMap.enableScrollWheelZoom();
            marker = new BMap.Marker(point);
            detailMap.addOverlay(marker);
        } else {
            const point = new BMap.Point(props.lng, props.lat);
            detailMap.centerAndZoom(point, 15);
            if (marker) {
                marker.setPosition(point);
            } else {
                marker = new BMap.Marker(point);
                detailMap.addOverlay(marker);
            }
        }
    } catch (error) {
        console.error('Failed to load Baidu Maps:', error);
    }
};

const showDetail = () => {
    detailVisible.value = true;
    setTimeout(() => {
        initMap();
    }, 100);
};

onMounted(() => {
    if (detailVisible.value) {
        initMap();
    }
});

onUnmounted(() => {
    if (detailMap) {
        detailMap.clearOverlays();
        detailMap = null;
    }
    if (marker) {
        marker = null;
    }
});

watch(
    () => [props.lat, props.lng],
    ([newLat, newLng], [oldLat, oldLng]) => {
        if (newLat !== oldLat || newLng !== oldLng) {
            initMap();
        }
    }
);
</script>

<style lang="less" scoped>
.location-message {
    cursor: pointer;
    width: 300px;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);

    .location-preview {
        position: relative;

        .map-preview {
            width: 100%;
            height: 150px;
            object-fit: cover;
        }

        .location-info {
            padding: 8px;
            background: #fff;

            .location-name {
                font-weight: 500;
                margin-bottom: 4px;
            }

            .location-address {
                font-size: 12px;
                color: #666;
            }
        }
    }
}

.location-detail {
    .detail-map {
        width: 100%;
        height: 300px;
        margin-bottom: 16px;
    }

    .detail-info {
        padding: 16px;

        .detail-name {
            font-size: 16px;
            font-weight: 500;
            margin-bottom: 8px;
        }

        .detail-address {
            color: #666;
        }
    }
}
</style>