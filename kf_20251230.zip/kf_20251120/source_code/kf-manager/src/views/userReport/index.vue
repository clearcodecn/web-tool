<template>
  <div class="kf-body">
    <a-card class="search-card">
      <a-form :model="searchParams" class="search-form">
        <a-form-item label="搜索用户">
          <a-input-search v-model:value="searchParams.searchBy" placeholder="请输入" allowClear @search="onSearch" />
        </a-form-item>
        <a-form-item label="创建时间">
          <a-range-picker v-model:value="searchParams.dateRange" @change="onDateRangeChange" />
        </a-form-item>
        <a-form-item>
          <a-space>
            <a-button @click="onReset">重置</a-button>
            <a-button type="primary" @click="onSearch">查询</a-button>
            <a-button type="primary" @click="onExport">导出</a-button>
          </a-space>
        </a-form-item>
      </a-form>
    </a-card>

    <a-row :gutter="16" class="statistics">
      <a-col :span="4">
        <a-card>
          <template #title>用户总数</template>
          <div class="statistic-value">{{ statistics.totalUsers }}</div>
        </a-card>
      </a-col>
      <a-col :span="4">
        <a-card>
          <template #title>总访问量</template>
          <div class="statistic-value">{{ statistics.visitStats.totalVisitCount }}</div>
        </a-card>
      </a-col>
      <a-col :span="4">
        <a-card>
          <template #title>今日访问量</template>
          <div class="statistic-value">{{ statistics.visitStats.dailyVisitCount }}</div>
        </a-card>
      </a-col>
      <a-col :span="4">
        <a-card>
          <template #title>今日新增用户</template>
          <div class="statistic-value">{{ statistics.messageStats.dailyNewUserCount }}</div>
        </a-card>
      </a-col>
      <a-col :span="4">
        <a-card>
          <template #title>总消息数</template>
          <div class="statistic-value">{{ statistics.messageStats.totalMessageCount }}</div>
        </a-card>
      </a-col>
      <a-col :span="4">
        <a-card>
          <template #title>今日消息数</template>
          <div class="statistic-value">{{ statistics.messageStats.dailyMessageCount }}</div>
        </a-card>
      </a-col>
    </a-row>

    <a-table bordered :columns="columns" :data-source="tableData" :loading="loading" :pagination="pagination"
      size="middle" :scroll="{ x: 'max-content' }" @change="handleTableChange">
      <template #bodyCell="{ column, record }">
        <template v-if="column.key === 'avatar'">
          <a-avatar :src="mergeCdn(record.avatar)" :size="32">
            <template v-if="!record.avatar" #icon>
              <UserOutlined />
            </template>
          </a-avatar>
        </template>
        <template v-if="column.key === 'dailyNewUser'">
          <a-tag :color="record.dailyNewUser ? 'green' : ''">
            {{ record.dailyNewUser ? '今日新增' : '' }}
          </a-tag>
        </template>
        <template v-if="column.key === 'isProxy'">
          <a-tag :color="record.isProxy === 1 ? 'red' : 'green'">
            {{ record.isProxy === 1 ? '是' : '否' }}
          </a-tag>
        </template>
        <template v-if="column.key === 'createdAt'">
          {{ formatDate(record.createdAt) }}
        </template>
        <template v-if="column.key === 'lastChatAt'">
          {{ record.lastChatAt ? formatTimestamp(record.lastChatAt) : '-' }}
        </template>
        <template v-if="column.key === 'action'">
          <a-space>
            <a-popconfirm title="确定要删除该用户吗？" @confirm="handleDelete(record)">
              <a-button type="link" danger>删除</a-button>
            </a-popconfirm>
          </a-space>
        </template>
      </template>
    </a-table>
  </div>
</template>

<script lang="ts" setup>
import { ref, reactive, onMounted } from 'vue'
import { getUserReportList, exportUserReport } from '@/webapi/report'
import { delUser } from '@/webapi/chat'
import type { TablePaginationConfig } from 'ant-design-vue'
import dayjs from 'dayjs'
import { UserOutlined, ReloadOutlined } from '@ant-design/icons-vue'
import { mergeCdn } from '@/utils/util'

const columns = [
  {
    title: '头像',
    dataIndex: 'avatar',
    key: 'avatar',
    width: 80,
  },
  {
    title: '昵称',
    dataIndex: 'nickName',
    key: 'nickName',
    width: 120,
  },
  {
    title: '手机号',
    dataIndex: 'mobile',
    key: 'mobile',
    width: 120,
  },
  {
    title: '备注名',
    dataIndex: 'remarkName',
    key: 'remarkName',
    width: 120,
  },
  {
    title: '创建时间',
    dataIndex: 'createdAt',
    key: 'createdAt',
    width: 160,
  },
  {
    title: '最后聊天时间',
    dataIndex: 'lastChatAt',
    key: 'lastChatAt',
    width: 160,
  },
  {
    title: '停留时长(s)',
    dataIndex: 'staySeconds',
    key: 'staySeconds',
    width: 160,
  },
  {
    title: '扫码次数',
    dataIndex: 'scanCount',
    key: 'scanCount',
    width: 100,
  },
  {
    title: '状态',
    dataIndex: 'dailyNewUser',
    key: 'dailyNewUser',
    width: 100,
  },
  {
    title: 'IP地址',
    dataIndex: 'ip',
    key: 'ip',
    width: 120,
  },
  {
    title: '地区',
    dataIndex: 'area',
    key: 'area',
    width: 120,
  },
  {
    title: '设备类型',
    dataIndex: 'deviceType',
    key: 'deviceType',
    width: 120,
  },
  {
    title: '浏览器',
    dataIndex: 'browser',
    key: 'browser',
    width: 120,
  },
  {
    title: '网络类型',
    dataIndex: 'networkType',
    key: 'networkType',
    width: 120,
  },
  {
    title: '是否代理',
    dataIndex: 'isProxy',
    key: 'isProxy',
    width: 100,
  },
  {
    title: '操作',
    key: 'action',
    fixed: 'right',
    width: 100,
  },
]

const loading = ref(false)
const tableData = ref([])

const searchParams = reactive({
  searchBy: '',
  dateRange: [],
})

const statistics = reactive({
  totalUsers: 0,
  visitStats: {
    totalVisitCount: 0,
    dailyVisitCount: 0
  },
  messageStats: {
    totalMessageCount: 0,
    dailyMessageCount: 0,
    dailyNewUserCount: 0
  }
})

const pagination = reactive({
  current: 1,
  pageSize: 20,
  total: 0,
})

const formatDate = (date: string) => {
  return dayjs(date).format('YYYY-MM-DDD HH:mm:ss')
}

const formatTimestamp = (timestamp: number) => {
  return dayjs.unix(timestamp).format('YYYY-MM-DD HH:mm:ss')
}

const handleDelete = async (record: any) => {
  try {
    await delUser(record.uuid)
    fetchData()
  } catch (error) {
    console.error('Failed to delete user:', error)
  }
}

const onReset = () => {
  searchParams.searchBy = ''
  searchParams.dateRange = []
  pagination.current = 1
  fetchData()
}

const onRefesh = () => {
  fetchData()
}

const fetchData = async () => {
  loading.value = true
  try {
    const params = {
      page: pagination.current,
      pageSize: pagination.pageSize,
      searchBy: searchParams.searchBy,
      startAt: searchParams.dateRange?.[0]?.unix(),
      endAt: searchParams.dateRange?.[1]?.unix(),
    }

    const res = await getUserReportList(params)
    tableData.value = res.data.items
    pagination.total = res.data.total
    statistics.totalUsers = res.data.total
    statistics.visitStats = res.data.visitStats
    statistics.messageStats = res.data.messageStats
  } catch (error) {
    console.error('Failed to fetch user report:', error)
  } finally {
    loading.value = false
  }
}

const handleTableChange = (pag: TablePaginationConfig) => {
  pagination.current = pag.current || 1
  pagination.pageSize = pag.pageSize || 10
  fetchData()
}

const onSearch = () => {
  pagination.current = 1
  fetchData()
}

const onDateRangeChange = () => {
  pagination.current = 1
  fetchData()
}

const onExport = async () => {
  try {
    const params = {
      searchBy: searchParams.searchBy,
      startAt: searchParams.dateRange?.[0]?.unix(),
      endAt: searchParams.dateRange?.[1]?.unix(),
    }

    const response = await exportUserReport(params)

    // Create a blob from the response
    const blob = new Blob([response], { type: 'text/csv;charset=utf-8;' })

    // Create a link element
    const link = document.createElement('a')
    const url = URL.createObjectURL(blob)

    // Set the filename
    const filename = `user_reports_${dayjs().format('YYYYMMDDHHmmss')}.csv`

    // Set the link attributes
    link.setAttribute('href', url)
    link.setAttribute('download', filename)
    link.style.visibility = 'hidden'

    // Append to body, click and remove
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  } catch (error) {
    console.error('Failed to export user report:', error)
  }
}

onMounted(() => {
  fetchData()
})
</script>

<style lang="less" scoped>
.kf-body {
  .top-action {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    padding-bottom: 12px;
  }

  .refesh {
    cursor: pointer;
    width: 27px;
    height: 27px;
    line-height: 24px;
    text-align: center;
    display: inline-block;
    border-radius: 50%;
    border: 1px solid #eee;
    background-color: #fff;

    &:hover {
      background-color: #eee;
    }
  }

  .search-card {
    margin-bottom: 24px;
  }

  .search-form {
    display: flex;
    flex-wrap: wrap;

    .ant-form-item {
      width: 30%;
      padding-right: 3%;

      .ant-form-item-label {
        width: 120px;
      }
    }
  }

  .statistics {
    margin-bottom: 24px;

    .statistic-value {
      font-size: 24px;
      font-weight: bold;
      color: #1890ff;
    }
  }

  .table-card {
    margin-top: 24px;
  }
}
</style>