<template>
  <div class="chat-user">
    <div class="tabs">
      <!-- @change="onChangeTab" -->
      <a-tabs v-model:activeKey="activeKey" style="width: 100%" @change="onChangeTab">
        <a-tab-pane v-for="tab in tabs" :key="tab.value" :tab="tab.label"></a-tab-pane>
      </a-tabs>
      <div v-if="activeKey === 0">
        <div class="user-info-section">
          <div class="info-item">
            <span class="info-label">扫码次数</span>
            <span class="info-value">{{ toUser.user.scanCount || 0 }}</span>
          </div>
          <div class="info-item">
            <span class="info-label">浏览器</span>
            <span class="info-value">{{ userInfo.browserType }}</span>
          </div>
          <div class="info-item">
            <span class="info-label">设备类型</span>
            <span class="info-value">{{ userInfo.deviceType }}</span>
          </div>
          <div class="info-item">
            <span class="info-label">系统类型</span>
            <span class="info-value">{{ userInfo.systemType }}</span>
          </div>
          <div class="info-item">
            <span class="info-label">首次扫码时间</span>
            <span class="info-value">{{ formatTime(toUser.user.created_at) }}</span>
          </div>
          <div class="info-item">
            <span class="info-label">用户备注</span>
            <a-input v-model:value="formState.remarkName" placeholder="请输入备注信息" @blur="onUpdateUser"
              @keyup.enter="onUpdateUser" class="info-input" />
          </div>
          <div class="info-item">
            <span class="info-label">聊天置顶</span>
            <a-switch v-model:checked="isTop" @change="handleTopChange" class="info-switch" />
          </div>
          <div class="action-buttons">
            <a-button type="primary" danger @click="handleDelete" class="delete-btn">删除</a-button>
            <a-button type="primary" @click="handleBlock" class="block-btn">{{ isBlocked ? '取消拉黑' : '拉黑' }}</a-button>
          </div>
        </div>
      </div>
      <!-- 快捷回复 -->
      <div v-if="activeKey === 1" class="quick-reply-list">
        <div v-for="item in quickReplyList" :key="item.id" class="quick-reply-item">
          <div class="quick-reply-content" @click="handlePreview(item)">
            <div class="quick-reply-title">
              <span>{{ item.title }}</span>
            </div>
          </div>
          <div class="quick-reply-actions">
            <a-button type="primary" @click="sendQuickReply(item)">发送</a-button>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- 预览模态框 -->
  <a-modal v-model:visible="previewVisible" title="预览" :footer="null" :width="400" class="preview-modal">
    <div class="preview-content">
      <div class="preview-body">
        <div v-if="previewItem?.type === 'text'" class="text-preview">
          <div class="text-content">{{ previewItem?.content }}</div>
        </div>
        <div v-else-if="previewItem?.type === 'image'" class="media-preview">
          <MaterialPreview :videoW="280" :videoH="160" :url="mergeCdn(previewItem?.content)"></MaterialPreview>
        </div>
        <div v-else-if="previewItem?.type === 'video'" class="media-preview">
          <MaterialPreview :videoW="280" :videoH="160" mediaType="video" :url="mergeCdn(previewItem?.content)">
          </MaterialPreview>
        </div>
      </div>
    </div>
  </a-modal>

  <!-- 隐藏的预览组件 -->
  <div style="position: absolute; z-index: -1">
    <MaterialPreview ref="previewRef" :url="mergeCdn(previewUrl)" :mediaType="previewMediaType" :autoPreview="true" />
  </div>
</template>
<script setup>
import { defineProps, toRefs, ref, watch, defineEmits, nextTick, computed } from 'vue'
import { ChatApi, MessageApi } from '@/webapi/index'
import { reactive } from 'vue'
import { message, Modal } from 'ant-design-vue'
import ls from '@/utils/Storage'
import { SendOutlined, CloseCircleOutlined } from '@ant-design/icons-vue'
import { showText } from '@/utils/util'
import MaterialPreview from '@/components/MaterialPreview/index.vue'
import dayjs from 'dayjs'
import { mergeCdn } from '@/utils/util.ts'
import { parseUserAgent } from '@/utils/userAgent'

const props = defineProps({
  toUser: {
    type: Object,
    default: () => ({
      user: {},
      lastChatAt: 0,
      lastMessage: null
    })
  }
})

const emit = defineEmits(['change', 'quick-reply'])

const { toUser } = toRefs(props)

const formState = reactive({
  remarkName: ''
})

const isTop = ref(false)
const isBlocked = ref(false)

watch(
  () => props.toUser,
  () => {
    if (toUser.value?.user) {
      formState.remarkName = toUser.value.user.remarkName || ''
      isTop.value = toUser.value.user.topAt > 0
      isBlocked.value = toUser.value.user.blockAt > 0
    }
  },
  {
    deep: true,
    immediate: true
  }
)

const tabs = [
  { label: '用户资料', value: 0 },
  { label: '快捷回复', value: 1 }
]

const quickReplyPage = ref(1)
const quickReplyPageSize = ref(20)
const activeKey = ref(0)
const quickReplyList = ref([])
const quickReplyFinish = ref(false)

const labels = [
  { key: 'ip', label: '注册IP' },
  { key: 'area', label: 'IP地区' },
  { key: 'created_at', label: '注册时间' },
  { key: 'offlineAt', label: '离线时间' },
  { key: 'scanCount', label: '扫码次数' },
  { key: 'topAt', label: '聊天置顶' },
  { key: 'blockAt', label: '用户拉黑' }
]

const formatTime = (timestamp) => {
  if (timestamp === 0) {
    return '-'
  }
  const msgDate = dayjs(timestamp * 1000)
  return msgDate.format('YYYY-MM-DD HH:mm')
}

const onUpdateUser = async () => {
  const { uuid } = toUser.value.user
  if (toUser.value.user.remarkName === formState.remarkName) {
    return
  }
  const params = {
    uuid,
    updateType: 'userinfo',
    remarkName: formState.remarkName
  }
  const res = await ChatApi.updateUser(params)
  if (res.code === 200) {
    toUser.value.user.remarkName = formState.remarkName
    emit('change', params)
  }
}

const handleTopChange = async (checked) => {
  const { uuid } = toUser.value.user
  const params = {
    uuid,
    updateType: 'top',
    top: checked ? 1 : 2
  }
  const res = await ChatApi.updateUser(params)
  if (res.code === 200) {
    message.success(checked ? '已置顶' : '已取消置顶')
    toUser.value.user.topAt = checked ? Date.now() / 1000 : 0
    emit('change', params)
  }
}

const handleDelete = () => {
  Modal.confirm({
    title: '确认删除',
    content: '确定要删除该用户及其聊天记录吗？',
    okText: '确定',
    cancelText: '取消',
    onOk: async () => {
      const { uuid } = toUser.value.user
      const res = await ChatApi.delUser(uuid)
      if (res.code === 200) {
        message.success('删除成功')
        emit('change', {
          uuid,
          updateType: 'delete',
          clearCurrentChat: true
        })
      }
    }
  })
}

const handleBlock = async () => {
  const { uuid } = toUser.value.user
  const params = {
    uuid,
    updateType: 'block',
    block: isBlocked.value ? 2 : 1
  }
  const res = await ChatApi.updateUser(params)
  if (res.code === 200) {
    message.success(isBlocked.value ? '已取消拉黑' : '已拉黑')
    toUser.value.user.blockAt = isBlocked.value ? 0 : Date.now() / 1000
    emit('change', params)
  }
}

const onChangeTab = async (e) => {
  if (e === 1) {
    if (quickReplyFinish.value) {
      return
    }
    let msgList = await MessageApi.getWelcomeList({ msgType: 'quick_reply', page: quickReplyPage.value, pageSize: quickReplyPageSize.value })
    if (msgList.code === 200) {
      quickReplyList.value = msgList.data.list || []
      quickReplyFinish.value = quickReplyList.value.length < quickReplyPageSize.value
    }
  }
}

const sendQuickReply = async (e) => {
  console.log('sendQuickReply:', e)
  let msg = { msgType: '', content: '' }
  if (e.type === 'text') {
    msg.content = e.content
    msg.msgType = 'text'
  } else if (e.type === 'image') {
    msg.content = `${e.content}`
    msg.msgType = 'image'
  } else if (e.type === 'video') {
    msg.content = JSON.stringify({
      url: `${e.content}`,
      thumb: e.thumb || '',
    })
    msg.msgType = 'video'
  }
  // 发送出去.
  console.log('msg:', msg)
  emit('quick-reply', msg)
}

const previewVisible = ref(false)
const previewItem = ref(null)

const showPreview = (item) => {
  previewItem.value = item
  previewVisible.value = true
}

const previewRef = ref(null)
const previewUrl = ref('')
const previewMediaType = ref('')

const handlePreview = (item) => {
  if (item.type === 'image' || item.type === 'video') {
    previewMediaType.value = item.type
    previewUrl.value = item.content
    nextTick(() => {
      previewRef.value && previewRef.value.autoPreview()
    })
  } else {
    previewItem.value = item
    previewVisible.value = true
  }
}

const userInfo = computed(() => {
  if (!toUser.value?.user?.userAgent) return {
    systemType: '-',
    deviceType: '-',
    browserType: '-'
  }
  return parseUserAgent(toUser.value.user.userAgent)
})
</script>
<style lang="less" scoped>
.chat-user {
  width: 100%;
  max-width: 300px;
  background: #fff;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  overflow: hidden;
  display: flex;
  flex-direction: column;

  :deep(.ant-tabs-top > .ant-tabs-nav) {
    margin: 0;
    padding: 0;
    height: 53px;
  }

  :deep(.ant-tabs-tab) {
    flex: 1;
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 0;
    padding: 0;
  }

  :deep(.ant-tabs-tab-btn) {
    width: 100%;
    text-align: center;
  }

  :deep(.ant-tabs-nav-list) {
    width: 100%;
    display: flex;
  }

  :deep(.ant-tabs-tab + .ant-tabs-tab) {
    margin: 0;
  }

  :deep(.ant-tabs-ink-bar) {
    width: 50% !important;
  }

  .user-info-section {
    padding: 12px;
    background: #fff;
    border-radius: 8px;
    margin: 8px;
  }

  .info-item {
    display: flex;
    align-items: center;
    padding: 8px 0;
    border-bottom: 1px solid #f0f0f0;

    &:last-child {
      border-bottom: none;
    }
  }

  .info-label {
    width: 100px;
    padding: 4px 8px;
    background: #e6f7ff;
    color: #1890ff;
    border-radius: 4px;
    font-size: 14px;
    margin-right: 16px;
    flex-shrink: 0;
  }

  .info-value {
    flex: 1;
    color: #333;
    font-size: 14px;
  }

  .info-input {
    flex: 1;

    :deep(.ant-input) {
      border-radius: 4px;
    }
  }

  .info-switch {
    margin-left: auto;
  }

  .action-buttons {
    display: flex;
    justify-content: space-between;
    margin-top: 16px;
    padding-top: 16px;
    border-top: 1px solid #f0f0f0;
    gap: 12px;

    .delete-btn {
      flex: 1;
      background: #ff4d4f;
      border-color: #ff4d4f;
      border-radius: 4px;
      height: 32px;

      &:hover {
        background: #ff7875;
        border-color: #ff7875;
      }
    }

    .block-btn {
      flex: 1;
      background: #1890ff;
      border-color: #1890ff;
      border-radius: 4px;
      height: 32px;

      &:hover {
        background: #40a9ff;
        border-color: #40a9ff;
      }
    }
  }
}

.quick-reply-list {
  padding: 8px;
  overflow-y: auto;
  max-height: calc(100vh - 200px);
}

.quick-reply-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px;
  margin-bottom: 6px;
  background: #f5f5f5;
  border-radius: 6px;
  transition: all 0.3s ease;

  &:hover {
    background: #e8e8e8;
    transform: translateX(2px);
  }

  &.sending {
    animation: sending 1s infinite;
  }
}

.quick-reply-content {
  flex: 1;
  padding-right: 8px;
  cursor: pointer;
}

.quick-reply-title {
  font-size: 13px;
  color: #333;
  line-height: 1.4;
  max-height: 36px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;

  &:hover {
    color: #1890ff;
  }
}

.quick-reply-actions {
  .ant-btn {
    height: 24px;
    padding: 0 12px;
    border-radius: 12px;
    font-size: 12px;
    transition: all 0.2s ease;
    display: flex;
    align-items: center;
    background: transparent;
    border: 1px solid #d9d9d9;
    color: #666;

    &:hover {
      color: #1890ff;
      border-color: #1890ff;
      background: transparent;
    }

    &.error-state {
      color: #ff4d4f;
      border-color: #ff4d4f;

      &:hover {
        color: #ff7875;
        border-color: #ff7875;
        background: transparent;
      }
    }
  }
}

.media-preview {
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  background: #f8f9fa;
  border-radius: 8px;
  padding: 16px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

.preview-modal {
  :deep(.ant-modal-content) {
    border-radius: 12px;
    overflow: hidden;
  }

  :deep(.ant-modal-header) {
    margin-bottom: 0;
    padding: 16px 24px;
    border-bottom: 1px solid #f0f0f0;
  }

  :deep(.ant-modal-title) {
    font-size: 16px;
    font-weight: 500;
    color: #333;
  }

  :deep(.ant-modal-body) {
    padding: 0;
  }
}

.preview-content {
  .preview-header {
    padding: 16px 24px;
    border-bottom: 1px solid #f0f0f0;
  }

  .preview-body {
    padding: 8px;
    min-height: 200px;
    max-height: 400px;
    overflow-y: auto;
  }

  .text-preview {
    width: 100%;
    background: #f8f9fa;
    border-radius: 8px;
    padding: 16px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);

    .text-content {
      color: #333;
      font-size: 14px;
      line-height: 1.6;
      white-space: pre-wrap;
      word-break: break-word;
      max-height: 300px;
      overflow-y: auto;
    }
  }

  .preview-actions {
    padding: 16px 24px;
    border-top: 1px solid #f0f0f0;
    display: flex;
    justify-content: flex-end;
    gap: 12px;

    .ant-btn {
      height: 36px;
      padding: 0 20px;
      font-size: 14px;
      border-radius: 6px;
      transition: all 0.3s ease;

      &.send-btn {
        background: #1890ff;
        border-color: #1890ff;

        &:hover {
          background: #40a9ff;
          border-color: #40a9ff;
        }
      }

      &.cancel-btn {
        color: #666;
        border-color: #d9d9d9;

        &:hover {
          color: #1890ff;
          border-color: #1890ff;
        }
      }
    }
  }
}

.fullscreen-preview {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.8);
  z-index: 1000;
  display: flex;
  justify-content: center;
  align-items: center;
}

@keyframes sending {
  0% {
    transform: scale(1);
    opacity: 1;
  }

  50% {
    transform: scale(0.95);
    opacity: 0.8;
  }

  100% {
    transform: scale(1);
    opacity: 1;
  }
}
</style>
