<template>
  <div style="display: flex; flex: 1" id="message-box">
    <div class="chatroom-contain">
      <!-- 消息来源 -->
      <div v-if="toUser?.user?.nickName" class="info-container">
        <div class="user-header">
          <div class="user-status" :class="{ online: toUser.user.isOnline }"></div>
          <div class="user-info">
            <span class="username">{{ toUser.user.remarkName || toUser.user.nickName }}</span>
            <span class="secondary-info">
              <span class="status-text">{{ toUser.user.isOnline ? '在线' : '离线' }}</span>
              <span class="ip">{{ toUser?.user?.ip || '0.0.0.0' }}</span>
              <span class="location">{{ formatLocation(toUser.user) }}</span>
            </span>
          </div>
        </div>
        <!-- 切换面板按钮 -->
        <div class="panel-toggle" @click="togglePanel">
          <MenuFoldOutlined :class="['toggle-icon', { 'active': isPanelVisible }]" />
        </div>
      </div>

      <!-- 消息展示区域 -->
      <div class="message-display" ref="messageDisplay" @scroll="loadHistoryMsg">
        <template v-for="message in processedMessages" :key="message.msgId">
          <div v-if="message.showTime" class="time">{{ message.displayMsgTime }}</div>
          <div :id="message.msgId" :class="['message', message.isKf == 1 ? 'right' : '']"
            :ref="el => { if (el) messageRefs[message.msgId] = el }">
            <div class="avatar-and-name">
              <span class="name">{{ message.isKf === 1 ? '' : message.guestName }}</span>
              <img :src="message.isKf === 1 ? kfAvatar : mergeCdn(toUser.user.avatar)" alt="Avatar" />
            </div>
            <div class="message-content">
              <div v-if="message.msgType === 'text'" v-html="message.content" class="text-content"></div>
              <div v-if="message.msgType === 'smartReply'" v-html="renderMessage(message.content)" class="text-content">
              </div>
              <div v-if="message.msgType === 'video'" class="video-contain">
                <MaterialPreview mediaType="video" :url="mergeCdn(message.content.url)"
                  :thumb="mergeCdn(message.content.thumb)" :videoW="200" :videoH="150" class="fixed-size-media">
                </MaterialPreview>
              </div>
              <a-image v-if="message.msgType === 'image'" :width="200" :height="150" :src="mergeCdn(message.content)"
                class="image-box fixed-size-media" />
              <LocationMessage v-if="message.msgType === 'location'" :lat="message.content.lat"
                :lng="message.content.lng" :address="message.content.address" />
              <div v-if="message.msgType === 'smart_msg'" class="text-content">
                <p>{{ message.content.describe }}</p>
                <p v-for="item in message.content.list" key="item.id">
                  <a href="javascript:;">{{ item.title }}</a>
                </p>
              </div>
            </div>
            <div v-if="message.isKf == 1" class="message-actions">
              <a-tooltip title="撤回消息" placement="top">
                <div class="revert-icon" @click="revertMsg(message)">
                  <UndoOutlined />
                </div>
              </a-tooltip>
            </div>
            <div class="read-status" v-if="message.isKf == 1 && message.readStatus === '已读'">
              已读
            </div>
          </div>
        </template>
      </div>


      <!-- 消息输入区域 -->
      <a-spin :spinning="loading">
        <div class="message-input">
          <div :class="['tools', { disable: disableChatBox() }]">
            <EmojiSelect @onChange="onEmojiChange"></EmojiSelect>
            <a-tooltip title="支持ctrl+v粘贴图片" placement="top">
              <SvgIcon name="icon-photo" width="28px" height="28px" @click="selectFile('image')" />
            </a-tooltip>
            <SvgIcon name="icon-video" width="28px" height="28px" @click="selectFile('video')" />
            <SvgIcon name="icon-location" width="28px" height="28px" @click="showLocationPicker" />
          </div>
          <a-textarea v-model:value="newMessage.content" v-focus placeholder="" :bordered="false"
            @pressEnter="onSendMessage" :disabled="disableChatBox()" />
          <a-button @click="onSendMessage" type="primary"
            :class="['send-btn', { disable: disableChatBox() }]">发送</a-button>
        </div>
      </a-spin>
    </div>

    <!-- 当前用户信息 -->
    <transition name="slide-fade">
      <ChatUser :key="toUser?.user?.uuid" v-if="toUser?.user?.nickName && isPanelVisible" :toUser="toUser"
        @change="onChangeUserInfo" @quick-reply="onQuickReply" class="user-panel" />
    </transition>

    <!-- 视频播放弹窗 -->
    <a-modal title="视频播放" v-model:visible="visible" :footer="null" :destroyOnClose="true" :maskClosable="false"
      :width="680">
      <video :src="videoUrl" width="640" height="360" autoplay controls></video>
    </a-modal>

    <!-- 新消息音频 -->
    <audio id="audioPlayer" :src="voiceSrc" controls style="display: none;"></audio>

    <!-- 位置选择器弹窗 -->
    <!-- <a-modal v-model:visible="locationPickerVisible" title="选择位置" :footer="null" width="800px"
      :destroyOnClose="true">
      <LocationPicker :visible="locationPickerVisible" @select="onLocationSelect"
        @close="locationPickerVisible = false" />
    </a-modal> -->

    <!-- 添加位置详情弹窗 -->
    <a-modal v-model:visible="locationDetailVisible" title="位置详情" :footer="null" width="600px" :destroyOnClose="true">
      <div class="location-detail">
        <div id="detail-map" class="detail-map"></div>
        <div class="detail-info">
          <div class="detail-name">{{ selectedLocation?.name }}</div>
          <div class="detail-address">{{ selectedLocation?.address }}</div>
        </div>
      </div>
    </a-modal>
  </div>
</template>

<script setup>
import { ref, onMounted, nextTick, toRefs, watch, computed, onUnmounted } from 'vue';
import WebSocketClient from '@/utils/mySocket.js';
import EmojiSelect from '@/components/EmojiSelect/index.vue'
import { FileImageOutlined, VideoCameraOutlined, PlayCircleOutlined, UndoOutlined, MenuFoldOutlined, ReloadOutlined, EnvironmentOutlined } from '@ant-design/icons-vue'
import dayjs from 'dayjs'
import { ChatApi } from '@/webapi/index'
import { message } from 'ant-design-vue';
import { throttle } from 'lodash-es'
import { mergeCdn, highlightURLs } from '@/utils/util.ts'
import ChatUser from './chatUser.vue'
import MaterialPreview from '@/components/MaterialPreview/index.vue'
import ls from '@/utils/Storage'
import msgVoice from '@/assets/newmsg.mp3'
import onlineVoice from '@/assets/online.mp3'
import { useUserStore } from '@/store/modules'
import { v4 as uuidv4 } from 'uuid';
import SvgIcon from '@/components/SvgIcon/index.vue'
import LocationPicker from '@/components/LocationPicker/index.vue';
import LocationMessage from '@/components/LocationMessage/index.vue';

const systemConfig = JSON.parse(sessionStorage.getItem('systemConfig'))
const kfAvatar = `${ls.get('cdnDomain')}${systemConfig.avatarUrl}`

const wsHost = ls.get('wsHost')
const wsFullHost = ls.get('wsFullHost')
const token = ls.get('token')
const loading = ref(false)

const props = defineProps({
  toUser: {
    type: Object,
    default: () => ({
      user: {},
      lastChatAt: 0,
      lastMessage: null
    })
  },
  batchSendMode: Boolean
})

const { toUser } = toRefs(props)
const scrollId = ref(0)
const allMsgLoaded = ref(false)

const disableChatBox = () => {
  if (props.batchSendMode) {
    return false
  }
  if (toUser.value?.user?.uuid) {
    return false
  }
  return true
}

watch(
  () => props.toUser,
  (newVal, oldVal) => {
    if (newVal?.user?.uuid && newVal.user.uuid != oldVal?.user?.uuid) {
      setTimeout(() => {
        getChatMsg()
      }, 0)
    }
  },
  {
    deep: true,
    immediate: true
  }
)

// ws实例
let wsClient

// 消息对象数组
const messages = ref([])
// 处理后的消息，带 showTime 字段
const processedMessages = computed(() => {
  const FIVE_MINUTES = 5 * 60; // 单位：秒
  let lastTimestamp = null;

  return messages.value.map((msg, index) => {
    const currentTime = msg.msgTime;
    let showTime = false;

    if (index === 0 || !lastTimestamp || (currentTime - lastTimestamp > FIVE_MINUTES)) {
      showTime = true;
      lastTimestamp = currentTime;
    }
    let content = msg.content;
    if (msg.msgType === 'smart_msg') {
      let obj = JSON.parse(msg.content)
      content = obj;
    }

    console.log('msg->>>>>', msg.content)

    return {
      ...msg,
      content: content,
      showTime,
      displayMsgTime: showTime ? formatTime(msg.msgTime) : undefined
    };
  });
});

const formatTime = (timestamp) => {
  if (timestamp === 0) {
    return ''
  }
  const msgDate = dayjs(timestamp * 1000);
  const today = dayjs();

  if (msgDate.isSame(today, 'day')) {
    return msgDate.format('HH:mm');
  } else {
    return msgDate.format('YYYY-MM-DD HH:mm');
  }
};

// 输入框中的新消息
const newMessage = ref({
  msgType: '', // "枚举值：text || image || video"
  msgId: '',
  content: '',
  guestName: '',
  guestAvatar: '',
  msgTime: '',
  guestId: '',
  kfId: '',
  content: '', //"内容：text=文本、image、video = 地址"
  isKf: 1
})

const onBatchSendSuccess = () => {
  newMessage.value.content = ''
}

defineExpose({ onBatchSendSuccess })

// 消息展示区域引用
const messageDisplay = ref(null)

// 状态管理
let isCoolingDown = ref(false) // 是否在冷却期
let lastSendTime = ref(0) // 最后发送时间戳

const onSendMessage = (event, msgType, msgText) => {
  if (isCoolingDown.value) {
    message.error('消息发送过于频繁，请稍后再试')
    return
  }
  if (Date.now() - lastSendTime < 200) {
    isCoolingDown.value = true
  }
  throttledSend(event, msgType, msgText)
}

const throttledSend = throttle(
  (event, msgType, msgText) => {
    isCoolingDown.value = false
    sendMessage(event, msgType, msgText)
    lastSendTime.value = Date.now()
  },
  200,
  {
    leading: true, // 立即执行第一次点击
    trailing: false // 不执行最后一次点击的延迟回调
  }
)

const messageRefs = ref({})

const scrollToBottom = () => {
  nextTick(() => {
    if (messageDisplay.value) {
      // 计算所有消息的总高度
      let totalHeight = 0
      Object.values(messageRefs.value).forEach(el => {
        totalHeight += el.offsetHeight
      })
      messageDisplay.value.scrollTop = totalHeight
    }
  })
}

const sendMessage = (event, msgType, msgText) => {
  // 阻止默认的换行行为
  event.preventDefault()

  // 验证消息长度:
  if (newMessage.value.content.length > 500) {
    message.error('消息长度不能超过500个字符')
    return
  }

  // 群发模式.
  if (props.batchSendMode) {
    // emit message 出去.
    emit('batch-send-message', {
      msgType: msgType ? msgType : 'text',
      content: msgText ? msgText : newMessage.value.content.trim()
    })
    return
  }

  if (!toUser.value?.user?.uuid) {
    message.error('请选中聊天粉丝')
    return
  }

  newMessage.value.guestId = toUser.value?.user?.uuid
  newMessage.value.msgId = uuidv4()
  const messageText = msgText ? msgText : newMessage.value.content.trim()
  if (messageText) {
    newMessage.value.msgType = msgType ? msgType : 'text'
    newMessage.value.content = messageText
    newMessage.value.msgTime = dayjs().unix()

    // 创建消息副本并添加到消息列表
    const messageCopy = JSON.parse(JSON.stringify(newMessage.value))
    // 发送给服务器
    wsClient.sendMessage(messageCopy)

    if (messageCopy.msgType === 'video' || messageCopy.msgType === 'location') {
      // 如果是视频消息，确保 content 是一个对象
      messageCopy.content = JSON.parse(messageCopy.content)
    }
    messages.value.push(messageCopy)
    // 同步list中消息内容及时间
    emit('newMessage', messageCopy)

    // 清空聊天
    newMessage.value.content = ''

    // 滚动到底部
    scrollToBottom()
  } else {
    message.error('请勿发送空白消息')
  }
}

// 切换表情包选择框
const onEmojiChange = (emoji) => {
  newMessage.value.content += emoji.i
}

// 选择文件
const IMG_MAX = 10
const VIDEO_MAX = 50
const selectFile = (type) => {
  const input = document.createElement('input')
  input.type = 'file'
  input.accept = type === 'image' ? 'image/*' : 'video/*'
  input.onchange = async (event) => {
    const file = event.target.files[0]
    if (file) {
      // console.log('file:', file)
      // 校验文件大小
      const maxSize = type === 'image' ? IMG_MAX : VIDEO_MAX
      if (file.size > 1024 * 1024 * maxSize) {
        return message.error(`${type === 'image' ? '图片' : '视频'}最大不能超过${maxSize}M`)
      }

      //上传至服务器，得到url后展示在消息框中
      const formData = new FormData()
      formData.append('file', file)
      formData.append('fileType', type)
      loading.value = true
      const res = await ChatApi.fileUpload(formData)
      loading.value = false
      if (res && res.code === 200 && res.data) {
        const { cdnHost, path, thumb } = res.data

        let content = `${path}`
        if (type === 'video') {
          content = JSON.stringify({
            url: content,
            thumb: thumb,
          })
        }
        onSendMessage({ preventDefault: () => { } }, type, content)
      } else {
        message.error(res.message)
      }
    }
  }
  input.click()
}

// 上一次请求的内容高度
let preScrollHeight = 0
const pageSize = 20

const getChatMsg = async () => {
  if (toUser.value?.user?.uuid === '') {
    return
  }

  // 当加载了所有消息，不再发送请求，最老的消息都加载了就没得了.
  if (allMsgLoaded.value) {
    return
  }

  preScrollHeight = messageDisplay.value.scrollHeight

  const params = {
    pageSize,
    lastMsgTime: scrollId.value,
    guestId: toUser.value.user.uuid
  }
  const res = await ChatApi.chatMsgPost(params)
  if (res && res.code === 200) {
    if (res.data && res.data.messages.length == 0) {
      allMsgLoaded.value = true
    }
    if (res.data && res.data.messages.length > 0) {
      scrollId.value = res.data.messages[0].msgTime
    }
    let msgtime = res.data.lastReadMsgAt;
    messages.value = [...res.data.messages, ...messages.value]
    messages.value.forEach(msg => {
      msg.readStatus = ''
      if (msg.msgTime <= msgtime && msg.isKf === 1) {
        msg.readStatus = '已读'
      }
      if (msg.msgType === 'video' || msg.msgType === 'location') {
        // 判断是否是json格式. 
        try {
          let content = JSON.parse(msg.content)
          msg.content = content
        } catch (e) {
          console.log("not json video", e)
        }
      }
      console.log(msg.msgTime <= msgtime);
    })

    await nextTick()

    // 滚动条定位
    messageDisplay.value.scrollTop = messageDisplay.value.scrollHeight - preScrollHeight
  } else {
    message.error(res.message || '请求失败，请联系管理员')
  }
}

const loadHistoryMsg = throttle(() => {
  const scrollTop = messageDisplay.value?.scrollTop
  if (scrollTop != null && scrollTop <= 0) {
    getChatMsg()
  }
}, 500)

const visible = ref(false)
const videoUrl = ref('')
const playVideo = (url) => {
  videoUrl.value = mergeCdn(url)
  visible.value = true
}

const emit = defineEmits(['newMessage', 'changeUserInfo', 'msg:online', 'msg:offline', 'update:lastChatTime', 'update-last-message'])

const onChangeUserInfo = (updateInfo) => {
  emit('changeUserInfo', updateInfo)
}

const onQuickReply = (msg) => {
  onSendMessage({ preventDefault: () => { } }, msg.msgType, msg.content)
}

const userStore = useUserStore()
const voiceFlag = computed(() => {
  return userStore.getUserInfo.newMessageVoice
})

let audio
const voiceSrc = ref(null)
const playVoice = (flag) => {
  if (!voiceFlag.value) return
  if (audio) audio.pause();
  voiceSrc.value = flag ? msgVoice : onlineVoice
  nextTick(() => {
    audio.play()
  })
}

const revertMsg = async (message) => {
  try {
    const { code, data } = await ChatApi.revert({ msgId: message.msgId })
    if (code === 200) {
      // 直接从消息列表中删除该消息
      const index = messages.value.findIndex(msg => msg.msgId === message.msgId)
      if (index !== -1) {
        messages.value.splice(index, 1)
      }

      // 找到当前会话的最后一条消息
      const lastMessage = messages.value.length > 0 ? messages.value[messages.value.length - 1] : null

      // 更新聊天列表的最后一条消息
      emit('update-last-message', {
        guestId: toUser.value.user.uuid,
        lastMessage: lastMessage ?
          (lastMessage.msgType === 'text' ? lastMessage.content :
            lastMessage.msgType === 'video' ? '[视频消息]' : '[图片消息]') :
          '[暂无消息]'
      })
    }
  } catch (error) {
    console.error('撤回消息失败:', error)
  }
}

const isPanelVisible = ref(true)

const togglePanel = () => {
  isPanelVisible.value = !isPanelVisible.value
}

// Add clipboard paste handler
const handlePaste = async (event) => {
  const items = event.clipboardData.items
  for (let i = 0; i < items.length; i++) {
    const item = items[i]
    if (item.type.indexOf('image') !== -1) {
      event.preventDefault()
      const file = item.getAsFile()

      // 校验文件大小
      if (file.size > 1024 * 1024 * IMG_MAX) {
        return message.error(`图片最大不能超过${IMG_MAX}M`)
      }

      //上传至服务器，得到url后展示在消息框中
      const formData = new FormData()
      formData.append('file', file)
      formData.append('fileType', 'image')
      loading.value = true
      try {
        const res = await ChatApi.fileUpload(formData)
        loading.value = false
        if (res && res.code === 200 && res.data) {
          const { path } = res.data
          onSendMessage({ preventDefault: () => { } }, 'image', `${path}`)
          // 确保消息发送后滚动到底部
          scrollToBottom()
        } else {
          message.error(res.message || '上传失败')
        }
      } catch (error) {
        loading.value = false
        message.error('上传失败，请重试')
      }
    }
  }
}


// 自动滚动到最新消息
onMounted(() => {
  audio = document.getElementById('audioPlayer')

  // Add paste event listener
  document.getElementById('message-box').addEventListener('paste', handlePaste)

  let params = {
    wsHost: wsHost,
    wsFullHost: wsFullHost,
    token: token
  }

  // 监听消息
  wsClient = new WebSocketClient(params)

  wsClient.onMessage(res => {
    // 判断消息类型. 
    if (res.msgType === 'kfuserread') {
      let msgtime = res.lastReadMsgAt
      // 更新前台用户的消息已读状态.
      messages.value.forEach(msg => {
        console.log(msg.guestId === res.guestId, msg.msgTime <= msgtime)
        if (msg.guestId === res.guestId && msg.msgTime <= msgtime && msg.isKf === 1) {
          msg.readStatus = '已读'
        }
      })
      return;
    }
    if (res.msgType === 'video' || res.msgType == 'location') {
      res.content = JSON.parse(res.content)
    }

    console.log('接收到啦：', res);
    res.msgTime = dayjs().unix()
    // 播放新消息音频
    playVoice(true)

    // 是否是当前粉丝发的消息
    const guestId = res.guestId
    if (toUser.value?.user?.uuid === guestId) {
      // 将消息展示在聊天框中
      messages.value.push(JSON.parse(JSON.stringify(res)))
      // 发送已读消息
      newMessage.value.msgType = 'read'
      newMessage.value.guestId = toUser.value?.user?.uuid
      wsClient.sendMessage(JSON.parse(JSON.stringify(newMessage.value)))

      nextTick(() => {
        messageDisplay.value.scrollTop = messageDisplay.value.scrollHeight
      })
    }
    emit('newMessage', res)
  })


  wsClient.onOffline((res) => {
    emit('msg:offline', res)
  })

  wsClient.onOnline((res) => {
    // 播放上线音频
    playVoice(false)
    emit('msg:online', res)
  })

  // 等待所有消息渲染完成后滚动到底部
  nextTick(() => {
    scrollToBottom()
  })
});

// Add cleanup for event listener
onUnmounted(() => {
  try {
    document.getElementById('message-box').removeEventListener('paste', handlePaste)
  } catch (error) {
    console.error('移除粘贴事件失败:', error)
  }
})

const renderMessage = (message) => {
  const messageEl = document.createElement('p')
  // 处理换行和 URL
  let html = highlightURLs(message)
  return html
}

const handleImageLoad = () => {
  nextTick(() => {
    if (messageDisplay.value) {
      messageDisplay.value.scrollTop = messageDisplay.value.scrollHeight
    }
  })
}

const formatLocation = (user) => {
  if (user.area === '') {
    return '未知地区'
  }
  return user.area
}

// 位置选择相关
const locationPickerVisible = ref(false);

// 显示位置选择器
const showLocationPicker = () => {
  locationPickerVisible.value = true;
};

// 处理位置选择
const onLocationSelect = (location) => {
  console.log('Selected location:', location); // 添加日志
  const locationMsg = {
    msgType: 'location',
    content: {
      lat: location.lat,
      lng: location.lng,
      address: location.address
    }
  };
  onSendMessage({ preventDefault: () => { } }, 'location', JSON.stringify(locationMsg.content))
};
</script>

<style lang="less" scoped>
.chatroom-contain {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  background: #fff;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  overflow: hidden;
}

.disable {
  cursor: not-allowed;
  pointer-events: none;
  /* 禁用所有鼠标事件 */
  filter: grayscale(80%);
  /* 灰化效果 */
  opacity: 0.7;
  // color: red;
}

.to-user {
  width: 100%;
  height: 53px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

/* 消息展示区域 */
.message-display {
  flex: 1;
  padding: 0 20px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  // gap: 10px;
  background-color: #f9f9f9;
  position: relative;
  padding-top: 10px;

  .message-list {
    width: 100%;
    position: relative;
  }
}

.message {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  max-width: 80%;
  position: relative;
  margin-bottom: 10px;

  .message-actions {
    display: flex;
    gap: 8px;
    margin-left: 8px;
    opacity: 0;
    transition: opacity 0.3s ease;

    .revert-icon {
      color: #999;
      cursor: pointer;

      &:hover {
        color: #1890ff;
      }
    }
  }

  &:hover .message-actions {
    opacity: 1;
  }

  .read-status {
    position: absolute;
    right: -20px;
    bottom: 0;
    color: #999;
    font-size: 12px;
    display: flex;
    align-items: center;
    gap: 2px;
  }
}

.message.right {
  margin-left: auto;
  flex-direction: row-reverse;

  .message-actions {
    right: auto;
    left: -30px;
  }

  .read-status {
    right: auto;
    bottom: 13px;
    right: auto;
    left: 0.2%;
  }
}

.message.right .message-content {
  background: #9eea6a;
}

.message .avatar-and-name {
  display: flex;
  flex-direction: column;
  align-items: center;
  // gap: 5px;
}

.message .avatar-and-name .name {
  font-size: 0.9em;
  color: #555;
}

.message img {
  width: 40px;
  height: 40px;
  border-radius: 50%;
}

.message-content {
  background: #e0e0e0;
  padding: 6px 10px;
  border-radius: 10px;
  display: flex;
  flex-direction: column;
  margin-bottom: 15px;
  min-height: 40px;
  max-width: 80%;
  word-break: break-word;
  overflow: hidden;

  .text-content {
    margin-bottom: 0;
    overflow-wrap: anywhere;
  }

  .video-contain {
    position: relative;
    max-width: 100%;
    max-height: 200px;
    overflow: hidden;
  }

  .fixed-size-media {
    object-fit: cover;
    border-radius: 4px;
  }

  :deep(.image-box) {
    width: 200px;
    height: 150px;
    object-fit: cover;
    border-radius: 4px;
  }
}

.time {
  font-size: 12px;
  color: #888;
  text-align: center;
}

.message.right {
  margin-left: auto;
  flex-direction: row-reverse;
}

.message.right .message-content {
  background: #9eea6a;
}

/* 消息输入区域 */
.message-input {
  position: relative;
  display: flex;
  flex-direction: column;
  padding: 10px;
  border-top: 1px solid #ddd;
  background: #fff;
  min-height: 200px;
  border-right: 1px solid #ddd;
}

.message-input .tools {
  display: flex;
  align-items: center;
  gap: 16px;
}

.message-input .ant-input {
  flex: 1;
  padding: 0 10px 10px 10px;
  font-size: 1em;
  outline: none;
}

.message-input button {
  border: none;
  font-size: 1em;
  cursor: pointer;
}

.message-input .send-btn {
  width: 80px;
  position: absolute;
  right: 10px;
  bottom: 10px;
}

.emoji-text {
  padding: 10px;
  border: none;
  background: transparent;
  font-size: 16px;
  cursor: pointer;
}

.info-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  height: 53px;
  padding: 0 16px;
  background-color: #f9f9f9;
  border-bottom: 1px solid #ddd;
  font-size: 14px;
  color: #333;
  position: relative;

  .user-header {
    display: flex;
    align-items: center;
    gap: 12px;
  }

  .user-status {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #ccc;
    position: relative;
    margin-right: 4px;

    &::after {
      content: '';
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      width: 16px;
      height: 16px;
      border-radius: 50%;
      background: inherit;
      opacity: 0.3;
      animation: pulse 2s infinite;
    }

    &.online {
      background: #52c41a;
    }
  }

  .user-info {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .username {
    font-weight: 600;
    color: #333;
    line-height: 1.2;
  }

  .secondary-info {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 12px;
    color: #666;
  }

  .status-text {
    color: #666;
  }

  .ip {
    color: #666;
  }

  .location {
    color: #666;
  }

  .panel-toggle {
    position: absolute;
    right: 16px;
    top: 50%;
    transform: translateY(-50%);
    cursor: pointer;
    padding: 8px;
    border-radius: 50%;
    transition: all 0.3s ease;

    &:hover {
      background: rgba(0, 0, 0, 0.05);
    }

    .toggle-icon {
      font-size: 18px;
      color: #666;
      transition: all 0.3s ease;

      &.active {
        color: #1890ff;
        transform: rotate(180deg);
      }
    }
  }
}

@keyframes pulse {
  0% {
    transform: translate(-50%, -50%) scale(1);
    opacity: 0.3;
  }

  50% {
    transform: translate(-50%, -50%) scale(1.5);
    opacity: 0.1;
  }

  100% {
    transform: translate(-50%, -50%) scale(1);
    opacity: 0.3;
  }
}

/* 用户面板动画 */
.slide-fade-enter-active,
.slide-fade-leave-active {
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.slide-fade-enter-from,
.slide-fade-leave-to {
  transform: translateX(100%);
  opacity: 0;
}

.slide-fade-enter-to,
.slide-fade-leave-from {
  transform: translateX(0);
  opacity: 1;
}

.user-panel {
  position: absolute;
  right: 0;
  top: 0;
  bottom: 0;
  width: 300px;
  background: #fff;
  box-shadow: -2px 0 8px rgba(0, 0, 0, 0.1);
  z-index: 1;
}

@keyframes spin {
  to {
    transform: translateY(-50%) rotate(360deg);
  }
}
</style>
