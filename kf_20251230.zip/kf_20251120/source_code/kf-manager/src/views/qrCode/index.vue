<!-- 二维码页面 -->
<template>
  <div class="kf-body">
    <a-spin :spinning="state.loading">
      <div class="max-containter">
        <div class="qrcode-top">
          <div class="qrcode">
            <div>
              <div class="qrcode-title">默认二维码</div>
              <div class="qrcode-canvas" id="qrcode">
                <img :src="qrcode.imageUrl" style="width: 200px" alt="" />
              </div>
              <!-- <div style="color: #7ec051; font-size: 12px">码正常 12-12 11:23:59</div> -->
            </div>
          </div>
          <div class="desc">
            <div class="qrcode-title">【使用说明】</div>
            <div>* 删除：删除当前域名，此域名无法引粉</div>
            <div>* 更换域名：老码不动，新增一个新域名</div>
            <div>* 微信状态：域名在微信中的状态,系统会进行自动检测</div>
            <div>* 点击域名列表，可以切换当前展示的二维码</div>
            <div>* 客户若扫不进来，请直接删除域名，会新增一个新域名</div>

            <!-- 使用红色 告警颜色-->
            <div>* <span style="color: red">建议使用:支付宝，抖音，QQ 扫码进入，体验真正的丝滑无拦截！</span></div>
          </div>
        </div>
        <div style="padding: 16px 0">
          <a-button type="primary" class="green-btn" :icon="h(PlusOutlined)"
            @click="switchQrcodeDomain()">更换域名</a-button>
        </div>
        <div>
          <a-table bordered :data-source="state.dataSource" :columns="columns" size="middle"
            :loading="state.tableLoading" rowKey="id"
            :row-selection="{ selectedRowKeys: state.selectedRowKeys, type: 'radio', onChange: onSelectChange }">
            <template #bodyCell="{ column, text, record }">
              <!-- <template v-if="column.dataIndex === 'status'">
                <a-tag v-if="record.status === 1" color="#87d068">正常</a-tag>
                <a-tag v-if="record.status === 2" color="gray">失效</a-tag>
                <a-tag v-if="record.status === 3" color="orange">暂停引新粉</a-tag>
              </template> -->
              <template v-if="column.dataIndex === 'wechatStatus'">
                <a-tag v-if="record.wechatStatus === 1" color="#87d068">正常</a-tag>
                <a-tag v-if="record.wechatStatus === 2" color="gray">封禁</a-tag>
                <a-tag v-if="record.wechatStatus === 3" color="orange">需要跳转</a-tag>
              </template>
              <template v-if="column.dataIndex === 'qrCode'">
                <img :src="record.qrCode" style="width: 120px; height: 120px;" alt="二维码" />
              </template>
              <template v-if="column.dataIndex === 'link'">
                {{  getQrcodeUrl(record.qrCodeUrl, record.domain) }}
              </template>
              <template v-if="column.dataIndex === 'operation'">
                <a-space>
                  <a-tooltip title="下载二维码图片">
                    <a-button type="primary" @click="downLoadQrCode" size="small">
                      下载二维码
                    </a-button>
                  </a-tooltip>
                  <a-tooltip title="复制二维码链接">
                    <a-button type="primary" @click="copyQrcode(record)" size="small">
                      复制链接
                    </a-button>
                  </a-tooltip>
                  <a-tooltip title="更换顶级域名，老码继续使用，可手动删除">
                    <a-button type="primary" size="small" @click="switchQrcodeDomain(record)">更换域名</a-button>
                  </a-tooltip>
                  <!-- <a-tooltip title="使码永久失效，无法引流">
                    <a-button type="primary" size="small" @click="changeQrcode(record, 'close')">失效码</a-button>
                  </a-tooltip>
                  <a-tooltip title="生成新码，旧码可以继续使用">
                    <a-button type="primary" size="small" @click="changeQrcode(record, 'change')">更换码</a-button>
                  </a-tooltip> -->
                  <!-- <a-tooltip title="老用户依然可以进入，但新用户不行">
                    <a-button v-if="record.status !== 3" type="primary" size="small"
                      @click="changeQrcode(record, 'stop-new')">暂停引新粉</a-button>
                  </a-tooltip>
                  <a-button v-if="record.status === 3" type="primary" size="small"
                    @click="changeQrcode(record, 'start-new')">开启引新粉</a-button>
                  <a-tooltip title="所有老码都失效">
                    <a-button type="primary" size="small" @click="changeQrcode(record, 'stop-all')">停用所有老码</a-button>
                  </a-tooltip> -->
                  <a-tooltip title="删除所有该顶级域名的二维码">
                    <a-button v-if="state.dataSource.length >= 0" type="danger" size="small"
                      @click="changeQrcode(record, 'delete')">删除</a-button>
                  </a-tooltip>
                </a-space>
              </template>
            </template>
          </a-table>
        </div>
      </div>
    </a-spin>

    <!-- 购买域名对表单，需要填写购买的usdt 地址 -->
    <a-modal v-model:visible="state.domainVisible" title="购买独立域名" @ok="onBuyDomainOK" @cancel="onCancelDomain">
      <a-form :model="domainOrderForm" ref="domainOrderRef" layout="vertical" :rules="rules">
        <a-form-item label="请输入您的支付订单的USDT地址, 仅支持 TRC20 协议" name="payAddress" required>
          <a-input v-model:value="domainOrderForm.payAddress" />
        </a-form-item>
      </a-form>
    </a-modal>
  </div>
</template>
<script lang="ts" setup>
import { computed, onMounted, reactive, ref } from 'vue'
import { h, createVNode } from 'vue'
import { PlusOutlined, AuditOutlined, DownloadOutlined, LinkOutlined, ExclamationCircleOutlined } from '@ant-design/icons-vue'
import logo from '@/assets/defaultUser.png'
import QRCode from 'qrcode'
import { message as Message, Modal } from 'ant-design-vue'
import { QrcodeApi } from '@/webapi/index'
import { useRouter } from 'vue-router'
import dayjs from 'dayjs'
import { useUserStore } from '@/store/modules'
import ls from '@/utils/Storage'

const router = useRouter()

const state = reactive({
  dataSource: [],
  editableData: {},
  tableLoading: false,
  loading: false,
  selectItem: {} as any, // 被操作的项
  selectedRowKeys: [],
  domainVisible: false
})
const qrcode = reactive({
  status: 'active',
  value: '',
  imageUrl: '',
  icon: logo
})
const qrcodeCanvasRef: any = ref('')

const columns = [
  {
    title: '域名',
    key: 'domain',
    dataIndex: 'domain'
  },
  {
    title: '二维码',
    key: 'qrCode',
    dataIndex: 'qrCode',
  },
  {
    title: '链接',
    key: 'link',
    dataIndex: 'link',
  },

  // {
  //   title: '二维码状态',
  //   key: 'status', // 1=正常，2=微信封禁, 3=系统封禁
  //   dataIndex: 'status',
  //   width: 150
  // },
  {
    title: '微信状态',
    key: 'wechatStatus', // 1=正常，2=微信封禁, 3=系统封禁
    dataIndex: 'wechatStatus',
    width: 150
  },
  {
    title: '生成时间',
    key: 'createAtText', // 1=正常，2=微信封禁, 3=系统封禁
    dataIndex: 'createAtText',
    width: 280
  },
  {
    title: '操作',
    dataIndex: 'operation',
    width: 400
  }
]

const getQrcodeUrl = (url: string, domain: string) => {
  if (domain.startsWith('http')) {
    return domain + "?c=" + url
  }
  return window.location.protocol + '//' + domain + "?" + url
}

const onSelectChange = (selectedRowKeys, selectedRows) => {
  state.selectedRowKeys = [...selectedRowKeys]
  state.selectItem = { ...selectedRows[0] }
  qrcode.imageUrl = state.selectItem.qrCode
}

const createQrcode = async (value) => {
  // Create QR code with rounded corners
  const qrOptions = {
    width: 300,
    margin: 2,  // 适中的边距
    color: {
      dark: '#000000',
      light: '#ffffff'
    },
    errorCorrectionLevel: 'M',  // 使用中等纠错级别
    version: 5  // 使用合适的版本号
  }

  // Generate QR code
  const qrDataUrl = await QRCode.toDataURL(value, qrOptions)

  // Create canvas for final image
  const canvas = document.createElement('canvas')
  const ctx = canvas.getContext('2d')
  canvas.width = 330
  canvas.height = 330

  // 绘制白色背景
  ctx.fillStyle = '#ffffff'
  ctx.fillRect(0, 0, canvas.width, canvas.height)

  const borderPadding = 15
  const qrSize = 300
  const radius = 30

  // Get user avatar
  const userStore = useUserStore()
  const userInfo = userStore.getUserInfo || {}
  const avatarUrl = userInfo.avatarUrl ? ls.get('cdnDomain') + userInfo.avatarUrl : defaultUser

  // 计算头像位置和大小
  const avatarSize = 50  // 保持头像尺寸
  const avatarPadding = 4  // 头像边距
  const avatarX = borderPadding + (qrSize - avatarSize) / 2
  const avatarY = borderPadding + (qrSize - avatarSize) / 2

  // 创建临时canvas用于处理二维码
  const tempCanvas = document.createElement('canvas')
  const tempCtx = tempCanvas.getContext('2d')
  tempCanvas.width = qrSize
  tempCanvas.height = qrSize

  // 在临时canvas上绘制二维码
  const qrImage = new Image()
  qrImage.crossOrigin = 'anonymous'
  qrImage.src = qrDataUrl
  await new Promise(resolve => qrImage.onload = resolve)
  tempCtx.drawImage(qrImage, 0, 0, qrSize, qrSize)

  // 将处理后的二维码绘制到主canvas
  ctx.drawImage(tempCanvas, borderPadding, borderPadding)

  // 绘制头像背景（半透明白色背景）
  ctx.fillStyle = 'rgba(255, 255, 255, 255)'
  ctx.beginPath()
  ctx.rect(avatarX - avatarPadding, avatarY - avatarPadding, avatarSize + avatarPadding * 2, avatarSize + avatarPadding * 2)
  ctx.closePath()
  ctx.fill()

  // 绘制头像白色边框
  ctx.strokeStyle = '#ffffff'
  ctx.lineWidth = 6
  ctx.strokeRect(avatarX - avatarPadding, avatarY - avatarPadding, avatarSize + avatarPadding * 2, avatarSize + avatarPadding * 2)

  // 绘制头像
  const avatar = new Image()
  avatar.crossOrigin = 'anonymous'
  avatar.src = avatarUrl
  await new Promise(resolve => avatar.onload = resolve)

  // 使用矩形裁剪头像
  ctx.save()
  ctx.beginPath()
  ctx.rect(avatarX, avatarY, avatarSize, avatarSize)
  ctx.closePath()
  ctx.clip()
  ctx.drawImage(avatar, avatarX, avatarY, avatarSize, avatarSize)
  ctx.restore()

  return canvas.toDataURL('image/png')
}

// 复制二维码
const copyQrcode = (record) => {
  navigator.clipboard
    .writeText(getQrcodeUrl(record.qrCodeUrl, record.domain))
    .then(function () {
      Message.success('已成功复制到剪切板!')
    })
    .catch(function (err) {
      Message.success('无法复制到剪切板!')
    })
}

// 下载二维码
const downLoadQrCode = async () => {
  const a = document.createElement('a')
  a.download = 'QRCode.png'
  a.href = qrcode.imageUrl
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
}

const getQrcodeList = async () => {
  state.tableLoading = true
  let { code, data, message }: any = await QrcodeApi.getQrcode({})
  state.tableLoading = false
  if (code === 200) {
    for (var i = 0; i < (data.domains || []).length; i++) {
      let item = data.domains[i]
      item.qrCode = await createQrcode(getQrcodeUrl(item.qrCodeUrl, item.domain))
      item.createAtText = item.createAt ? dayjs(item.createAt * 1000).format('YYYY-MM-DD HH:mm:ss') : ''
    }
    state.dataSource = data.domains || []
    if (state.dataSource.length) {
      let firstItem = state.dataSource[0]
      if (state.selectItem.id) {
        let item = state.dataSource.find((el) => el.id === state.selectItem.id)
        if (item) {
          onSelectChange([item.id], [item])
          return;
        }
      }
      onSelectChange([firstItem.id], [firstItem])
    }
  } else {
    Message.error(message || '请求失败')
  }
}
// 使码失效
const offQrcode = async (params: any) => {
  state.loading = true
  let { code, data, message }: any = await QrcodeApi.getQrcodeOff(params)
  state.loading = false
  if (code === 200) {
    Message.success('操作成功')
    getQrcodeList()
  } else {
    Message.error(message || '请求失败')
  }
}
// 使码失效
const deleteQRCode = async (params: any) => {
  state.loading = true
  let { code, data, message }: any = await QrcodeApi.deleteQRCode(params)
  state.loading = false
  if (code === 200) {
    Message.success('操作成功')
    getQrcodeList()
  } else {
    Message.error(message || '请求失败')
  }
}
// 更换码
const switchQrcode = async (reocrd: any) => {
  state.loading = true
  let params = {
    id: reocrd.id
  }
  let { code, data, message }: any = await QrcodeApi.getQrcodeSwitch(params)
  state.loading = false
  if (code === 200) {
    Message.success('操作成功')
    state.selectItem = { ...reocrd }
    getQrcodeList()
  } else {
    Message.error(message || '请求失败')
  }
}


// 更换码
const switchQrcodeDomain = async (reocrd: any) => {
  state.loading = true
  let params = {
  }
  if (reocrd) {
    params.id = reocrd.id
  }
  let { code, data, message }: any = await QrcodeApi.getDomainSwitch(params)
  state.loading = false
  if (code === 200) {
    Message.success('操作成功')
    if (reocrd) {
      state.selectItem = { ...reocrd }
    }
    getQrcodeList()
  } else {
    Message.error(message || '请求失败')
  }
}

const changeQrcode = (reocrd, actionType = '') => {
  let tip = ''
  let params: any = {
    id: reocrd.id
  }
  if (actionType === 'close') {
    tip = '失效后无法引流，确定操作吗？'
    params.status = 2
  }
  if (actionType === 'change') {
    tip = '生成新码，旧码可以继续使用，但不会检测和通知，确定操作吗？'
  }
  if (actionType === 'stop-all') {
    tip = '停用后，所有旧码均不能再使用，确定操作吗？'
    params.disableOld = true
  }
  if (actionType === 'stop-new') {
    tip = '暂停后，老用户依然可以进入，但新用户不行，确定操作吗？'
    params.status = 3
  }
  if (actionType === 'start-new') {
    params.status = 1
    return offQrcode(params)
  }
  if (actionType === 'delete') {
    Modal.confirm({
      title: '提示',
      icon: createVNode(ExclamationCircleOutlined),
      content: "确认删除二维码？",
      okText: '确认',
      cancelText: '取消',
      onOk() {
        deleteQRCode({ id: params.id })
      },
      onCancel() { }
    })
    return
  }
  Modal.confirm({
    title: '提示',
    icon: createVNode(ExclamationCircleOutlined),
    content: tip,
    okText: '确认',
    cancelText: '取消',
    onOk() {
      if (actionType === 'change') {
        switchQrcode(params)
      } else {
        offQrcode(params)
      }
    },
    onCancel() { }
  })
}

const domainOrderRef: any = ref('')
const domainOrderForm = reactive({
  payAddress: ''
})

const rules = {
  payAddress: [
    { required: true, message: '请输入支付地址', trigger: 'blur' },
    { pattern: /^T[a-zA-Z0-9]{33}$/, message: '请输入正确的TRC20地址', trigger: 'blur' }
  ]
}

// 打开弹窗
const onBuyDomain = () => {
  domainOrderRef.value && domainOrderRef.value.resetFields()
  state.domainVisible = true
}
const onViewOrder = () => {
  router.push('/qrCode/order')
}

const onBuyDomainOK = () => {
  domainOrderRef.value
    .validate()
    .then(() => {
      QrcodeApi.createDomainOrder({ payAddress: domainOrderForm.payAddress }).then((res: any) => {
        if (res.code === 200) {
          Message.success('订单创建成功，即将跳转支付')
          state.domainVisible = false
          domainOrderForm.payAddress = ''
          console.log(res)
          setTimeout(() => {
            window.open(res.data.payUrl)
          }, 1500)
        } else {
          Message.error(res.message || '购买失败')
        }
      })
    })
    .catch((err) => {
      console.log(err)
    })
}

const onCancelDomain = () => {
  state.domainVisible = false
  domainOrderForm.payAddress = ''
}

onMounted(() => {
  getQrcodeList()
})
</script>
<style lang="less" scoped>
.qrcode-top {
  display: flex;

  .qrcode {
    width: 400px;

    &>div {
      width: 200px;
      margin-left: 20px;
      text-align: center;
    }

    .qrcode-canvas {
      padding: 12px 0;
    }
  }

  .desc {
    flex: 1;
    min-width: 300px;
    line-height: 28px;
    color: #999;
  }

  .qrcode-title {
    color: #599cf8;
    font-weight: 600;
    font-size: 16px;
  }
}
</style>
