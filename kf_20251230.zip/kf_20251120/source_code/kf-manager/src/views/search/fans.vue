<template>
  <div class="search-container">
    <a-card class="search-card" title="卡密状态查询" :bordered="false">
      <a-form :model="searchParams" class="search-form" layout="vertical">
        <!-- <a-row>
          <a-col :span="8">
            <a-form-item label="显示筛选">
              <div style="display: flex; gap: 8px;">
                <a-button :type="searchParams.status === 0 ? 'primary' : 'default'"
                  @click="searchParams.status = 0">全部</a-button>
                <a-button :type="searchParams.status === 1 ? 'primary' : 'default'"
                  @click="searchParams.status = 1">有效</a-button>
                <a-button :type="searchParams.status === 2 ? 'primary' : 'default'"
                  @click="searchParams.status = 2">非微信</a-button>
                <a-button :type="searchParams.status === 3 ? 'primary' : 'default'"
                  @click="searchParams.status = 3">未WS</a-button>
              </div>
              <div style="display: flex; gap: 8px;margin-top: 12px;">
                <a-button :type="searchParams.platform === '' ? 'primary' : 'default'"
                  @click="searchParams.platform = ''">全部</a-button>
                <a-button :type="searchParams.platform === 'apple' ? 'primary' : 'default'"
                  @click="searchParams.platform = 'apple'">苹果</a-button>
                <a-button :type="searchParams.platform === 'android' ? 'primary' : 'default'"
                  @click="searchParams.platform = 'android'">安卓</a-button>
              </div>
            </a-form-item>
          </a-col>
        </a-row> -->

        <a-row :gutter="24">
          <a-col :span="8">
            <a-form-item label="卡密ID">
              <a-input v-model:value="searchParams.cardId" placeholder="请输入卡密ID" allowClear />
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item label="注册时间">
              <a-range-picker v-model:value="searchParams.loginTime" style="width: 100%" />
            </a-form-item>
          </a-col>
          <a-col :span="8">
            <a-form-item label="访客IP">
              <a-textarea v-model:value="searchParams.ip" placeholder="请输入访客ip，一行一个" allow-clear :rows="4" />
            </a-form-item>
          </a-col>
        </a-row>

        <a-row>
          <a-col :span="24">
            <a-form-item>
              <a-space>
                <a-button type="primary" @click="onButtonSerch">查询</a-button>
                <a-button type="primary" @click="onExport">导出</a-button>
              </a-space>
            </a-form-item>
          </a-col>
        </a-row>
      </a-form>
    </a-card>

    <a-card class="status-card" title="状态说明" :bordered="false">
      <a-row :gutter="[16, 16]">
        <a-col :span="8">
          <a-card size="small" :bordered="false" class="status-item status-normal">
            <template #title>
              <span class="status-title">正常</span>
            </template>
            <p class="status-desc">有效有效访客</p>
          </a-card>
        </a-col>
        <a-col :span="8">
          <a-card size="small" :bordered="false" class="status-item status-ip-high">
            <template #title>
              <span class="status-title">非国内</span>
            </template>
            <p class="status-desc">非国内无效访客 代表访问者ip地址非果内</p>
          </a-card>
        </a-col>
        <a-col :span="8">
          <a-card size="small" :bordered="false" class="status-item status-ip-medium">
            <template #title>
              <span class="status-title">非微信</span>
            </template>
            <p class="status-desc">非微信无效访客 代表访问者并非使用微信扫码进入</p>
          </a-card>
        </a-col>
        <a-col :span="8">
          <a-card size="small" :bordered="false" class="status-item status-no-ws">
            <template #title>
              <span class="status-title">未WS</span>
            </template>
            <p class="status-desc">无效访客,代表访问者通过访问入口，获取到了落地地址并访问，但是并未创建WS聊天的链接至服务器,可能是脚本</p>
          </a-card>
        </a-col>
        <a-col :span="8">
          <a-card size="small" :bordered="false" class="status-item status-non-wechat">
            <template #title>
              <span class="status-title">IP次数大于9小于20</span>
            </template>
            <p class="status-desc">代表当前访客IP在系统中出现次数大于9且小于20</p>
          </a-card>
        </a-col>
        <a-col :span="8">
          <a-card size="small" :bordered="false" class="status-item status-non-domestic">
            <template #title>
              <span class="status-title">IP次数大于20</span>
            </template>
            <p class="status-desc">代表当前访客IP在系统中出现次数大于20</p>
          </a-card>
        </a-col>
      </a-row>
    </a-card>

    <a-card class="table-card" :bordered="false">
      <a-table :dataSource="data" :columns="columns" :pagination="false" :scroll="{ x: 1500 }">
        <template #bodyCell="{ column, text, record }">
          <template v-if="column.dataIndex === 'status'">
            <a-tag color="green" v-if="record.status == 1">正常</a-tag>
            <a-tag color="red" v-if="record.status == 2">非国内</a-tag>
            <a-tag color="cyan" v-if="record.status == 3">非微信</a-tag>
            <a-tag color="pink" v-if="record.status == 4">未ws</a-tag>
            <a-tag color="orange" v-if="record.status == 5">IP次数大于9小于20</a-tag>
            <a-tag color="blue" v-if="record.status == 6">ip次数大于20</a-tag>
          </template>
        </template>
      </a-table>
      <div class="pagination-container">
        <a-pagination v-model:current="searchParams.page" :defaultPageSize="20" :total="total" @change="onPage"
          show-size-changer show-quick-jumper :show-total="(total) => `共 ${total} 条`" />
      </div>
    </a-card>
  </div>
</template>

<script lang="ts" setup>
import { computed, reactive, ref } from 'vue'
import { SearchAPI } from '@/webapi'
import { message as Message } from 'ant-design-vue'
import dayjs from 'dayjs'
import { parseUserAgent } from '@/utils/userAgent'

const cardIds = ref('')
const data = ref([])
const total = ref(0)

const searchParams = reactive({
  cardId: '',
  page: 1,
  pageSize: 10,
  ip: '',
  loginTime: [],
  status: 0,
  platform: '',
})

const onButtonSerch = () => {
  searchParams.page = 1; // 重置页码
  onSearch();
}

const onPage = (page: number) => {
  searchParams.page = page;
  onSearch();
}

const onExport = async () => {
  if (searchParams.cardId === '') {
    Message.error('请输入卡密信息')
    return
  }
  let param = {
    cardId: searchParams.cardId,
    page: searchParams.page,
    pageSize: searchParams.pageSize,
    registerBeginTime: searchParams.loginTime.length > 0 ? dayjs(searchParams.loginTime[0]).unix() * 1000 : 0,
    registerEndTime: searchParams.loginTime.length > 1 ? dayjs(searchParams.loginTime[1]).unix() * 1000 : 0,
    ip: searchParams.ip,
    export: true, // 添加导出标志
  }

  let resp = await SearchAPI.exportFans(param)
}

const onSearch = async () => {
  if (searchParams.cardId === '') {
    Message.error('请输入卡密信息')
    return
  }
  console.log(searchParams.loginTime)
  let param = {
    cardId: searchParams.cardId,
    page: searchParams.page,
    pageSize: searchParams.pageSize,
    registerBeginTime: searchParams.loginTime.length > 0 ? dayjs(searchParams.loginTime[0]).unix() * 1000 : 0,
    registerEndTime: searchParams.loginTime.length > 1 ? dayjs(searchParams.loginTime[1]).unix() * 1000 : 0,
    ip: searchParams.ip,
  }

  let resp = await SearchAPI.fans(param)
  if (resp.code !== 200) {
    Message.error('查询失败')
    return
  }
  if (!resp.data.list || resp.data?.list?.length === 0) {
    Message.error('未查询到信息')
    return
  }
  data.value = [];
  total.value = resp.data.cnt;
  resp.data.list.forEach((item: any) => {
    let lasgLoginTime = item.lastReadMsgAt || item.createdAt;
    let ua = parseUserAgent(item.userAgent);
    item = {
      ...item,
      isOnline: item.isOnline ? '是' : '否',
      isEmulatorText: item.isEmulator ? '是' : '否',
      isProxyText: item.isProxy ? '是' : '否',
      isWsText: item.isWs ? '是' : '否',
      createdAtText: formatTimestamp(item.createdAt),
      lastReadMsgAtText: formatTimestamp(lasgLoginTime),
      staySeconds: item.staySeconds || 0,
      scanCount: item.scanCount || 0,
      device: [ua.systemType, ua.deviceType, ua.browserType].filter(Boolean).join('-'),
    }
    data.value.push(item);
  })
}

const formatTimestamp = (timestamp: number) => {
  return dayjs.unix(timestamp).format('YYYY-MM-DD HH:mm:ss')
}

const columns = reactive([
  {
    title: '状态',
    dataIndex: 'status',
    key: 'status',
    width: 100,
    fixed: 'left',
  },
  {
    title: '备注',
    dataIndex: 'remarkName',
    key: 'remarkName',
    width: 150,
  },
  {
    title: '访客名称',
    dataIndex: 'nickName',
    key: 'nickName',
    width: 150,
  },
  {
    title: '手机号',
    dataIndex: 'mobile',
    key: 'mobile',
    width: 180,
  },
  {
    title: '是否在线',
    dataIndex: 'isOnline',
    key: 'isOnline',
    width: 180,
  },
  {
    title: '首次访问时间',
    dataIndex: 'createdAtText',
    key: 'createdAtText',
    width: 180,
  },
  {
    title: '最近登录时间',
    dataIndex: 'lastReadMsgAtText',
    key: 'lastReadMsgAtText',
    width: 180,
  },
  {
    title: '停留时长',
    dataIndex: 'staySeconds',
    key: 'staySeconds',
    width: 180,
  },
  {
    title: '扫码次数',
    dataIndex: 'scanCount',
    key: 'scanCount',
    width: 180,
  },
  {
    title: '注册IP',
    dataIndex: 'ip',
    key: 'ip',
    width: 180,
  },
  {
    title: 'ip次数',
    dataIndex: 'ipCnt',
    key: 'ipCnt',
    width: 180,
  },
  {
    title: 'ip归属地',
    dataIndex: 'area',
    key: 'area',
    width: 200,
  },
  {
    title: '系统类型',
    dataIndex: 'device',
    key: 'device',
    width: 240,
  },
  {
    title: '是否模拟器',
    dataIndex: 'isEmulatorText',
    key: 'isEmulatorText',
    width: 180,
  },
  {
    title: '是否代理',
    dataIndex: 'isProxyText',
    key: 'isProxyText',
    width: 180,
  },
  {
    title: '是否ws',
    dataIndex: 'isWsText',
    key: 'isWsText',
    width: 180,
  }
])

</script>
<style lang="less" scoped>
@import '@/style/index.less';

.search-container {
  min-height: 100vh;

  .search-card,
  .status-card,
  .table-card {
    margin-bottom: 24px;
    border-radius: 8px;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
  }

  .search-form {
    .ant-form-item {
      margin-bottom: 16px;
    }
  }

  .c-1 {
    background-color: #52c41a;
    color: #fff;
  }

  .c-2 {
    background-color: #f5222d;
    color: #fff;
  }

  .c-3 {
    background-color: #fa8c16;
    color: #fff;
  }

  .c-4 {
    background-color: #eb2f96;
    color: #fff;
  }

  .c-5 {
    background-color: #13c2c2;
    color: #fff;
  }

  .c-6 {
    background-color: #1890ff;
    color: #fff;
  }

  .c-7 {
    background-color: #2f54eb;
    color: #fff;
  }


  .status-card {
    .status-item {
      transition: all 0.3s;
      border-left: 4px solid transparent;

      &:hover {
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.09);
      }

      .status-title {
        font-weight: 500;
      }

      .status-desc {
        margin: 0;
        color: #666;
      }

      &.status-normal {
        border-left-color: #52c41a;

        .status-title {
          color: #52c41a;
        }
      }

      &.status-non-domestic {
        border-left-color: #f5222d;

        .status-title {
          color: #f5222d;
        }
      }

      &.status-non-wechat {
        border-left-color: #fa8c16;

        .status-title {
          color: #fa8c16;
        }
      }

      &.status-no-ws {
        border-left-color: #eb2f96;

        .status-title {
          color: #eb2f96;
        }
      }

      &.status-ip-medium {
        border-left-color: #13c2c2;

        .status-title {
          color: #13c2c2;
        }
      }

      &.status-ip-high {
        border-left-color: #1890ff;

        .status-title {
          color: #1890ff;
        }
      }
    }
  }

  .table-card {
    .pagination-container {
      margin-top: 16px;
      text-align: right;
    }
  }
}
</style>
