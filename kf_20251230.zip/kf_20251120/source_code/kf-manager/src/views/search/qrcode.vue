<template>
    <div class="search-container">
        <h2 style="text-align: center;">引流工作台</h2>

        <a-textarea v-model:value="cardIds" placeholder="请输入卡密，一行一个" allow-clear :rows="8" />
        <a-button type="primary" class="search-btn" @click="search">获取二维码</a-button>
        <a-button type="primary" class="search-btn" @click="searchUserIncr">查询用户新增</a-button>

        <div class="mt-2" v-if="qrcodeSearchData.length > 0">
            <a-table :dataSource="qrcodeSearchData" :columns="qrcodeColumns" :pagination="false">
                <template #bodyCell="{ column, text, record }">
                    <template v-if="column.dataIndex === 'qrcode'">
                        <img :src="record.qrcode" alt="二维码" style="width: 100px; height: 100px;" />
                    </template>
                    <template v-if="column.dataIndex === 'operation'">
                        <a-button type="primary" @click="downLoadQrCode(record.qrcode)">下载二维码</a-button>
                    </template>
                </template>
            </a-table>
        </div>

        <div class="mt-2" v-show="columns.length > 0">
            <a-table :dataSource="data" :columns="columns" :pagination="false">

            </a-table>
        </div>
    </div>
</template>

<script lang="ts" setup>
import { computed, reactive, ref } from 'vue'
import { SearchAPI } from '@/webapi'
import { message as Message } from 'ant-design-vue'
import dayjs from 'dayjs'
import QRCode from 'qrcode'
import { getQrcode } from '@/webapi/qrcode'

const cardIds = ref('')
const data = ref([])
const qrcodeSearchData = ref([])

const search = async () => {
    if (cardIds.value.trim() === '') {
        Message.error('请输入卡密信息')
        return
    }
    let resp = await SearchAPI.qrcode({ cardId: cardIds.value })
    if (resp.code !== 200) {
        Message.error('查询失败')
        return
    }
    if (!resp.data.domains || resp.data?.domains?.length === 0) {
        Message.error('未查询到相关卡密信息')
        return
    }

    for (var i = 0; i < resp.data.domains.length; i++) {
        let item = resp.data.domains[i]
        const qrcodeImg = await QRCode.toDataURL(getQrcodeUrl(item.qrCodeUrl, item.domain), {
            width: 80,
            margin: 1
        });
        qrcodeSearchData.value.push({
            cardId: item.cardId,
            domain: item.domain,
            qrcode: qrcodeImg,
        })
    }

}


// 下载二维码
const downLoadQrCode = async (url) => {
    const a = document.createElement('a')
    a.download = 'QRCode.png'
    a.href = url
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
}


const createQrcode = async (value) => {
    let url = await QRCode.toDataURL(value)
    return url;
}

const getQrcodeUrl = (url: string, domain: string) => {
    if (domain.startsWith('http')) {
        return domain + url
    }
    return window.location.protocol + '//' + domain + url
}


const qrcodeColumns = reactive([
    {
        title: '卡密',
        dataIndex: 'cardId',
        key: 'cardId',
    },
    {
        title: '域名',
        dataIndex: 'domain',
        key: 'domain',
    },
    {
        title: '二维码',
        dataIndex: 'qrcode',
        key: 'qrcode',
    },
    {
        title: '操作',
        dataIndex: 'operation',
        width: 400
    }
])


const columns = ref([])

const searchUserIncr = async () => {
    if (cardIds.value.trim() === '') {
        Message.error('请输入卡密信息')
        return
    }
    let resp = await SearchAPI.dayincr7({ cardId: cardIds.value })
    if (resp.code !== 200) {
        Message.error('查询失败')
        return
    }
    columns.value = [{
        title: '卡密',
        dataIndex: 'cardId',
        key: 'cardId',
    }]

    resp.data.rows.forEach(item => {
        columns.value.push({
            title: item,
            dataIndex: item,
            key: item,
        })
    })
    data.value = []
    resp.data.cardUserCount?.forEach((item: any) => {
        let obj = {
            cardId: item.cardId,
            ...item.userCount,
        }
        for (let i = 0; i < resp.data.rows.length; i++) {
            if (!obj[resp.data.rows[i]]) {
                obj[resp.data.rows[i]] = 0
            }
        }
        data.value.push(obj)
    })

    // for (var i = 0; i < resp.data.domains.length; i++) {
    //     let item = resp.data.domains[i]
    //     const qrcodeImg = await QRCode.toDataURL(getQrcodeUrl(item.qrCodeUrl, item.domain), {
    //         width: 80,
    //         margin: 1
    //     });
    //     qrcodeSearchData.value.push({
    //         cardId: item.cardId,
    //         domain: item.domain,
    //         qrcode: qrcodeImg,
    //     })
    // }
}


</script>
<style lang="less" scoped>
@import '@/style/index.less';

.search-container {
    padding-top: 20px;
    width: 75%;
    margin: auto;
}

.search-btn {
    margin: auto;
    margin-top: 20px;
    width: 100%;
    display: block;
}

.mt-2 {
    margin-top: 20px;
}
</style>