<template>
  <div class="search-container">
    <h2 style="text-align: center;">卡密状态查询</h2>

    <a-textarea v-model:value="cardIds" placeholder="请输入卡密，一行一个" allow-clear :rows="8" />
    <a-button type="primary" class="search-btn" @click="search">点击查询</a-button>

    <div class="mt-2">
      <a-table :dataSource="data" :columns="columns" :pagination="false" />
    </div>
  </div>
</template>

<script lang="ts" setup>
import { computed, reactive, ref } from 'vue'
import { SearchAPI } from '@/webapi'
import { message as Message } from 'ant-design-vue'
import dayjs from 'dayjs'

const cardIds = ref('')
const data = ref([])

const search = async () => {
  if (cardIds.value.trim() === '') {
    Message.error('请输入卡密信息')
    return
  }
  let resp = await SearchAPI.cardStatus({ cardId: cardIds.value })
  if (resp.code !== 200) {
    Message.error('查询失败')
    return
  }
  if (!resp.data.list || resp.data?.list?.length === 0) {
    Message.error('未查询到相关卡密信息')
    return
  }
  resp.data.list.forEach((item: any) => {
    item.cardTypeText = item.cardType === 1 ? '正式卡' : '测试卡'
    if (item.expireTime === 0) {
      item.expireTimeText = '--'
      item.status = '未使用'
    } else {
      item.expireTimeText = dayjs(item.expireTime * 1000).format('YYYY-MM-DD HH:mm:ss')
      item.status = item.expired ? '已过期' : '未过期'
    }
    data.value.push({
      cardId: item.cardId,
      cardTypeText: item.cardTypeText,
      status: item.status,
      expireTimeText: item.expireTimeText,
    })
  })
}

const columns = reactive([
  {
    title: '卡密',
    dataIndex: 'cardId',
    key: 'cardId',
  },
  {
    title: '卡密类型',
    dataIndex: 'cardTypeText',
    key: 'cardTypeText',
  },
  {
    title: '状态',
    dataIndex: 'status',
    key: 'status',
  },
  {
    title: '过期时间',
    dataIndex: 'expireTimeText',
    key: 'expireTimeText',
  },
])

</script>
<style lang="less" scoped>
@import '@/style/index.less';

.search-container {
  padding-top: 20px;
  width: 75%;
  margin: auto;
}

.search-btn {
  margin: auto;
  margin-top: 20px;
  width: 100%;
  display: block;
}

.mt-2 {
  margin-top: 20px;
}
</style>
