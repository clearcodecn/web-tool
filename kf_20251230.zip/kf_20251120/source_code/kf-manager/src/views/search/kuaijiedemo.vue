<template>
  <div>快捷页面2</div>
</template>

<script lang="ts" setup>
import { computed, reactive, ref } from 'vue'
</script>
<style lang="less" scoped></style>
