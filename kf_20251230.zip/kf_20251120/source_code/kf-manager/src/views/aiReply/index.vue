<!-- 二维码页面 -->
<template>
  <div class="kf-body">
    <div class="top-action">
      <a-button type="primary" @click="onAddMsg">添加智能欢迎语</a-button>
      <div @click="onRefesh">
        <span class="refesh">
          <ReloadOutlined />
        </span>
      </div>
    </div>
    <MaterialTable type="smart_msg" ref="tableRef"></MaterialTable>
  </div>
</template>

<script lang="ts" setup>
import { computed, ref, onMounted, reactive } from 'vue'
import { ReloadOutlined } from '@ant-design/icons-vue'
import MaterialTable from '@/components/MaterialTable/index.vue'

const tableRef: any = ref('')

const onRefesh = () => {
  tableRef.value && tableRef.value.onRefesh()
}
const onAddMsg = () => {
  tableRef.value && tableRef.value.onAddMsg()
}

onMounted(() => {
  tableRef.value && tableRef.value.getTableList()
})
</script>
<style lang="less" scoped>
.top-action {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding-bottom: 12px;
}
.refesh {
  cursor: pointer;
  width: 27px;
  height: 27px;
  line-height: 24px;
  text-align: center;
  display: inline-block;
  border-radius: 50%;
  border: 1px solid #eee;
  background-color: #fff;
  &:hover {
    background-color: #eee;
  }
}
.anticon-edit span {
  margin-inline-start: 0;
}
</style>
