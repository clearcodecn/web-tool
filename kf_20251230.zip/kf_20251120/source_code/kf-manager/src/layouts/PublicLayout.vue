<template>
  <div id="PublicLayout">
    <div class="container">
      <div class="user-layout-content">
        <router-view />
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup name="PublicLayout">
import { onMounted, onBeforeUnmount } from 'vue'

onMounted(() => {
  document.body.classList.add('PublicLayout')
})
onBeforeUnmount(() => {
  document.body.classList.remove('PublicLayout')
})
</script>

<style lang="less" scoped>
</style>
