<template>
    <div id="SearchLayout">
        <div class="container">
            <a-layout-content style="padding: 0 50px">
                <div :style="{ background: '#fff', padding: '24px', minHeight: '280px' }">
                    <router-view />
                </div>
            </a-layout-content>
        </div>
    </div>
</template>

<script lang="ts" setup name="SearchLayout">
import { onMounted, onBeforeUnmount } from 'vue'

onMounted(() => {
    document.body.classList.add('SearchLayout')
})
onBeforeUnmount(() => {
    document.body.classList.remove('SearchLayout')
})
</script>

<style lang="less" scoped></style>
