import { UserLayout } from '@/layouts'
import { h } from 'vue'
import { BasicLayout, RouteView, BlankLayout, SearchLayout } from '@/layouts'
import { type Router } from './types'

// info:todo:1.如果使用服务端获取路由,path: '/',这块路由再写就会被覆盖
// 2.router.addRoute(parent, routeObj),添加parent,它就会自动加上/parent/xxx,直接写parent即可,就算嵌套多层也没事,自动变成/xxxx/xxxx/parent/xxxxx
// 3.以"/"开头的嵌套路径会被当作根路径，所以子路由上不用加"";
// 在生成路由时，主路由上的path会被自动添加到子路由之前，所以子路由上的path不用在重新声明主路由上的path了。
export default [
  {
    path: '/',
    name: 'index',
    component: BasicLayout,
    redirect: '/qrCode',
    children: [
      {
        path: '/qrCode',
        name: 'qrCode',
        meta: { title: '二维码', icon: 'icon-erweima' },
        component: () => import('@/views/qrCode/index.vue')
      },
      {
        path: '/qrCode/order',
        name: 'qrCode-order',
        component: () => import('@/views/qrCode/order.vue'),
        meta: { title: '域名订单', hidden: true }
      },
      {
        path: '/chat',
        name: 'Chat',
        component: () => import('@/views/chat/index.vue'),
        meta: { title: '消息', icon: 'icon-xiaoxi' }
      },
      {
        path: '/welcomeMsg',
        name: 'welcomeMsg',
        meta: { title: '欢迎语', icon: 'icon-huanyingyu' },
        component: () => import('@/views/welcomeMsg/index.vue')
      },
      // 没有想好怎么实现， 暂时屏蔽
      {
        path: '/aiReply',
        name: 'aiReply',
        meta: { title: '智能回复', icon: 'icon-zhinenghuifu' },
        component: () => import('@/views/aiReply/index.vue')
      },
      {
        path: '/quickReply',
        name: 'quickReply',
        meta: { title: '快捷回复', icon: 'icon-kuaijiehuifu' },
        component: () => import('@/views/quickReply/index.vue')
      },
      {
        path: '/speechCraft',
        name: 'speechCraft',
        meta: { title: '话术复制', icon: 'icon-fuzhi' },
        component: () => import('@/views/speech/index.vue')
      },

      {
        path: '/userReport',
        name: 'userReport',
        meta: { title: '用户列表', icon: 'icon-user' },
        component: () => import('@/views/userReport/index.vue')
      },
      {
        path: '/systemLog',
        name: 'systemLog',
        meta: { title: '日志', icon: 'icon-rizhi' },
        component: () => import('@/views/systemLog/index.vue')
      },
      {
        path: '/systemSetting',
        name: 'systemSetting',
        meta: { title: '设置', icon: 'icon-shezhi' },
        component: () => import('@/views/systemSetting/index.vue')
      }
    ]
  },
  {
    path: '/user',
    name: 'user',
    component: UserLayout,
    redirect: '/user/login',
    hidden: true,
    children: [
      {
        path: 'login',
        name: 'login',
        component: () => import(/* webpackChunkName: "user" */ '@/views/user/Login.vue'),
        meta: { title: '登录' }
      },
      {
        path: 'recover',
        name: 'recover',
        component: undefined
      }
    ]
  },
  {
    path: '/search',
    name: 'search',
    component: SearchLayout,
    redirect: '/search/cardStatus',
    hidden: true,
    children: [
      {
        path: 'cardStatus',
        name: 'cardSearchPage',
        component: () => import(/* webpackChunkName: "search" */ '@/views/search/index.vue'),
        meta: { title: '查询卡密' },
      },
      {
        path: 'fans',
        name: 'fans',
        component: () => import(/* webpackChunkName: "search" */ '@/views/search/fans.vue'),
        meta: { title: '查粉' },
      },
      {
        name: 'searchQrcode',
        path: 'qrcode',
        component: () => import(/* webpackChunkName: "search" */ '@/views/search/qrcode.vue'),
        meta: { title: '查询二维码' },
      }
      // {
      //   path: 'kuaijiedemo',
      //   name: 'kuaijiedemo',
      //   component: () => import(/* webpackChunkName: "search" */ '@/views/search/kuaijiedemo.vue'),
      //   meta: { title: '快捷入口2' }
      // }
    ]
  },
  {
    path: '/:path(.*)',
    name: 'NoMatch',
    component: () => import('@/views/exception/404.vue')
  }
] as Router[]
