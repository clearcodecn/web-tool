import * as UserApi from './user'
import * as QrcodeApi from './qrcode'
import * as SystemApi from './system'
import * as ChatApi from './chat'
import * as MessageApi from './message'
import * as ReportApi from './report'
import * as SearchAPI from './search'

export { UserApi, QrcodeApi, SystemApi, ChatApi, MessageApi, ReportApi, SearchAPI }
