import baseService from '@/utils/http/axios'

// 用户报表列表
export const getUserReportList = (data: any) => {
  return baseService.get(`api/kf-be/report/user`, { params: data })
}

// 导出用户报表
export const exportUserReport = (data: any) => {
  return baseService.get(`api/kf-be/report/user/export`, { 
    params: data,
    responseType: 'blob'
  })
} 