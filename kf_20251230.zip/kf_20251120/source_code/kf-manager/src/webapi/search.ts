import baseService from '@/utils/http/axios'

export const cardStatus = (data: any) => {
    return baseService.post(`api/kf-be/search/cardstatus`, data)
}

export const qrcode = (data: any) => {
    return baseService.post(`api/kf-be/search/qrcode`, data)
}

export const dayincr7 = (data: any) => {
    return baseService.post(`api/kf-be/search/7dayincr`, data)
}


export const fans = (data: any) => {
    return baseService.post(`api/kf-be/search/fans`, data)
}

export const exportFans = async (data: any) => {
    let resp = await baseService.post(`api/kf-be/search/fans`, data)
    console.log(resp.data);

    // 创建下载链接
    const downloadUrl = window.URL.createObjectURL(new Blob([resp.data]));
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.setAttribute('download', 'filename.csv'); // 设置下载文件名
    document.body.appendChild(link);
    link.click();

    // 清理
    document.body.removeChild(link);
    window.URL.revokeObjectURL(downloadUrl);
}
