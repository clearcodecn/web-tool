const token = 'f64366a9-19dc-43fb-b1ed-c33bb11180b6'

class WebSocketClient {
  constructor(params) {
    this.onlineHandlers = []
    this.offlineHandlers = []
    this.messageHandlers = []
    this.readHandlers = []
    this.connect(params)
  }

  // 连接方法
  connect(params) {
    this.messageHandlers = []

    console.log('-ws->', params)

    let socketHost = params.wsHost
    let host = ''
    host = socketHost.replace(/^(ws|wss):\/\//, '') // 去掉前面的 ws:// 或 wss://
    host = host.replace(/\/$/, '') // 去掉末尾的斜杠

    const wsOptions = {
      host: host, // 域名，部署到线上直接用当前域名，本地连接可以写死。
      secure: true, // 固定
      transports: ['websocket'], // 固定
      query: `platform=kf-backend&token=${params.token}`,
      path: '/socket.io/' // 固定
    }

    console.log('wsOptions:', wsOptions)
    console.log('params:', params)

    this.socket = io(socketHost, wsOptions)

    // 服务端确认收到消息
    this.socket.on('messageAck', (msg) => {
      let data = JSON.parse(msg)
    })

    this.socket.on('message', (msg) => {
      let data = JSON.parse(msg)
      this.messageHandlers.forEach((handler) => handler(data))
    })

    this.socket.on('online', (msg) => {
      this.onlineHandlers.forEach((handler) => handler(JSON.parse(msg)))
    })

    this.socket.on('offline', (msg) => {
      this.offlineHandlers.forEach((handler) => handler(JSON.parse(msg)))
    })

    // 新增已读消息事件处理
    this.socket.on('read', (msg) => {
      this.readHandlers.forEach((handler) => handler(JSON.parse(msg)))
    })

    this.socket.on('disconnect', (reason) => {
      console.log('Disconnected from the server:', reason)
    })

    this.socket.on('sessionId', function (msg) {
      console.log('sessionId-->', msg)
    })
  }

  // 发送消息
  sendMessage(message) {
    console.log('发送消息:', message)
    this.socket.emit('message', JSON.stringify(message))
  }

  // 接收消息
  onMessage(handler) {
    this.messageHandlers.push(handler)
  }

  onOnline(handler) {
    this.onlineHandlers.push(handler)
  }

  onOffline(handler) {
    this.offlineHandlers.push(handler)
  }

  // 新增已读消息处理
  onRead(handler) {
    this.readHandlers.push(handler)
  }
}

export default WebSocketClient
