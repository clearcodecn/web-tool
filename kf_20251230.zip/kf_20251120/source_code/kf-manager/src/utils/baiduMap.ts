// 百度地图加载状态
let bmapLoading = false;
let bmapLoaded = false;

// 加载百度地图脚本
export const loadBMapScript = (): Promise<typeof BMap> => {
    return new Promise((resolve, reject) => {
        if (window.BMap) {
            bmapLoaded = true;
            resolve(window.BMap);
            return;
        }

        if (bmapLoading) {
            // 如果正在加载，等待加载完成
            const checkBMap = setInterval(() => {
                if (window.BMap) {
                    clearInterval(checkBMap);
                    bmapLoaded = true;
                    resolve(window.BMap);
                }
            }, 100);
            return;
        }

        bmapLoading = true;
        const script = document.createElement('script');
        script.type = 'text/javascript';
        script.src = `https://api.map.baidu.com/api?v=3.0&ak=baiduKey&callback=initBMap`;
        script.onerror = (error) => {
            bmapLoading = false;
            reject(error);
        };
        window.initBMap = () => {
            bmapLoading = false;
            bmapLoaded = true;
            resolve(window.BMap);
            document.body.removeChild(script);
            delete window.initBMap;
        };
        document.body.appendChild(script);
    });
};

// 获取IP定位
export const getLocationByIP = async (): Promise<{ lat: number; lng: number }> => {
    try {
        await loadBMapScript();
        return new Promise((resolve, reject) => {
            const geolocation = new BMap.Geolocation();
            geolocation.getCurrentPosition((result) => {
                if (result && result.point) {
                    resolve({
                        lat: result.point.lat,
                        lng: result.point.lng
                    });
                } else {
                    // 如果获取失败，使用默认位置（北京）
                    resolve({
                        lat: 39.915,
                        lng: 116.404
                    });
                }
            }, {
                enableHighAccuracy: true,
                timeout: 5000,
                maximumAge: 0
            });
        });
    } catch (error) {
        console.error('Failed to get location:', error);
        // 返回默认位置
        return {
            lat: 39.915,
            lng: 116.404
        };
    }
};

// 获取静态地图URL
export const getStaticMapUrl = (lat: number, lng: number, width = 300, height = 150): string => {
    const params = new URLSearchParams({
        ak: 'ePN0XerR3AmMxXutHAPir5K55Xco0L7e',
        mcode: '666666',
        center: `${lng},${lat}`,
        width: width.toString(),
        height: height.toString(),
        zoom: '15',
        markers: `${lng},${lat}`,
        coordtype: 'bd09ll'
    });
    return `https://api.map.baidu.com/staticimage/v2?${params.toString()}`;
}; 