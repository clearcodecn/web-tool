export const parseUserAgent = (userAgent: string) => {
  const ua = userAgent.toLowerCase();
  
  // 系统类型
  let systemType = '-';
 if (ua.includes('windows')) {
    systemType = 'Windows';
  } else if (ua.includes('android')) {
    systemType = '安卓 (Android)';
  } else if (ua.includes('iphone') || ua.includes('ipad')) {
    systemType = 'iPhone (iOS)';
  } else if (ua.includes('mac os x')) {
    systemType = '苹果电脑';
  }

  // 设备类型
  let deviceType = '-';
  if (ua.includes('mobile') || ua.includes('android') || ua.includes('iphone') || ua.includes('ipad')) {
    deviceType = '手机';
  } else {
    deviceType = '电脑';
  }

  // 浏览器类型
  let browserType = '-';
  if (ua.includes('micromessenger')) {
    browserType = '微信扫码';
  } else if (ua.includes('chrome')) {
    browserType = 'Chrome';
  } else if (ua.includes('firefox')) {
    browserType = 'Firefox';
  } else if (ua.includes('safari') && !ua.includes('chrome')) {
    browserType = 'Safari';
  } else if (ua.includes('msie') || ua.includes('trident')) {
    browserType = 'IE';
  } else if (ua.includes('edge')) {
    browserType = 'Edge';
  } else {
    browserType = '其他';
  }

  return {
    systemType,
    deviceType,
    browserType
  };
}; 