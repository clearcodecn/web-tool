# 天马云客服系统安装指南

## 系统要求

- Ubuntu 20.04 或更高版本
- 至少 2GB 内存
- 至少 1GB 可用磁盘空间
- 1个CPU核心

## 依赖要求

安装脚本会自动检测并安装以下依赖：

- **Docker**: 任意版本 (使用官方安装脚本)
- **Go**: >= 1.23.2 (从golang.org下载，用于构建Docker镜像)
- **Node.js**: >= 18.20.4 (通过NVM安装，用于构建前端)
- **NVM**: Node Version Manager
- **Nginx**: 任意版本 (apt安装)
- **Make**: 用于执行Makefile构建命令

## 架构说明

系统采用Docker化部署架构：

- **基础服务**: MySQL, Redis, NSQ (通过docker-compose管理)
- **后端服务**: kf-api, kf-message (构建为Docker镜像)
- **前端服务**: kf-bill, kf-manager, kf-mobile (构建为静态文件)
- **Web服务器**: Nginx (反向代理和静态文件服务)

## 快速安装

### 1. 下载源码

```bash
# 克隆或下载源码到服务器
cd /path/to/your/project
```

### 2. 运行安装脚本

```bash
# 给脚本执行权限
chmod +x install.sh

# 以root用户运行安装脚本
sudo ./install.sh
```

### 3. 安装过程

安装脚本会自动执行以下步骤：

1. **系统检查**: 检查是否为root用户
2. **用户输入**: 收集域名和密码配置
3. **依赖检测与安装**:
   - 检测现有依赖版本
   - 更新系统包
   - 安装基础依赖
   - 智能安装缺失或版本过低的依赖
   - 显示所有依赖的版本信息
4. **环境配置**:
   - 创建安装目录
   - 复制源码
   - 替换配置文件
   - 创建MySQL初始化脚本
   - 创建Docker网络
5. **服务部署**:
   - 构建后端服务Docker镜像 (使用Makefile)
   - 启动基础Docker服务 (MySQL, Redis, NSQ)
   - 启动后端Docker服务 (kf-api, kf-message)
   - 构建前端服务 (kf-bill, kf-manager, kf-mobile)
   - 配置Nginx
   - 创建服务管理脚本

### 4. 依赖检测功能

安装脚本具有智能依赖检测功能：

- **版本检测**: 自动检测已安装的依赖版本
- **版本比较**: 与要求版本进行比较
- **智能安装**: 只安装缺失或版本过低的依赖
- **版本输出**: 安装完成后显示所有依赖的版本信息

示例输出：
```
[INFO] 检测到Docker版本: 24.0.2
[INFO] 检测到Go版本: 1.23.2
[INFO] Go版本满足要求 (>= 1.23.2)
[INFO] 检测到NVM已安装
[INFO] 检测到Node.js版本: 18.20.4
[INFO] Node.js版本满足要求 (>= 18.20.4)
[INFO] 检测到Nginx版本: 1.29.0
```

### 5. 配置说明

安装过程中需要提供以下信息：

- **域名**: 例如 `example.com`
- **密码选项**: 可选择自动生成或手动输入
  - MySQL密码
  - Redis密码
  - 管理员密码

### 6. 安装完成

安装完成后会显示：

```
==========================================
天马云客服系统安装完成
==========================================
域名: example.com
安装路径: /www
客服后台: http://manager.example.com
总后台: http://bill.example.com
管理员账号: admin
管理员密码: [自动生成的密码]
MySQL密码: [自动生成的密码]
Redis密码: [自动生成的密码]

服务管理命令:
启动服务: /www/start.sh
停止服务: /www/stop.sh
重启服务: /www/restart.sh

查看日志:
kf-api日志: docker-compose logs -f (在 /www/kf-api 目录下)
kf-message日志: docker-compose logs -f (在 /www/kf-message 目录下)
基础服务日志: docker-compose logs -f (在 /www/kf-containers 目录下)
查看所有容器: docker ps
==========================================
```

## 测试依赖检测

在安装前，可以运行测试脚本检查当前系统依赖：

```bash
# 运行版本检测测试
./test_versions.sh
```

这将显示当前系统中所有依赖的版本信息，帮助确认是否需要安装或更新。

## 服务管理

### 启动服务

```bash
/www/start.sh
```

### 停止服务

```bash
/www/stop.sh
```

### 重启服务

```bash
/www/restart.sh
```

或者使用全局重启脚本：

```bash
./restart.sh
```

### 查看服务状态

```bash
# 查看所有容器状态
docker ps

# 查看具体服务日志
cd /www/kf-api && docker-compose logs -f      # API服务日志
cd /www/kf-message && docker-compose logs -f  # 消息服务日志
cd /www/kf-containers && docker-compose logs -f # 基础服务日志
```

## 配置模板

所有配置文件模板位于 `config_template/` 目录：

### 后端服务配置
- `kf_api.yaml`: API服务配置模板
- `kf_message_prod.yaml`: 消息服务配置模板

### Docker配置
- `docker-compose.yaml`: 基础服务Docker Compose配置模板
- `init.sql`: MySQL初始化脚本模板

### 前端配置
- `frontend-env.tmpl`: 前端环境变量模板

安装脚本会自动替换以下变量：

- `__domain__`: 域名
- `__mysql__password__`: MySQL密码
- `__redis__password__`: Redis密码
- `__admin__password__`: 管理员密码

### 模板处理机制

- **模板保护**: 原始模板文件不会被修改
- **动态生成**: 每次安装都从模板重新生成配置文件
- **重复安装**: 支持重复安装，不会影响模板文件
- **变量替换**: 使用用户输入替换模板变量

## 目录结构

安装后的目录结构：

```
/www/
├── kf-api/              # API后端服务 (Docker镜像)
├── kf-message/          # 消息服务 (Docker镜像)
├── kf-bill/             # 总后台前端 (静态文件)
├── kf-manager/          # 客服后台前端 (静态文件)
├── kf-mobile/           # 移动端前端 (静态文件)
├── kf-containers/       # 基础服务Docker配置
├── cdn/                 # 静态文件目录
├── logs/                # 日志目录
├── install.conf         # 安装配置信息
├── start.sh             # 启动脚本
├── stop.sh              # 停止脚本
└── restart.sh           # 重启脚本
```

## 访问地址

- **总后台**: `http://bill.your-domain.com`
- **客服后台**: `http://manager.your-domain.com`
- **CDN静态文件**: `http://cdn.your-domain.com`
- **WebSocket服务**: `http://goim.your-domain.com`

## Docker镜像

系统会构建以下Docker镜像：

- **kf-api:latest**: API服务镜像
- **socket-server:latest**: 消息服务镜像

镜像构建过程：
1. 使用Makefile构建二进制文件
2. 使用Dockerfile构建Docker镜像
3. 通过docker-compose启动服务

## 故障排除

### 1. 服务无法启动

检查Docker容器状态：

```bash
docker ps -a
docker logs <container_name>
```

### 2. Docker服务问题

```bash
cd /www/kf-containers
docker-compose logs
docker-compose ps
```

### 3. 后端服务问题

```bash
cd /www/kf-api
docker-compose logs
docker-compose ps

cd /www/kf-message
docker-compose logs
docker-compose ps
```

### 4. Nginx配置问题

```bash
nginx -t
systemctl status nginx
```

### 5. 端口占用

检查端口占用：

```bash
netstat -tlnp | grep :8081  # API端口
netstat -tlnp | grep :9000  # 消息服务端口
netstat -tlnp | grep :80    # Nginx端口
```

### 6. 依赖版本问题

如果遇到依赖版本问题，可以：

```bash
# 检查当前依赖版本
./test_versions.sh

# 手动安装或更新依赖
# 然后重新运行安装脚本
```

### 7. 镜像构建问题

如果Docker镜像构建失败：

```bash
# 检查Makefile
cd /www/kf-api
make build
make build-image

cd /www/kf-message
make build
make build-image
```

## 安全建议

1. **修改默认密码**: 安装完成后立即修改管理员密码
2. **配置防火墙**: 只开放必要的端口 (80, 443)
3. **SSL证书**: 配置HTTPS证书
4. **定期备份**: 备份数据库和配置文件
5. **Docker安全**: 定期更新Docker镜像和基础镜像

## 更新系统

如需更新系统，建议：

1. 备份当前配置和数据
2. 停止所有服务
3. 更新源码
4. 重新构建Docker镜像
5. 重新运行安装脚本或手动更新

## 技术支持

如遇到问题，请检查：

1. 系统日志: `journalctl -xe`
2. Docker日志: `docker-compose logs`
3. Nginx日志: `/var/log/nginx/`
4. 依赖版本: `./test_versions.sh`
5. 容器状态: `docker ps -a` 