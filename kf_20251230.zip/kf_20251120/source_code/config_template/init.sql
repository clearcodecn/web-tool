-- MySQL初始化脚本
-- 创建默认数据库 kf2

CREATE DATABASE IF NOT EXISTS kf2 CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- 显示创建的数据库
SHOW DATABASES; 