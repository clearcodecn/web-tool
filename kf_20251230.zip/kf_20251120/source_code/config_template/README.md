# 配置模板目录

本目录包含所有需要变量替换的配置文件模板。

## 模板文件列表

### 后端服务配置

- **`kf_api.yaml`**: kf-api服务的配置文件模板
  - 变量: `__domain__`, `__mysql__password__`, `__redis__password__`, `__admin__password__`

- **`kf_message_prod.yaml`**: kf-message服务的配置文件模板
  - 变量: `__redis__password__`

### Docker配置

- **`docker-compose.yaml`**: 基础服务(Mysql, Redis, NSQ)的Docker Compose配置模板
  - 变量: `__mysql__password__`, `__redis__password__`

- **`init.sql`**: MySQL初始化脚本模板
  - 用于创建默认数据库kf2

### 前端配置

- **`frontend-env.tmpl`**: 前端项目环境变量模板
  - 变量: `__domain__`
  - 生成: `.env.production` 文件

## 变量说明

| 变量名 | 说明 | 示例 |
|--------|------|------|
| `__domain__` | 安装域名 | `example.com` |
| `__mysql__password__` | MySQL数据库密码 | `mypassword123` |
| `__redis__password__` | Redis密码 | `redispass456` |
| `__admin__password__` | 管理员密码 | `adminpass789` |

## 安装过程

安装脚本会按以下步骤处理模板文件：

1. **复制模板**: 将模板文件复制到目标位置
2. **变量替换**: 使用用户输入的配置替换模板变量
3. **生成配置**: 生成最终的配置文件

## 注意事项

- 模板文件不会被修改，保持原始状态
- 每次安装都会从模板重新生成配置文件
- 支持重复安装，不会影响模板文件 