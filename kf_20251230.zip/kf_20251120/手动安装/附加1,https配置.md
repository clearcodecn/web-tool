
### 安装 https 证书，使用lego

```
wget https://github.com/go-acme/lego/releases/download/v4.23.1/lego_v4.23.1_linux_amd64.tar.gz
tar -zxvf lego_v4.23.1_linux_amd64.tar.gz
mv lego /usr/local/bin/
lego --version

# 输出以下内容代表执行成功
lego version 4.23.1 linux/amd64



# 我这里用的是godaddy的域名
export GODADDY_API_KEY="e4XjorzTMFxi_HUdks5RToqbgDBw7BUaUnn"
export GODADDY_API_SECRET="GkKmyHyGWsdaSSn9PbbxCw"


lego --email=admin@pearkfsmart.site \
     --domains="*.pearkfsmart.site" \
     --domains="pearkfsmart.site" \
     --dns=godaddy \
     --accept-tos \
     run


lego --email=admin@smartkf.top \
     --domains="*.orangekfsmart.site" \
     --domains="orangekfsmart.site" \
     --domains="*.grapekfsmart.site" \
     --domains="grapekfsmart.site" \
     --dns=godaddy \
     --accept-tos \
     run

lego --email=admin@smartkf.top \
     --domains="*.grapekfsmart.site" \
     --domains="grapekfsmart.site" \
     --dns=godaddy \
     --accept-tos \
     run


orangekfsmart.site
grapekfsmart.site




```